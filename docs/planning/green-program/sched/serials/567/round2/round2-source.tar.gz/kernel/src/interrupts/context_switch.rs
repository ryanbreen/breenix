//! Context switching logic for interrupt return path
//!
//! This module handles the actual context switching when returning from
//! interrupts. It's called from assembly code after the interrupt handler
//! has completed its minimal work.

#![cfg(target_arch = "x86_64")]

use crate::task::dispatch_strand_census::{note_fact, DispatchLogFact};
use crate::task::process_context::{
    is_kernel_code_selector, restore_userspace_context, save_userspace_context, RestoreError,
    SavedRegisters,
};
use crate::task::scheduler;
use crate::task::thread::ThreadPrivilege;
use crate::tracing::providers::counters::{
    DISPATCH_GATE_PREEMPT_ACTIVE, DISPATCH_KERNEL_RESTORE_TOTAL, DISPATCH_NO_PROGRESS,
};
use crate::tracing::providers::sched::{
    trace_ctx_switch, trace_dispatch_abandon, trace_dispatch_save, DispatchAbandonSite,
    DispatchSaveReason,
};
use core::sync::atomic::{AtomicU64, Ordering};
use x86_64::structures::idt::InterruptStackFrame;
use x86_64::VirtAddr;

/// Admission to the x86 selection operation. Only this module can construct it;
/// ordinary kernel callers request rescheduling without changing the owner of
/// the RIP/RSP/RFLAGS snapshot. Constructed after the IRQ-return admission checks.
pub(crate) struct InterruptDispatch {
    private: (),
}

enum FirstUserspaceEntry {
    Installed,
    Aborted,
}

static KERNEL_FRAME_RESTORE_REFUSED: AtomicU64 = AtomicU64::new(0);
static FIRST_USERSPACE_ENTRY_ABORT_COUNT: AtomicU64 = AtomicU64::new(0);
static USERSPACE_DISPATCH_NO_CR3_REFUSED: AtomicU64 = AtomicU64::new(0);
static USERSPACE_DISPATCH_CREATING_REFUSED: AtomicU64 = AtomicU64::new(0);
static DISPATCH_GUARD_UNAVAILABLE_STREAK: AtomicU64 = AtomicU64::new(0);

/// Third dispatch admission arm (tranche-2 P3). A row whose publication has not
/// completed must never have CR3 armed for it. Cheap field read on a row the
/// caller already holds; hot-path safe.
#[inline]
pub(crate) fn refuse_unpublished_dispatch(
    process: &crate::process::process::Process,
    _: u64,
    _: u64,
) -> bool {
    if !process.is_unpublished() {
        return false;
    }
    USERSPACE_DISPATCH_CREATING_REFUSED.fetch_add(1, Ordering::Relaxed);

    true
}

#[cfg(feature = "boot_tests")]
pub fn userspace_dispatch_creating_refused() -> u64 {
    USERSPACE_DISPATCH_CREATING_REFUSED.load(Ordering::Relaxed)
}

#[inline(always)]
fn note_dispatch_guard_available() {
    DISPATCH_GUARD_UNAVAILABLE_STREAK.store(0, Ordering::Relaxed);
}

#[inline(always)]
fn note_dispatch_guard_unavailable() {
    DISPATCH_GUARD_UNAVAILABLE_STREAK.fetch_add(1, Ordering::Relaxed);
}

// REMOVED: NEXT_PAGE_TABLE is no longer needed since CR3 switching happens
// immediately during context switch, not deferred to interrupt return

/// Check if rescheduling is needed and perform context switch if necessary
///
/// This is called from the assembly interrupt return path and is the
/// CORRECT place to handle context switching (not in the interrupt handler).
#[no_mangle]
pub extern "C" fn check_need_resched_and_switch(
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
) {
    crate::task::scheduler::note_scheduling_epoch(0);
    // CRITICAL: Only schedule when returning to userspace with preempt_count == 0
    if !crate::per_cpu::can_schedule(interrupt_frame.code_segment.0 as u64) {
        return;
    }

    // NOTE: Context is saved ONLY when actually switching threads (see line ~135).
    // We do NOT save on every timer interrupt - that caused massive overhead
    // preventing userspace from executing even one instruction.
    // The interrupt frame captures the current RIP; we save to thread.context
    // only when switching away.
    let from_userspace = (interrupt_frame.code_segment.0 & 3) == 3;

    // CRITICAL: Check if preemption is enabled before attempting context switch.
    // Syscalls call preempt_disable() at entry, so if preempt_count > 0, we must NOT
    // switch away. The bits 0-27 hold the actual count, bit 28 is PREEMPT_ACTIVE.
    let preempt_count = crate::per_cpu::preempt_count();
    let preempt_count_value = preempt_count & 0x0FFFFFFF; // Mask out PREEMPT_ACTIVE bit
    if preempt_count_value > 0 && !from_userspace {
        // Preemption disabled while in kernel - don't context switch.
        // The thread is executing a syscall or other non-preemptible kernel code.
        // Leave need_resched set so we try again after preempt_enable().
        return;
    }

    // CRITICAL FIX: Check PREEMPT_ACTIVE early, BEFORE calling schedule().
    // PREEMPT_ACTIVE (bit 28) is set in syscall/entry.asm during syscall return
    // to protect the register restoration sequence. If set, we're in the middle
    // of returning from a syscall and must NOT attempt a context switch.
    //
    // Previously, this check happened AFTER schedule() was called, which mutated
    // the scheduler's current_thread state. Then the early return left the
    // scheduler thinking the idle thread was running when actually the userspace
    // thread was still active. This caused the entire scheduler to become stuck.
    //
    // The fix: Check preempt_active BEFORE schedule() to avoid state corruption.
    let preempt_count = crate::per_cpu::preempt_count();
    let preempt_active = (preempt_count & 0x10000000) != 0; // Bit 28

    if preempt_active {
        // PREEMPT_ACTIVE is set during syscall return while registers are being restored.
        // We must NOT context switch during this critical window, regardless of whether
        // the interrupt frame shows userspace or kernel CS.
        //
        // Previously this only checked `from_userspace && preempt_active`, which missed
        // the case where we're in kernel mode (CS=0x08) but PREEMPT_ACTIVE is set because
        // we're in the middle of setting up the interrupt frame for userspace return.
        // In that case, doing a context switch would corrupt partially-restored registers.
        //
        // NOTE: No logging here - we're in IRQ context and logging can deadlock.
        //
        // #772 diagnostics: this is also the gate the 1 syscall-return call
        // site leaves by. `kernel/src/syscall/entry.asm` sets PREEMPT_ACTIVE at
        // `:110`, two instructions before its call at `:124`, and clears it at
        // `:223`, after that call has returned -- so a save attributed to that
        // entry point would contradict those 3 line numbers. Counting the exits
        // is what makes the claim measurable rather than only readable off the
        // assembly.
        crate::trace_count!(DISPATCH_GATE_PREEMPT_ACTIVE);
        return;
    }

    // Check if current thread is blocked or terminated - we MUST switch away in that case.
    // Uses ThreadState::is_blocked() (#673 review, m4) -- this site recognizes
    // the FULL five-variant family (including BlockedOnIO), unlike
    // per_cpu::can_schedule()'s deliberately narrower four-variant set
    // (per_cpu.rs's own comment on that narrowing names the reason).
    //
    // Recognizing BlockedOnIO here is safe for a reason specific to THIS
    // site, not a blanket claim about the state itself (#673 review, MA2):
    // this check runs strictly AFTER the `preempt_count_value > 0 &&
    // !from_userspace` early return above, so by the time we reach it,
    // either preempt_count is already zero or we entered from userspace --
    // never mid-brake. Every x86 producer of BlockedOnIO (the
    // WaitQueueHead-based `prepare_to_wait(BlockedOnIO)` sites in
    // drivers/virtio/{block,block_mmio,sound,sound_mmio,gpu_pci}.rs and
    // syscall/graphics.rs, and the scheduler-internal
    // `block_current_for_io_with_timeout()` the Completion-based device
    // waits use, task/scheduler.rs) sets the state only immediately before
    // handing off to the scheduler (`schedule_current_wait()` or an inline
    // `schedule()` call), so a thread is never observably BlockedOnIO while
    // still holding a brake it needs this check to respect. That includes
    // #673's own production-init brake:
    // `Completion::wait_timeout_uninterruptible()` (task/completion.rs, used
    // by the ext2 read's `wait_for_completion()`, drivers/virtio/block.rs)
    // explicitly calls `preempt_enable()` before setting BlockedOnIO and
    // restores the brake afterward, so this site seeing BlockedOnIO here
    // never coincides with the brake being up. This half of the widening
    // ships in every x86 profile, `boot_tests`/`testing` included, not only
    // the shipped production one.
    //
    // per_cpu::can_schedule() (M5) narrows differently: it is called from
    // the timer interrupt with no equivalent preceding preempt-count gate of
    // its own, so it cannot rely on the same "never mid-brake" argument --
    // see its own comment for why BlockedOnIO stays out there (#666, #508,
    // the still-open gap between preempt_count and scheduling admission
    // during a boot-thread disk-completion wait). The two sites are not
    // inconsistent: each recognizes the family that is provably safe for
    // where it sits.
    let current_thread_blocked_or_terminated = scheduler::with_scheduler(|sched| {
        sched.current_thread_mut().is_some_and(|current| {
            current.state.is_blocked()
                || current.state == crate::task::thread::ThreadState::Terminated
        })
    })
    .unwrap_or(false);

    // Check if reschedule is needed
    // CRITICAL: If current thread is blocked/terminated, we MUST schedule regardless of need_resched.
    // A blocked thread cannot continue running - we must switch to another thread.
    let need_resched = scheduler::check_and_clear_need_resched();
    if !need_resched && !current_thread_blocked_or_terminated {
        // No reschedule needed, but check for pending signals before returning to userspace
        if from_userspace {
            check_and_deliver_signals_for_current_thread(saved_regs, interrupt_frame);
        }
        return;
    }

    // #772 census: count a preemption entered on a frame
    // byte-identical -- RIP AND RSP -- to the one the last completed dispatch
    // installed for this same thread.
    //
    // This used to be a refusal: candidate A spent a one-shot per dispatch,
    // re-armed `need_resched` and returned to the thread. R115 removed that arm.
    // Ruling R113 (2026-09-03) retired the proxy, because
    // docs/planning/green-program/sockets/772-DIAG-2026-09-03.md symbolised the
    // two addresses this population sits on as the wait loop's own park points
    // -- so an identical frame records a thread that went once around its wait
    // loop and re-parked, not a dispatch that retired no instruction. What is
    // left is a REVISIT census: the counter still measures something real and
    // reproducible, it just does not measure the defect #772 is filed for, and
    // nothing here changes control flow. The replacement oracle is the
    // park-count split at the save site (`note_dispatch_save` below), not
    // anything in this block.
    // claim-lint:ok: 8 of 8 `return;` statements in this function match main
    // 5f81d92b, counted in this slot; the only additions are counter reads.
    //
    // The increment rule is unchanged from the build the 40-boot battery
    // measured, so its committed `DISPATCH_NO_PROGRESS` readouts stay
    // comparable with any future one.
    //
    // Cost on the interrupt-return path: 0 added instructions for an interrupt
    // that returns at gate 4 -- the common tick -- because this block sits
    // after that return. On the arm that does reach it: one lock-free
    // current-thread read plus `classify_dispatch_progress`'s four GS-relative
    // loads and one `Acquire` load, then at most one per-CPU relaxed atomic
    // add. No lock, no allocation, no formatting, no page-table work.
    //
    // Short-circuited on the blocked/terminated arm deliberately: that switch
    // is mandatory, it must not pay for the predicate -- not even the lock-free
    // tid read -- and the per-reason save census
    // (`DISPATCH_NOPROGRESS_SAVE_KERNEL_BLOCKED_MANDATORY`) already records
    // that arm's identical frames at the save site.
    if !current_thread_blocked_or_terminated {
        if let Some(current_tid) = crate::per_cpu::current_thread_id_lock_free() {
            // `matches!` rather than `==`: `NoProgress` now carries the
            // witness the save-site split consumes, and this census does not
            // want the split -- reading the kind here would put
            // `classify_no_progress_kind`'s five reads on the
            // interrupt-return path for a value this census does not record.
            if matches!(
                crate::per_cpu::classify_dispatch_progress(
                    current_tid,
                    interrupt_frame.instruction_pointer.as_u64(),
                    interrupt_frame.stack_pointer.as_u64(),
                ),
                crate::per_cpu::DispatchProgress::NoProgress(_)
            ) {
                crate::trace_count!(DISPATCH_NO_PROGRESS);
            }
        }
    }

    // Both entry paths must resolve the process-manager dependency BEFORE committing
    // to a scheduling decision, and both must refuse identically when it is
    // unavailable. The kernel-entry path used to skip this check and pass `None`
    // down, so a dispatch could be committed to a never-started user thread whose
    // first ring-3 entry then aborted for want of this very lock, requeue the
    // thread and re-arm need_resched, forever. Refusing here leaves the
    // lock-holding context - the only one that can release it - running.
    // try_lock only: blocking here would deadlock the interrupt path.
    let mut process_manager_guard = match crate::process::try_manager() {
        Some(guard) => {
            note_dispatch_guard_available();
            guard
        }
        None => {
            note_dispatch_guard_unavailable();
            scheduler::set_need_resched();
            return;
        }
    };

    // Perform scheduling decision
    let admission = InterruptDispatch { private: () };
    let () = admission.private;
    let schedule_result = scheduler::schedule_for_interrupt_return(&admission);

    if schedule_result.is_none() {
        // CRITICAL: Clear exception cleanup context even when no switch happens.
        // Otherwise the flag stays set forever, causing unexpected scheduling later.
        crate::per_cpu::clear_exception_cleanup_context();
        // CRITICAL: Even though no context switch happens, we MUST check for signals!
        // This case occurs when the current thread is the only ready thread (e.g., after
        // yield_now() when no other threads are runnable). Without this check, signals
        // queued for the current process (like SIGTERM from kill()) would never be delivered.
        if from_userspace {
            check_and_deliver_signals_for_current_thread(saved_regs, interrupt_frame);
        }
        return;
    }
    if let Some((old_thread_id, new_thread_id)) = schedule_result {
        // Clear exception cleanup context since we're doing a context switch
        crate::per_cpu::clear_exception_cleanup_context();

        // Trace context switch - compiles to ~5 instructions when disabled
        trace_ctx_switch(old_thread_id, new_thread_id);

        if old_thread_id == new_thread_id {
            // Same thread continues running, but check for pending signals
            if from_userspace {
                check_and_deliver_signals_for_current_thread(saved_regs, interrupt_frame);
            }
            return;
        }

        // Save current thread's context if coming from userspace
        // CRITICAL: If save fails, we MUST NOT switch contexts!
        // Switching without saving would cause the process to return to stale RIP (entry point)
        //
        // NOTE: PREEMPT_ACTIVE check was moved earlier in this function (before schedule() call)
        // to prevent scheduler state corruption. If we reach here from userspace, we know
        // preempt_active is false (otherwise we would have returned early).

        // Check if current thread is blocked in syscall (pause/waitpid)
        let (blocked_in_syscall, old_thread_is_user) =
            scheduler::with_thread_mut(old_thread_id, |thread| {
                (
                    thread.blocked_in_syscall,
                    thread.privilege == ThreadPrivilege::User,
                )
            })
            .unwrap_or((false, false));

        // #772 diagnostics: which gate admitted this switch. The blocked or
        // terminated arm is the mandatory switch the refusal is conjoined out
        // of; anything else got here on `need_resched`. This is the same
        // boolean the refusal itself tests, so the split is exactly the
        // refusal's visibility boundary.
        let save_mandatory = current_thread_blocked_or_terminated;

        if from_userspace {
            // Use the already-held guard to save context (prevents TOCTOU race)

            if !save_current_thread_context_with_guard(
                old_thread_id,
                saved_regs,
                interrupt_frame,
                &mut process_manager_guard,
                if save_mandatory {
                    DispatchSaveReason::UserMandatory
                } else {
                    DispatchSaveReason::UserPreempt
                },
            ) {
                // Roll back the committed switch and re-arm rescheduling.
                scheduler::abort_dispatch_and_resume(new_thread_id, old_thread_id);
                trace_dispatch_abandon(DispatchAbandonSite::RollbackSaveFailed);
                scheduler::set_need_resched();
                return;
            }
        } else if !from_userspace && (blocked_in_syscall || old_thread_is_user) {
            // A user thread was interrupted in kernel mode, including a thread blocked
            // in a syscall's HLT loop. Save the KERNEL context in process.main_thread so
            // the user-thread restore path can resume it at the correct kernel location.
            // NOTE: No logging here - this is a hot path during blocking I/O
            save_kernel_context_with_guard(
                old_thread_id,
                saved_regs,
                interrupt_frame,
                &mut process_manager_guard,
                if save_mandatory {
                    DispatchSaveReason::KernelBlockedMandatory
                } else {
                    DispatchSaveReason::KernelBlockedPreempt
                },
            );
        } else if !from_userspace {
            // Pure kernel thread (like kthread) being preempted - save its context
            // This is NOT a userspace thread and NOT blocked in syscall - it's a
            // kernel thread running its own code (e.g., kthread_entry -> user function)
            save_kthread_context(
                old_thread_id,
                saved_regs,
                interrupt_frame,
                if save_mandatory {
                    DispatchSaveReason::KthreadMandatory
                } else {
                    DispatchSaveReason::KthreadPreempt
                },
            );
        }

        // Switch to the new thread
        // Pass the process_manager_guard so we don't try to re-acquire the lock
        switch_to_thread(
            new_thread_id,
            old_thread_id,
            saved_regs,
            interrupt_frame,
            Some(process_manager_guard),
        );

        // #772: record the resume frame this dispatch installed.
        //
        // Taken HERE rather than beside `set_current_thread` inside
        // `switch_to_thread`: at that point the frame still carries the
        // OUTGOING thread's RIP/RSP, because the resume frame is not written
        // until one of `switch_to_thread`'s arms rewrites it further down. By
        // the time control returns here the frame is final on the arms that
        // install a resume frame and on the arms that instead redirect to idle
        // or roll the dispatch back,
        // which is why the tid comes from the per-CPU current-thread pointer
        // (whoever the CPU is actually about to run) and not from
        // `new_thread_id`. Writing it unconditionally on a completed switch is
        // also what invalidates the previous thread's mark.
        match crate::per_cpu::current_wait_loop_iters() {
            // The tid and the park count come out of one deref of the per-CPU
            // current-thread pointer, so the mark cannot pair one thread's id
            // with another thread's count.
            Some((dispatched_tid, wait_iters)) => crate::per_cpu::set_dispatch_mark(
                dispatched_tid,
                interrupt_frame.instruction_pointer.as_u64(),
                interrupt_frame.stack_pointer.as_u64(),
                wait_iters,
            ),
            // No nameable current thread: invalidate rather than record a
            // mark no later check could honestly match.
            None => crate::per_cpu::clear_dispatch_mark(),
        }

        // NOTE: Don't log here - this is on the hot path and can affect timing

        // CRITICAL: Clear PREEMPT_ACTIVE after context switch completes
        // PREEMPT_ACTIVE (bit 28) is set in syscall/entry.asm to protect register
        // restoration during syscall return. When we switch to a different thread,
        // that flag should NOT persist - the NEW thread is not in syscall return.
        //
        // Without this, PREEMPT_ACTIVE would carry over to the new thread, causing:
        // 1. can_schedule() to return false (blocks scheduling)
        // 2. Exception handlers to need the bypass workaround
        //
        // Linux clears this in schedule_tail() after context switch.
        crate::per_cpu::clear_preempt_active();

        // Reset the timer quantum for the new thread
        super::timer::reset_quantum();
    }
}

/// #772 diagnostics: record one context save, classified against the dispatch
/// mark this CPU carries.
///
/// `thread_id` is the thread whose context is being saved, which is also the
/// thread the last completed dispatch installed the mark for, so the two ends
/// of the comparison name the same identity. `Advanced` means the thread moved
/// off the RIP/RSP it was dispatched to (or no mark applies); `NoProgress`
/// means the frame is byte-identical.
///
/// A byte-identical frame is a wait-loop revisit census, not a defect census
/// (docs/planning/green-program/sockets/772-DIAG-2026-09-03.md, and ruling
/// R113 (2026-09-03), which retired the proxy). This function no longer leaves
/// the two cases indistinguishable, which is what that ruling asked for: the
/// `NoProgress` arm mints a `DispatchNoProgressKind` from the witness
/// `classify_dispatch_progress` hands it, splitting a thread that reached a
/// counted park point again (`Revisit`) from one that reached none in
/// between (`ZeroIter`) -- "re-parked on the same halt" and "retired no
/// instructions" hold only where the mark's RIP is that wait loop's own
/// post-halt resume point, which these counters do not record -- with
/// `Unknown` for an observation neither answer fits.
// claim-lint:ok: docs/planning/green-program/sockets/772-DIAG-2026-09-03.md
///
/// Cost: four GS-relative loads and one `PER_CPU_INITIALIZED` Acquire load
/// inside `classify_dispatch_progress`; on a byte-identical frame, five more
/// reads inside `classify_no_progress_kind` (that Acquire load again, the
/// lock-free current-thread deref, the thread's id and its park count, and
/// the GS-relative stamp the count is compared against), then four per-CPU
/// atomic adds (the reason total, the identical-frame subset of that reason,
/// the kind aggregate, and the reason x kind cell); on any other frame, one
/// add. That is the accounting
/// `crate::tracing::providers::sched::trace_dispatch_save` states, and this
/// comment is kept equal to it. No lock, no allocation, no formatting. It is
/// called from the 3 arms that save a context and is absent from the gate-4
/// early return the common tick takes.
#[inline(always)]
fn note_dispatch_save(
    reason: DispatchSaveReason,
    thread_id: u64,
    interrupt_frame: &InterruptStackFrame,
) {
    let rip = interrupt_frame.instruction_pointer.as_u64();
    let no_progress = match crate::per_cpu::classify_dispatch_progress(
        thread_id,
        rip,
        interrupt_frame.stack_pointer.as_u64(),
    ) {
        // The witness the match binds is the only way to reach the split, so
        // the kind cannot be minted from a frame the mark did not match, nor
        // for a thread other than the one the mark named.
        crate::per_cpu::DispatchProgress::NoProgress(frame) => {
            Some(crate::per_cpu::classify_no_progress_kind(frame))
        }
        crate::per_cpu::DispatchProgress::Advanced => None,
    };
    trace_dispatch_save(reason, no_progress, rip);
}

/// Save the current thread's userspace context using an already-held guard
/// Returns true if context was saved successfully, false otherwise
///
/// This version takes an already-acquired process manager guard to prevent
/// TOCTOU races where the lock could be acquired between checking availability
/// and actually using it.
fn save_current_thread_context_with_guard(
    thread_id: u64,
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
    manager_guard: &mut crate::process::TryProcessManagerGuard,
    save_reason: DispatchSaveReason,
) -> bool {
    if let Some(ref mut manager) = **manager_guard {
        if let Some((_, process)) = manager.find_process_by_thread_mut(thread_id) {
            if let Some(ref mut thread) = process.main_thread {
                save_userspace_context(thread, interrupt_frame, saved_regs);
                // #772: recorded where the save actually happened, so the
                // counter cannot outrun the saves.
                note_dispatch_save(save_reason, thread_id, interrupt_frame);

                return true;
            } else {
                note_fact(DispatchLogFact::SaveNoMainThread);
            }
        } else {
            note_fact(DispatchLogFact::SaveProcessNotFound);
        }
    } else {
        note_fact(DispatchLogFact::SaveManagerNone);
    }
    false
}

/// Save kernel context for a thread blocked inside a syscall
/// This saves the kernel-mode context (RIP in HLT loop, kernel RSP, CS=0x08)
/// so the thread can be resumed at the correct kernel location.
fn save_kernel_context_with_guard(
    thread_id: u64,
    saved_regs: &SavedRegisters,
    interrupt_frame: &InterruptStackFrame,
    manager_guard: &mut crate::process::TryProcessManagerGuard,
    save_reason: DispatchSaveReason,
) {
    if let Some(ref mut manager) = **manager_guard {
        if let Some((_pid, process)) = manager.find_process_by_thread_mut(thread_id) {
            if let Some(ref mut thread) = process.main_thread {
                // Save kernel context - the thread is in kernel mode (HLT loop in pause/waitpid)
                // Save registers from the interrupt frame (kernel mode state)
                thread.context.rax = saved_regs.rax;
                thread.context.rbx = saved_regs.rbx;
                thread.context.rcx = saved_regs.rcx;
                thread.context.rdx = saved_regs.rdx;
                thread.context.rsi = saved_regs.rsi;
                thread.context.rdi = saved_regs.rdi;
                thread.context.rbp = saved_regs.rbp;
                thread.context.r8 = saved_regs.r8;
                thread.context.r9 = saved_regs.r9;
                thread.context.r10 = saved_regs.r10;
                thread.context.r11 = saved_regs.r11;
                thread.context.r12 = saved_regs.r12;
                thread.context.r13 = saved_regs.r13;
                thread.context.r14 = saved_regs.r14;
                thread.context.r15 = saved_regs.r15;

                // From interrupt frame - this is the KERNEL location (HLT instruction)
                thread.context.rip = interrupt_frame.instruction_pointer.as_u64();
                thread.context.rsp = interrupt_frame.stack_pointer.as_u64();
                thread.context.rflags = interrupt_frame.cpu_flags.bits();
                thread.context.cs = interrupt_frame.code_segment.0 as u64;
                thread.context.ss = interrupt_frame.stack_segment.0 as u64;

                // #772/#775: the reason counter and the fixed atomic strand
                // ledger cover this same successful kernel-context save.
                note_dispatch_save(save_reason, thread_id, interrupt_frame);
                crate::task::dispatch_strand_census::note_save(thread_id);
            }
        }
    }
}

/// Save kernel thread (kthread) context before switching away
/// This is similar to save_kernel_context_with_guard but for pure kernel threads
/// that are not associated with a process (they only exist in the scheduler)
fn save_kthread_context(
    thread_id: u64,
    saved_regs: &SavedRegisters,
    interrupt_frame: &InterruptStackFrame,
    save_reason: DispatchSaveReason,
) {
    let saved = scheduler::with_thread_mut(thread_id, |thread| {
        // Save general purpose registers from the interrupt
        thread.context.rax = saved_regs.rax;
        thread.context.rbx = saved_regs.rbx;
        thread.context.rcx = saved_regs.rcx;
        thread.context.rdx = saved_regs.rdx;
        thread.context.rsi = saved_regs.rsi;
        thread.context.rdi = saved_regs.rdi;
        thread.context.rbp = saved_regs.rbp;
        thread.context.r8 = saved_regs.r8;
        thread.context.r9 = saved_regs.r9;
        thread.context.r10 = saved_regs.r10;
        thread.context.r11 = saved_regs.r11;
        thread.context.r12 = saved_regs.r12;
        thread.context.r13 = saved_regs.r13;
        thread.context.r14 = saved_regs.r14;
        thread.context.r15 = saved_regs.r15;

        // Save from interrupt frame - the kernel location where thread was preempted
        thread.context.rip = interrupt_frame.instruction_pointer.as_u64();
        thread.context.rsp = interrupt_frame.stack_pointer.as_u64();
        thread.context.rflags = interrupt_frame.cpu_flags.bits();
        thread.context.cs = interrupt_frame.code_segment.0 as u64;
        thread.context.ss = interrupt_frame.stack_segment.0 as u64;
    })
    .is_some();

    // #772: only a save that found its thread is counted.
    if saved {
        note_dispatch_save(save_reason, thread_id, interrupt_frame);
    }

    // Hardware memory fence to ensure all context saves are visible before
    // we switch to a different thread. This is critical for TCG mode.
    core::sync::atomic::fence(core::sync::atomic::Ordering::SeqCst);
}

/// The saved CS is authoritative, and this predicate deliberately mirrors the
/// enforcement check in `restore_userspace_context`. A never-run user thread
/// carries `cs = 0x33`, while `is_kernel_code_selector` rejects `cs == 0`, so
/// this does not widen kernel-frame routing.
fn saved_context_is_kernel_frame(
    thread_id: u64,
    guard: Option<&crate::process::TryProcessManagerGuard>,
) -> bool {
    let manager_has_kernel_frame = |manager: &crate::process::ProcessManager| {
        manager
            .find_process_by_thread(thread_id)
            .and_then(|(_pid, process)| process.main_thread.as_ref())
            .is_some_and(|thread| {
                thread.privilege == ThreadPrivilege::User
                    && is_kernel_code_selector(thread.context.cs)
            })
    };

    if let Some(manager_guard) = guard {
        let manager_option: &Option<crate::process::ProcessManager> = manager_guard;
        return manager_option
            .as_ref()
            .is_some_and(manager_has_kernel_frame);
    }

    let Some(manager_guard) = crate::process::try_manager() else {
        return false;
    };
    let manager_option: &Option<crate::process::ProcessManager> = &manager_guard;
    manager_option
        .as_ref()
        .is_some_and(manager_has_kernel_frame)
}

/// Switch to a different thread
fn switch_to_thread(
    thread_id: u64,
    resume_thread_id: u64,
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
    process_manager_guard: Option<crate::process::TryProcessManagerGuard>,
) {
    // Update per-CPU current thread and TSS.RSP0
    scheduler::with_thread_mut(thread_id, |thread| {
        // Update per-CPU current thread pointer
        let thread_ptr = thread as *const _ as *mut crate::task::thread::Thread;
        crate::per_cpu::set_current_thread(thread_ptr);

        // Update TSS.RSP0 with new thread's kernel stack top
        // This is critical for interrupt/exception handling
        if let Some(kernel_stack_top) = thread.kernel_stack_top {
            crate::per_cpu::update_tss_rsp0(kernel_stack_top.as_u64());
        }
    });

    // Switch TLS if needed (kernel threads don't have TLS)
    let is_kernel_thread = scheduler::with_thread_mut(thread_id, |thread| {
        thread.privilege == ThreadPrivilege::Kernel
    })
    .unwrap_or(false);

    if !is_kernel_thread {
        if crate::tls::switch_tls(thread_id).is_err() {
            scheduler::abort_dispatch_and_resume(thread_id, resume_thread_id);
            trace_dispatch_abandon(DispatchAbandonSite::RollbackTls);
            scheduler::set_need_resched();
            return;
        }
    }

    // Check if this is the idle thread
    let is_idle =
        scheduler::with_scheduler(|sched| thread_id == sched.idle_thread()).unwrap_or(false);

    // Check if thread was blocked inside a syscall (pause/waitpid)
    // If so, we must NOT restore userspace context - the thread needs to
    // continue executing the syscall code and return through the normal path.
    let blocked_in_syscall =
        scheduler::with_thread_mut(thread_id, |thread| thread.blocked_in_syscall).unwrap_or(false);
    if is_idle {
        // Check if idle thread has a saved context to restore
        // If it was preempted while running actual code (not idle_loop), restore that context
        //
        // CRITICAL: After userspace starts (RING3_CONFIRMED), always go to idle_loop.
        // Idle's saved context from boot may contain RIP values in kernel init code
        // that cause hangs when restored during userspace operation.
        let userspace_started = crate::syscall::handler::is_ring3_confirmed();

        let has_saved_context = if userspace_started {
            // After userspace starts, idle should always return to idle_loop
            false
        } else {
            // During boot, may need to restore kernel init progress
            scheduler::with_thread_mut(thread_id, |thread| {
                let idle_loop_addr = idle_loop as *const () as u64;
                // Has saved context if RIP is non-zero AND not pointing to idle_loop
                thread.context.rip != 0 && thread.context.rip != idle_loop_addr
            })
            .unwrap_or(false)
        };

        if has_saved_context {
            // Restore idle thread's saved context (like a kthread)

            setup_kernel_thread_return(thread_id, saved_regs, interrupt_frame);
        } else {
            // No saved context or was in idle_loop - go to idle loop

            setup_idle_return(interrupt_frame);
        }
    } else if is_kernel_thread {
        // Set up to return to kernel thread

        setup_kernel_thread_return(thread_id, saved_regs, interrupt_frame);
    // The saved CS is the authoritative record of the ring where the context was
    // captured, even if a remote waker cleared blocked_in_syscall. Evaluate it
    // only for the non-idle userspace thread that consumes the result.
    } else if blocked_in_syscall
        || saved_context_is_kernel_frame(thread_id, process_manager_guard.as_ref())
    {
        // CRITICAL: Thread was blocked inside a syscall (like pause() or waitpid()).
        // We need to check if there are pending signals. If so, deliver them using
        // the saved userspace context. Otherwise, resume at the kernel HLT loop.

        // CRITICAL FIX: Read saved_userspace_context from the SCHEDULER's Thread,
        // not from process.main_thread. This fixes a race condition where:
        // - pause() saves context to process.main_thread THEN blocks in scheduler
        // - kill() sends signal BETWEEN these two operations
        // - Signal arrives but context not yet saved in the scheduler's Thread
        //
        // By reading from the scheduler's Thread (which is updated atomically with
        // the BlockedOnSignal state), we ensure consistency.
        let saved_context_from_scheduler =
            scheduler::with_thread_mut(thread_id, |thread| thread.saved_userspace_context.clone())
                .flatten();

        // Get the process page table and thread context
        let guard_option = process_manager_guard.or_else(|| crate::process::try_manager());
        if let Some(mut manager_guard) = guard_option {
            if let Some(ref mut manager) = *manager_guard {
                if let Some((pid, process)) = manager.find_process_by_thread_mut(thread_id) {
                    if refuse_unpublished_dispatch(process, thread_id, pid.as_u64()) {
                        crate::task::scheduler::set_need_resched();
                        setup_idle_return(interrupt_frame);
                        crate::task::scheduler::switch_to_idle();
                        trace_dispatch_abandon(DispatchAbandonSite::IdleUnpublishedBlocked);
                        crate::task::scheduler::requeue_refused_dispatch(thread_id);
                        unsafe {
                            crate::memory::process_memory::switch_to_kernel_page_table();
                        }
                        return;
                    }
                    let process_cr3 = match process.cr3_value() {
                        Some(cr3_value) => cr3_value,
                        None => {
                            USERSPACE_DISPATCH_NO_CR3_REFUSED.fetch_add(1, Ordering::Relaxed);

                            if let Some(ref mut thread) = process.main_thread {
                                thread.set_terminated();
                            }
                            crate::task::scheduler::with_thread_mut(thread_id, |sched_thread| {
                                sched_thread.set_terminated();
                            });
                            crate::task::scheduler::set_need_resched();
                            setup_idle_return(interrupt_frame);
                            crate::task::scheduler::switch_to_idle();
                            trace_dispatch_abandon(DispatchAbandonSite::IdleNoCr3Blocked);
                            unsafe {
                                crate::memory::process_memory::switch_to_kernel_page_table();
                            }
                            return;
                        }
                    };

                    // Check if there are pending signals to deliver
                    crate::signal::delivery::check_and_fire_alarm(process);
                    crate::signal::delivery::check_and_fire_itimer_real(process, 5000);

                    let has_pending_signals =
                        crate::signal::delivery::has_deliverable_signals(process);
                    // Use context from scheduler's Thread (single source of truth)
                    // Fall back to process.main_thread for backwards compatibility
                    let has_saved_context = saved_context_from_scheduler.is_some()
                        || process
                            .main_thread
                            .as_ref()
                            .map(|t| t.saved_userspace_context.is_some())
                            .unwrap_or(false);

                    if has_pending_signals && has_saved_context {
                        // SIGNAL DELIVERY PATH: Use saved userspace context for signal delivery
                        note_fact(DispatchLogFact::SignalPendingBlocked);

                        // CRITICAL FIX: Use context from scheduler's Thread (single source of truth)
                        // Fall back to process.main_thread for backwards compatibility
                        let saved_ctx_option =
                            saved_context_from_scheduler.as_ref().or_else(|| {
                                process
                                    .main_thread
                                    .as_ref()
                                    .and_then(|t| t.saved_userspace_context.as_ref())
                            });

                        if let Some(saved_ctx) = saved_ctx_option {
                            // Restore userspace registers from saved context
                            // But set RAX = -EINTR for the interrupted syscall
                            saved_regs.rax = (-4i64) as u64; // -EINTR
                            saved_regs.rbx = saved_ctx.rbx;
                            saved_regs.rcx = saved_ctx.rcx;
                            saved_regs.rdx = saved_ctx.rdx;
                            saved_regs.rsi = saved_ctx.rsi;
                            saved_regs.rdi = saved_ctx.rdi;
                            saved_regs.rbp = saved_ctx.rbp;
                            saved_regs.r8 = saved_ctx.r8;
                            saved_regs.r9 = saved_ctx.r9;
                            saved_regs.r10 = saved_ctx.r10;
                            saved_regs.r11 = saved_ctx.r11;
                            saved_regs.r12 = saved_ctx.r12;
                            saved_regs.r13 = saved_ctx.r13;
                            saved_regs.r14 = saved_ctx.r14;
                            saved_regs.r15 = saved_ctx.r15;

                            // Restore interrupt frame with USERSPACE context
                            unsafe {
                                interrupt_frame.as_mut().update(|frame| {
                                    frame.instruction_pointer =
                                        x86_64::VirtAddr::new(saved_ctx.rip);
                                    frame.stack_pointer = x86_64::VirtAddr::new(saved_ctx.rsp);
                                    frame.cpu_flags =
                                        x86_64::registers::rflags::RFlags::from_bits_truncate(
                                            saved_ctx.rflags,
                                        );
                                    // Use userspace code/stack segments
                                    frame.code_segment = crate::gdt::user_code_selector();
                                    frame.stack_segment = crate::gdt::user_data_selector();
                                });
                            }

                            note_fact(DispatchLogFact::SignalContextBlocked);
                        }

                        // Clear blocked_in_syscall and saved context on BOTH process.main_thread
                        // AND the scheduler's Thread to keep them in sync
                        if let Some(ref mut thread) = process.main_thread {
                            thread.blocked_in_syscall = false;
                            thread.saved_userspace_context = None;

                            // Update TSS RSP0 for the thread's kernel stack
                            if let Some(kernel_stack_top) = thread.kernel_stack_top {
                                crate::per_cpu::update_tss_rsp0(kernel_stack_top.as_u64());
                            }
                        }

                        // Also clear on scheduler's Thread
                        scheduler::with_thread_mut(thread_id, |thread| {
                            thread.blocked_in_syscall = false;
                            thread.saved_userspace_context = None;
                        });

                        // CRITICAL: Switch to process CR3 BEFORE delivering signal
                        // Signal delivery writes to user stack memory, which requires
                        // the process's page table to be active (not the kernel CR3).
                        // Without this, we get a page fault when trying to write the
                        // signal frame to user memory.
                        unsafe {
                            use x86_64::registers::control::{Cr3, Cr3Flags};
                            use x86_64::structures::paging::PhysFrame;
                            use x86_64::PhysAddr;
                            Cr3::write(
                                PhysFrame::containing_address(PhysAddr::new(process_cr3)),
                                Cr3Flags::empty(),
                            );
                        }
                        // Now deliver the signal (modifies interrupt_frame and saved_regs)
                        let signal_result = crate::signal::delivery::deliver_pending_signals(
                            process,
                            interrupt_frame,
                            saved_regs,
                        );

                        // Handle signal result
                        match signal_result {
                            crate::signal::delivery::SignalDeliveryResult::Terminated(_) => {
                                // Process was terminated - notify parent after releasing locks
                                // We need to return from this function and let the locks drop naturally
                                // but first save the notification data
                                // We have the notification info but can't call notify while holding locks.
                                // The notification will be handled by the timer interrupt when it
                                // eventually switches to the parent process, because:
                                // 1. The child is now marked as terminated
                                // 2. When the parent's waitpid resumes, it will find the terminated child
                                // 3. The scheduler will see the parent is unblocked
                                // However, this path is rare (signal terminating a process whose parent
                                // is blocked in waitpid *at the exact same time*).
                                // The parent notification happens in the other code paths.
                                // The return frame, RSP0, and CR3 already name the terminated
                                // thread, so bookkeeping-only rollback would make recorded and
                                // executing threads diverge. Complete the switch to idle on its
                                // own stack and master kernel PML4; the saved resume thread will
                                // be dispatched again by the reschedule armed here.
                                scheduler::set_need_resched();
                                setup_idle_return(interrupt_frame);
                                scheduler::switch_to_idle();
                                trace_dispatch_abandon(
                                    DispatchAbandonSite::IdleSignalTerminatedBlocked,
                                );
                                unsafe {
                                    crate::memory::process_memory::switch_to_kernel_page_table();
                                }
                                return;
                            }
                            crate::signal::delivery::SignalDeliveryResult::Delivered => {
                                note_fact(DispatchLogFact::SignalDeliveredBlocked);
                            }
                            crate::signal::delivery::SignalDeliveryResult::NoAction => {}
                        }
                    } else {
                        // NO PENDING SIGNALS: Resume at kernel HLT loop
                        if let Some(ref thread) = process.main_thread {
                            // Restore kernel context
                            saved_regs.rax = thread.context.rax;
                            saved_regs.rbx = thread.context.rbx;
                            saved_regs.rcx = thread.context.rcx;
                            saved_regs.rdx = thread.context.rdx;
                            saved_regs.rsi = thread.context.rsi;
                            saved_regs.rdi = thread.context.rdi;
                            saved_regs.rbp = thread.context.rbp;
                            saved_regs.r8 = thread.context.r8;
                            saved_regs.r9 = thread.context.r9;
                            saved_regs.r10 = thread.context.r10;
                            saved_regs.r11 = thread.context.r11;
                            saved_regs.r12 = thread.context.r12;
                            saved_regs.r13 = thread.context.r13;
                            saved_regs.r14 = thread.context.r14;
                            saved_regs.r15 = thread.context.r15;

                            // Restore interrupt frame with KERNEL context
                            unsafe {
                                interrupt_frame.as_mut().update(|frame| {
                                    frame.instruction_pointer =
                                        x86_64::VirtAddr::new(thread.context.rip);
                                    frame.stack_pointer = x86_64::VirtAddr::new(thread.context.rsp);
                                    frame.cpu_flags =
                                        x86_64::registers::rflags::RFlags::from_bits_truncate(
                                            thread.context.rflags,
                                        );
                                    // CRITICAL: Use kernel code segment (CS=0x08)
                                    frame.code_segment = crate::gdt::kernel_code_selector();
                                    frame.stack_segment = crate::gdt::kernel_data_selector();
                                });
                            }

                            // #772/#775: the aggregate counter and fixed atomic
                            // strand ledger cover this completed restore.
                            crate::trace_count!(DISPATCH_KERNEL_RESTORE_TOTAL);
                            crate::task::dispatch_strand_census::note_restore(thread_id);

                            // Update TSS RSP0 for the thread's kernel stack
                            if let Some(kernel_stack_top) = thread.kernel_stack_top {
                                crate::per_cpu::update_tss_rsp0(kernel_stack_top.as_u64());
                            }
                        }

                        // CRITICAL: Switch CR3 IMMEDIATELY when returning to kernel mode!
                        // The kernel code (e.g., waitpid HLT loop) will access userspace memory
                        // (like the wstatus pointer). Without switching CR3 here, we'd be using
                        // the previous process's page tables and get a page fault.
                        unsafe {
                            use x86_64::registers::control::{Cr3, Cr3Flags};
                            use x86_64::structures::paging::PhysFrame;
                            use x86_64::PhysAddr;
                            Cr3::write(
                                PhysFrame::containing_address(PhysAddr::new(process_cr3)),
                                Cr3Flags::empty(),
                            );
                        }
                    }

                    // Set up CR3 for the process's page table
                    unsafe {
                        // Tell timer_entry.asm to switch CR3 before IRETQ
                        crate::per_cpu::set_next_cr3(process_cr3);

                        // Update saved_process_cr3 for future timer interrupts
                        core::arch::asm!(
                            "mov gs:[80], {}",
                            in(reg) process_cr3,
                            options(nostack, preserves_flags)
                        );
                    }
                }
            }
        } else {
            // CRITICAL: Cannot acquire lock to restore kernel context
            // This is a fatal error - we cannot switch to this thread without its context
            // Roll back the committed dispatch and re-arm rescheduling.
            scheduler::abort_dispatch_and_resume(thread_id, resume_thread_id);
            trace_dispatch_abandon(DispatchAbandonSite::RollbackKernelContextLock);
            scheduler::set_need_resched();
            return;
        }
    } else {
        // Restore userspace thread context

        // Pass the process_manager_guard to avoid double-lock
        restore_userspace_thread_context(
            thread_id,
            resume_thread_id,
            saved_regs,
            interrupt_frame,
            process_manager_guard,
        );
    }
}

/// Set up interrupt frame to return to idle loop
pub(crate) fn setup_idle_return(interrupt_frame: &mut InterruptStackFrame) {
    // CRITICAL: Get the idle thread's actual kernel stack from the scheduler
    // Do NOT use per_cpu::kernel_stack_top() because that gets updated during
    // context switches and may point to a different thread's stack!
    let idle_stack = scheduler::with_scheduler(|sched| {
        let idle_id = sched.idle_thread();
        sched
            .get_thread(idle_id)
            .and_then(|t| t.kernel_stack_top.map(|v| v.as_u64()))
    })
    .flatten()
    .unwrap_or_else(|| {
        note_fact(DispatchLogFact::IdleStackMissing);
        crate::per_cpu::kernel_stack_top() // Fallback, but this is wrong
    });

    unsafe {
        interrupt_frame.as_mut().update(|frame| {
            frame.code_segment = crate::gdt::kernel_code_selector();
            frame.stack_segment = crate::gdt::kernel_data_selector();
            frame.instruction_pointer = x86_64::VirtAddr::new(idle_loop as *const () as u64);
            // CRITICAL: Set both INTERRUPT_FLAG (bit 9) AND reserved bit 1 (always required)
            // 0x202 = INTERRUPT_FLAG (0x200) | reserved bit 1 (0x002)
            // Without bit 1, IRETQ behavior is undefined per Intel spec.
            let flags_ptr =
                &mut frame.cpu_flags as *mut x86_64::registers::rflags::RFlags as *mut u64;
            *flags_ptr = 0x202;

            frame.stack_pointer = x86_64::VirtAddr::new(idle_stack);
        });

        // NOTE: We do NOT switch page tables here. The userspace process page table
        // already has all kernel mappings (code, stacks, etc.) so we can run
        // kernel code (idle loop) with it.

        // CRITICAL FIX: Clear PREEMPT_ACTIVE when switching to idle!
        // PREEMPT_ACTIVE (bit 28) is set during syscall return to protect register
        // restoration. When we switch to the idle thread, we MUST clear it - otherwise
        // can_schedule() will return false and block all future scheduling attempts,
        // leaving the system stuck in the idle loop unable to switch to ready threads.
        crate::per_cpu::clear_preempt_active();
    }
}

/// Set up interrupt frame to return to kernel thread
fn setup_kernel_thread_return(
    thread_id: u64,
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
) {
    // Get thread info - restore the 15 saved general-purpose registers plus the
    // frame, not just a few.
    //
    // The name is deliberately NOT read here. Cloning it allocated a `String`
    // on each kernel-thread dispatch -- a heap-allocator lock taken from
    // interrupt context, which ordinary thread context holds with interrupts
    // enabled -- for a value this function then dropped unused. `Context` is
    // plain registers, so cloning it performs no allocation.
    //
    // This function is NOT lock-free, and an earlier revision of the #791 record
    // wrongly said the dispatch path had "no lock left to spin on". The call
    // below takes SCHEDULER.lock() -- a spin::Mutex -- through
    // scheduler::with_thread_mut. What keeps that acquisition out of the #791
    // failure class is the interrupt state of its holders, not their absence:
    // with_thread_mut takes the lock inside without_interrupts, so no holder can
    // be preempted while holding it and the byte spun on here always has a
    // runnable owner. The hazard #791 hit was the opposite shape -- a mutex this
    // path reads with IF=0 that ordinary thread context holds with interrupts
    // ENABLED. Any future lock added to this path must have the masked-holder
    // property or it re-arms #791.
    // claim-lint:ok: the deadlock this hazard class produced is issue #791 and
    // docs/planning/green-program/sockets/787-REGRESSION-RCA-2026-09-04.md.
    let thread_info = scheduler::with_thread_mut(thread_id, |thread| thread.context.clone());

    if let Some(context) = thread_info {
        unsafe {
            interrupt_frame.as_mut().update(|frame| {
                frame.instruction_pointer = x86_64::VirtAddr::new(context.rip);
                frame.stack_pointer = x86_64::VirtAddr::new(context.rsp);
                frame.code_segment = crate::gdt::kernel_code_selector();
                frame.stack_segment = crate::gdt::kernel_data_selector();
                frame.cpu_flags =
                    x86_64::registers::rflags::RFlags::from_bits_truncate(context.rflags);
            });

            // Restore ALL general purpose registers from saved context
            saved_regs.rax = context.rax;
            saved_regs.rbx = context.rbx;
            saved_regs.rcx = context.rcx;
            saved_regs.rdx = context.rdx;
            saved_regs.rsi = context.rsi;
            saved_regs.rdi = context.rdi;
            saved_regs.rbp = context.rbp;
            saved_regs.r8 = context.r8;
            saved_regs.r9 = context.r9;
            saved_regs.r10 = context.r10;
            saved_regs.r11 = context.r11;
            saved_regs.r12 = context.r12;
            saved_regs.r13 = context.r13;
            saved_regs.r14 = context.r14;
            saved_regs.r15 = context.r15;
        }

        // Switch to master kernel PML4 for running kernel threads
        // This ensures kernel threads have access to all kernel mappings
        unsafe {
            crate::memory::process_memory::switch_to_kernel_page_table();
        }

        // Hardware memory fence to ensure all writes to interrupt frame and saved_regs
        // are visible before IRETQ reads them. This is critical for TCG mode
        // where software emulation may have different memory ordering semantics.
        // Using a full fence (mfence) rather than just compiler fence to force
        // actual CPU store completion.
        core::sync::atomic::fence(core::sync::atomic::Ordering::SeqCst);
    } else {
        note_fact(DispatchLogFact::KernelThreadInfoMissing);
    }
}

/// Restore userspace thread context
fn restore_userspace_thread_context(
    thread_id: u64,
    resume_thread_id: u64,
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
    process_manager_guard: Option<crate::process::TryProcessManagerGuard>,
) {
    // Check if this thread has ever run before
    let has_started =
        scheduler::with_thread_mut(thread_id, |thread| thread.has_started).unwrap_or(false);

    if !has_started {
        // CRITICAL: This is a brand new thread that has never run
        // We need to set up for its first entry to userspace
        // For first run, we need to set up the interrupt frame to jump to userspace
        match setup_first_userspace_entry(
            thread_id,
            interrupt_frame,
            saved_regs,
            process_manager_guard,
        ) {
            FirstUserspaceEntry::Installed => {
                scheduler::with_thread_mut(thread_id, |thread| {
                    thread.has_started = true;
                });
            }
            FirstUserspaceEntry::Aborted => {
                FIRST_USERSPACE_ENTRY_ABORT_COUNT.fetch_add(1, Ordering::Relaxed);

                scheduler::abort_dispatch_and_resume(thread_id, resume_thread_id);
                trace_dispatch_abandon(DispatchAbandonSite::RollbackFirstEntry);
                scheduler::set_need_resched();
            }
        }
        return;
    }

    // Thread has run before - do normal context restore

    // CRITICAL: Use the passed-in guard if available, otherwise try to acquire one.
    // The guard is passed from check_need_resched_and_switch to avoid double-lock deadlock.
    // If we're called from elsewhere without a guard, try_manager() as fallback.
    let guard_option = process_manager_guard.or_else(|| crate::process::try_manager());

    // Track if signal termination happened (for parent notification after borrow ends)
    let mut signal_termination_info: Option<crate::signal::delivery::ParentNotification> = None;

    if let Some(mut manager_guard) = guard_option {
        if let Some(ref mut manager) = *manager_guard {
            if let Some((pid, process)) = manager.find_process_by_thread_mut(thread_id) {
                // Get CR3 before borrowing main_thread mutably
                if refuse_unpublished_dispatch(process, thread_id, pid.as_u64()) {
                    crate::task::scheduler::set_need_resched();
                    setup_idle_return(interrupt_frame);
                    crate::task::scheduler::switch_to_idle();
                    trace_dispatch_abandon(DispatchAbandonSite::IdleUnpublishedUser);
                    crate::task::scheduler::requeue_refused_dispatch(thread_id);
                    return;
                }
                let process_cr3 = process.cr3_value();

                if let Some(ref mut thread) = process.main_thread {
                    if thread.privilege == ThreadPrivilege::User {
                        if let Err(error) =
                            restore_userspace_context(thread, interrupt_frame, saved_regs)
                        {
                            if matches!(error, RestoreError::KernelFrame) {
                                KERNEL_FRAME_RESTORE_REFUSED.fetch_add(1, Ordering::Relaxed);
                            }
                            // Corrupted process state. Terminate the process and switch to idle.
                            thread.set_terminated();
                            process.terminate(-11); // SIGSEGV equivalent
                            crate::task::scheduler::with_thread_mut(thread_id, |sched_thread| {
                                sched_thread.set_terminated();
                            });
                            crate::task::scheduler::set_need_resched();
                            setup_idle_return(interrupt_frame);
                            crate::task::scheduler::switch_to_idle();
                            trace_dispatch_abandon(DispatchAbandonSite::IdleRestoreError);
                        } else {
                            // CRITICAL: Defer CR3 switch to timer_entry.asm before IRETQ
                            // We do NOT switch CR3 here because:
                            // 1. Kernel can run on process page tables (they have kernel mappings)
                            // 2. timer_entry.asm will perform the actual switch before IRETQ (line 324)
                            // 3. Switching here would cause DOUBLE CR3 write (flush TLB twice)
                            //
                            // Instead, we set next_cr3 and saved_process_cr3 to communicate
                            // the target CR3 to the assembly code.
                            if let Some(cr3_value) = process_cr3 {
                                unsafe {
                                    // Tell timer_entry.asm to switch CR3 before IRETQ
                                    crate::per_cpu::set_next_cr3(cr3_value);

                                    // Update saved_process_cr3 so future timer interrupts
                                    // without context switch restore the correct CR3
                                    core::arch::asm!(
                                        "mov gs:[80], {}",
                                        in(reg) cr3_value,
                                        options(nostack, preserves_flags)
                                    );
                                }
                            } else {
                                USERSPACE_DISPATCH_NO_CR3_REFUSED.fetch_add(1, Ordering::Relaxed);

                                // With next_cr3 == 0, timer_entry.asm takes its fallback path
                                // and restores the interrupted process's address space. Refuse
                                // to finish this user-mode return with that wrong CR3 active.
                                thread.set_terminated();
                                crate::task::scheduler::with_thread_mut(
                                    thread_id,
                                    |sched_thread| {
                                        sched_thread.set_terminated();
                                    },
                                );
                                crate::task::scheduler::set_need_resched();
                                setup_idle_return(interrupt_frame);
                                crate::task::scheduler::switch_to_idle();
                                trace_dispatch_abandon(DispatchAbandonSite::IdleNoCr3User);
                                return;
                            }

                            // Update TSS RSP0 for the new thread's kernel stack
                            if let Some(kernel_stack_top) = thread.kernel_stack_top {
                                crate::per_cpu::update_tss_rsp0(kernel_stack_top.as_u64());
                            } else {
                                note_fact(DispatchLogFact::UserKernelStackMissing);
                            }

                            // SIGNAL DELIVERY: Check for pending signals before returning to userspace
                            // This is the correct point to deliver signals - after context is restored
                            // but before we actually return to userspace
                            crate::signal::delivery::check_and_fire_alarm(process);
                            crate::signal::delivery::check_and_fire_itimer_real(process, 5000);

                            if crate::signal::delivery::has_deliverable_signals(process) {
                                note_fact(DispatchLogFact::SignalDeliverableUser);

                                // CRITICAL: Switch to process CR3 BEFORE delivering signal
                                // Signal delivery writes to user stack memory, which requires
                                // the process's page table to be active (not the kernel CR3).
                                // Without this, we get a page fault when trying to write the
                                // signal frame to user memory.
                                if let Some(cr3_val) = process.cr3_value() {
                                    unsafe {
                                        use x86_64::registers::control::{Cr3, Cr3Flags};
                                        use x86_64::structures::paging::PhysFrame;
                                        use x86_64::PhysAddr;
                                        Cr3::write(
                                            PhysFrame::containing_address(PhysAddr::new(cr3_val)),
                                            Cr3Flags::empty(),
                                        );
                                    }
                                }

                                // Deliver pending signals
                                let signal_result =
                                    crate::signal::delivery::deliver_pending_signals(
                                        process,
                                        interrupt_frame,
                                        saved_regs,
                                    );

                                match signal_result {
                                    crate::signal::delivery::SignalDeliveryResult::Terminated(
                                        notification,
                                    ) => {
                                        // Signal terminated the process
                                        crate::task::scheduler::set_need_resched();
                                        // Save notification for later (after manager lock is released)
                                        signal_termination_info = Some(notification);
                                        setup_idle_return(interrupt_frame);
                                        crate::task::scheduler::switch_to_idle();
                                        trace_dispatch_abandon(
                                            DispatchAbandonSite::IdleSignalTerminatedUser,
                                        );
                                        // Don't return here - fall through to handle notification
                                    }
                                    crate::signal::delivery::SignalDeliveryResult::Delivered => {
                                        // Signal was delivered and frame was modified
                                        if process.is_terminated() {
                                            // Process was terminated (somehow?)
                                            crate::task::scheduler::set_need_resched();
                                            setup_idle_return(interrupt_frame);
                                            crate::task::scheduler::switch_to_idle();
                                            trace_dispatch_abandon(
                                                DispatchAbandonSite::IdleProcessTerminatedUser,
                                            );
                                        }
                                    }
                                    crate::signal::delivery::SignalDeliveryResult::NoAction => {}
                                }
                            }
                        }
                    }
                }
            }

            // Now process borrow has ended - notify parent if signal terminated a child
            // Drop manager guard first to avoid deadlock when notifying parent
            drop(manager_guard);
            if let Some(notification) = signal_termination_info {
                crate::signal::delivery::notify_parent_of_termination_deferred(&notification);
            }
        }
    }
}

/// Set up interrupt frame for first entry to userspace
fn setup_first_userspace_entry(
    thread_id: u64,
    interrupt_frame: &mut InterruptStackFrame,
    saved_regs: &mut SavedRegisters,
    process_manager_guard: Option<crate::process::TryProcessManagerGuard>,
) -> FirstUserspaceEntry {
    // Phase 1: resolve every fallible dependency before touching the return frame.
    let mut manager_guard = match process_manager_guard.or_else(crate::process::try_manager) {
        Some(guard) if guard.is_some() => guard,
        _ => return FirstUserspaceEntry::Aborted,
    };
    let (_, process) = match manager_guard
        .as_mut()
        .and_then(|manager| manager.find_process_by_thread_mut(thread_id))
    {
        Some(found) => found,
        None => return FirstUserspaceEntry::Aborted,
    };
    let cr3_value = match process.cr3_value() {
        Some(value) => value,
        None => return FirstUserspaceEntry::Aborted,
    };
    let thread = match process.main_thread.as_ref() {
        Some(thread) => thread,
        None => return FirstUserspaceEntry::Aborted,
    };
    let kernel_stack_top = match thread.kernel_stack_top {
        Some(stack_top) => stack_top,
        None => return FirstUserspaceEntry::Aborted,
    };
    let entry_rip = thread.context.rip;
    let user_rsp = thread.context.rsp;
    drop(manager_guard);

    unsafe {
        crate::per_cpu::set_next_cr3(cr3_value);
        core::arch::asm!(
            "mov gs:[80], {}",
            in(reg) cr3_value,
            options(nostack, preserves_flags)
        );
    }
    crate::per_cpu::update_tss_rsp0(kernel_stack_top.as_u64());

    // Phase 2: commit the first userspace frame only after CR3 and RSP0 are installed.
    unsafe {
        interrupt_frame.as_mut().update(|frame| {
            // Set instruction pointer to entry point
            frame.instruction_pointer = VirtAddr::new(entry_rip);

            // Set stack pointer to the user stack EXACTLY as process creation
            // computed it -- do NOT realign. Breenix's userspace entry point
            // (_start, libs/libbreenix/src/runtime.rs) is reached via IRETQ
            // directly, not a `call`: there is no implicit return-address
            // push for a "(rsp % 16) == 8 at entry" C-ABI-call convention to
            // compensate for. _start's naked asm reads argc directly from
            // [rsp] (`mov rdi, rsp`) before it does anything else, and its
            // own `and rsp, -16` re-aligns ONLY for its own internal `call`
            // to runtime_entry, entirely after that read. The kernel must
            // hand user_rsp over unmodified: 16-byte aligned, pointing at
            // argc, exactly as ProcessManager::setup_argv_on_stack computed
            // it (or, for a process created with no argv, exactly as
            // create_main_thread's `stack_top - 16` computed it, which is
            // also already 16-byte aligned).
            //
            // A previous version of this line forcibly misaligned RSP by 8
            // bytes here ("Ensure (rsp % 16) == 8"), silently corrupting the
            // exact byte offset _start reads argc from for every
            // argv-carrying process. It was never visible before #713
            // because every earlier x86 process-creation path left the
            // stack region above RSP as fresh, zeroed memory with no real
            // argc/argv written there at all -- reading "argc" 8 bytes off
            // from a run of zero bytes still read as zero either way.
            // #713's spawn() is the first x86 caller to write real,
            // non-zero argc/argv data there, which is what made the
            // corruption visible: bsshd panicked on first entry with
            // "capacity overflow" in std::sys::args::unix::args(), reading
            // a garbage argc that was actually a misaligned read spanning
            // part of argc and part of argv[0]'s pointer bytes.
            frame.stack_pointer = VirtAddr::new(user_rsp);

            // Set code segment to user code (Ring 3)
            frame.code_segment = crate::gdt::user_code_selector();

            // Set stack segment to user data (Ring 3)
            frame.stack_segment = crate::gdt::user_data_selector();

            // Set CPU flags: IF=1 (interrupts enabled), bit 1=1 (reserved)
            let flags_ptr =
                &mut frame.cpu_flags as *mut x86_64::registers::rflags::RFlags as *mut u64;
            *flags_ptr = 0x202; // Bit 1=1 (required), IF=1 (bit 9)
        });
    }

    // CRITICAL: Zero all general-purpose registers for security and determinism
    // This ensures userspace starts with a clean register state
    saved_regs.rax = 0;
    saved_regs.rbx = 0;
    saved_regs.rcx = 0;
    saved_regs.rdx = 0;
    saved_regs.rsi = 0;
    saved_regs.rdi = 0;
    saved_regs.rbp = 0;
    saved_regs.r8 = 0;
    saved_regs.r9 = 0;
    saved_regs.r10 = 0;
    saved_regs.r11 = 0;
    saved_regs.r12 = 0;
    saved_regs.r13 = 0;
    saved_regs.r14 = 0;
    saved_regs.r15 = 0;

    FirstUserspaceEntry::Installed
}

/// Check and deliver pending signals for the current thread
///
/// Called when returning to userspace without a context switch (same thread continues).
/// This ensures signals are delivered promptly even when the same thread keeps running.
fn check_and_deliver_signals_for_current_thread(
    saved_regs: &mut SavedRegisters,
    interrupt_frame: &mut InterruptStackFrame,
) {
    // Get current thread ID
    let current_thread_id = match scheduler::current_thread_id() {
        Some(id) => id,
        None => return,
    };

    // 0 is the no-thread sentinel, not a live thread id, so there is no
    // process to deliver signals to.
    if current_thread_id == 0 {
        return;
    }

    // Try to acquire process manager lock
    let mut manager_guard = match crate::process::try_manager() {
        Some(guard) => guard,
        None => return, // Lock held, skip signal check this time
    };

    // Track if signal termination happened (for parent notification after borrow ends)
    let mut signal_termination_info: Option<crate::signal::delivery::ParentNotification> = None;

    if let Some(ref mut manager) = *manager_guard {
        // Find the process for this thread
        if let Some((_pid, process)) = manager.find_process_by_thread_mut(current_thread_id) {
            // Note: Debug logging removed from hot path - use GDB if debugging is needed
            crate::signal::delivery::check_and_fire_alarm(process);
            crate::signal::delivery::check_and_fire_itimer_real(process, 5000);

            if crate::signal::delivery::has_deliverable_signals(process) {
                // Switch to process's page table for signal delivery
                if let Some(cr3_val) = process.cr3_value() {
                    unsafe {
                        use x86_64::registers::control::{Cr3, Cr3Flags};
                        use x86_64::structures::paging::PhysFrame;
                        use x86_64::PhysAddr;
                        Cr3::write(
                            PhysFrame::containing_address(PhysAddr::new(cr3_val)),
                            Cr3Flags::empty(),
                        );
                    }
                }

                // Deliver signals
                let signal_result = crate::signal::delivery::deliver_pending_signals(
                    process,
                    interrupt_frame,
                    saved_regs,
                );

                match signal_result {
                    crate::signal::delivery::SignalDeliveryResult::Terminated(notification) => {
                        // Signal terminated the process
                        crate::task::scheduler::set_need_resched();
                        signal_termination_info = Some(notification);
                        setup_idle_return(interrupt_frame);
                        crate::task::scheduler::switch_to_idle();
                        trace_dispatch_abandon(DispatchAbandonSite::IdleSignalTerminatedOnReturn);
                        // Don't return here - fall through to handle notification
                    }
                    crate::signal::delivery::SignalDeliveryResult::Delivered => {
                        if process.is_terminated() {
                            crate::task::scheduler::set_need_resched();
                            setup_idle_return(interrupt_frame);
                            crate::task::scheduler::switch_to_idle();
                            trace_dispatch_abandon(
                                DispatchAbandonSite::IdleProcessTerminatedOnReturn,
                            );
                        }
                    }
                    crate::signal::delivery::SignalDeliveryResult::NoAction => {}
                }
            }
        }
        // process borrow has ended here

        // Drop manager guard first to avoid deadlock when notifying parent
        drop(manager_guard);

        // Notify parent if signal terminated a child
        if let Some(notification) = signal_termination_info {
            crate::signal::delivery::notify_parent_of_termination_deferred(&notification);
        }
    }
}

/// Simple idle loop - made pub for exception handlers that need to jump to idle
pub fn idle_loop() -> ! {
    loop {
        // #775 round 3 (N1): this is the idle loop x86 actually runs, and the
        // TOP of its body is the position that runs on every idle dispatch.
        // Once any thread reaches Ring 3, is_ring3_confirmed() latches and
        // setup_idle_return rewrites the frame to restart this function, so the
        // code after enable_and_hlt() below runs only when the halt returns
        // WITHOUT the timer handler switching away. main.rs's idle_thread_fn is
        // the idle task's stored ENTRY POINT and is never dispatched at all,
        // which is why the heartbeat used to be certified-but-dead there.
        // claim-lint:ok: #775 round 3 finding N1; the cadence this position
        // produces is measured in
        // docs/planning/green-program/sockets/775-CENSUS-EQUIVALENCE-2026-09-04.md
        //
        // The call is one rate-limited comparison of a monotonic timestamp,
        // made outside any interrupt with IF=1 (this loop's other housekeeping
        // already prints from here), and the callee refuses unless interrupts
        // are enabled, so the COM2 lock it may take is never acquired from a
        // masked context. Cadence is only as good as how often the CPU idles:
        // a wedge that spins instead of idling stops it, which the census
        // consumer and 775-CENSUS-EQUIVALENCE-2026-09-04.md both state.
        // claim-lint:ok: the interrupts-enabled refusal is in
        // kernel/src/task/dispatch_strand_census.rs report_heartbeat_if_due().
        crate::task::report_dispatch_strand_census_heartbeat();
        crate::task::process_task::reclaim_deferred_process_resources();
        // P6a PR-2, review finding B2. Retention at quiesce has to be sampled
        // from a context that exists AFTER every userspace thread is gone and
        // after the drain above has had passes to run; the idle loop is the only
        // such context on x86, because the strand reporter fires once before
        // userspace and the heartbeat's procfs reader is an aarch64 userspace
        // program. Boot-test profile only. On the production x86 path this is
        // compiled out entirely, and inside the profile it is one relaxed atomic
        // load per idle pass until it emits its single line: no lock, no
        // allocation, and nothing on the context-switch path itself.
        #[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
        crate::tracing::providers::teardown::x86_settled_tombstone_census();
        crate::task::scheduler::reclaim_terminated_threads();
        // Try to flush any pending IRQ logs while idle
        crate::irq_log::flush_local_try();
        // CRITICAL: Use enable_and_hlt() instead of just hlt()
        // This atomically enables interrupts and halts, preventing race conditions
        // where interrupts might be disabled when we enter this loop.
        // Without this, if interrupts are disabled, HLT would hang forever.
        x86_64::instructions::interrupts::enable_and_hlt();
    }
}

// REMOVED: get_next_page_table() is no longer needed since CR3 switching
// happens immediately during context switch in the scheduler
