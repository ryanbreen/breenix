#[cfg(target_arch = "x86_64")]
pub(crate) mod dispatch_boot_facts;
use alloc::boxed::Box;
use core::{
    future::Future,
    pin::Pin,
    sync::atomic::{AtomicU64, Ordering},
    task::{Context, Poll},
};

// Core task/thread modules - shared across architectures
#[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
pub mod boot_resume_oracle;
pub mod completion;
#[cfg(target_arch = "x86_64")]
pub(crate) mod dispatch_strand_census;
#[cfg(target_arch = "x86_64")]
pub fn report_dispatch_strand_census_heartbeat() {
    dispatch_strand_census::report_heartbeat_if_due();
}
#[cfg(target_arch = "x86_64")]
pub fn start_dispatch_strand_census_kthread() {
    dispatch_strand_census::start_census_kthread();
}
pub mod executor;
pub mod exit_tally;
pub mod thread;
pub mod waitqueue;

// Architecture-specific context switching
// Note: context.rs contains x86_64 assembly - ARM64 uses separate implementation
#[cfg(target_arch = "x86_64")]
pub mod context;

// Scheduler and preemption - works on both x86_64 and aarch64
// (requires architecture-specific interrupt control, provided by arch_impl)
pub mod scheduler;
// Registered unconditionally: the in-path recorders it exposes are called from
// the aarch64 dispatch path in every profile, and compile to empty inline
// no-ops without `percpu_stack_custody_oracle`.
pub mod percpu_stack_oracle;
#[cfg(feature = "boot_tests")]
pub mod ret_zero_pc_oracle;
#[cfg(feature = "boot_tests")]
pub mod strand_oracle;
/// #766's wake-to-dispatch latency leg. Boot-tests only: it makes 8 threads
/// CPU-bound on purpose, which is not something a shipped kernel should do.
#[cfg(feature = "boot_tests")]
pub mod timer_wake_oracle;

// Kernel threads and workqueues - work on both x86_64 and aarch64
// Uses architecture-independent types and conditional interrupt control
pub mod kthread;
#[cfg(feature = "testing")]
pub mod kthread_tests;
#[cfg(any(feature = "testing", feature = "boot_tests"))]
pub mod softirq_tests;
pub mod softirqd;
pub mod workqueue;
#[cfg(feature = "testing")]
pub mod workqueue_tests;

// Process-related modules
// Note: process_context is available for both architectures as SavedRegisters
// is architecture-specific but needed for signal delivery on both
pub mod process_context;
// process_task uses architecture-independent types (ProcessId, scheduler, Thread)
pub mod process_task;
// spawn.rs provides thread spawning functionality for both architectures
// Uses architecture-specific cfg guards internally for VirtAddr, ELF loading, and TLS
pub mod spawn;

// Re-export kthread public API for kernel-wide use
// These are intentionally available but may not be called yet
#[allow(unused_imports)]
pub use kthread::{
    kthread_exit, kthread_join, kthread_park, kthread_run, kthread_should_stop, kthread_stop,
    kthread_unpark, KthreadError, KthreadHandle,
};

// Re-export workqueue public API for kernel-wide use
#[allow(unused_imports)]
pub use workqueue::{
    flush_system_workqueue, init_workqueue, schedule_work, schedule_work_fn, Work, Workqueue,
    WorkqueueFlags,
};

// Re-export softirqd public API for kernel-wide use
#[allow(unused_imports)]
pub use softirqd::{
    init_softirq, raise_softirq, register_softirq_handler, SoftirqHandler, SoftirqType,
};

#[allow(dead_code)] // Used in kernel_main_continue (conditionally compiled)
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct TaskId(u64);

impl TaskId {
    #[allow(dead_code)] // Used in kernel_main_continue (conditionally compiled)
    fn new() -> Self {
        static NEXT_ID: AtomicU64 = AtomicU64::new(0);
        TaskId(NEXT_ID.fetch_add(1, Ordering::Relaxed))
    }
}

#[allow(dead_code)] // Used in kernel_main_continue (conditionally compiled)
pub struct Task {
    id: TaskId,
    future: Pin<Box<dyn Future<Output = ()>>>,
}

impl Task {
    #[allow(dead_code)] // Used in kernel_main_continue (conditionally compiled)
    pub fn new(future: impl Future<Output = ()> + 'static) -> Task {
        Task {
            id: TaskId::new(),
            future: Box::pin(future),
        }
    }

    #[allow(dead_code)] // Used in kernel_main_continue (conditionally compiled)
    fn poll(&mut self, context: &mut Context) -> Poll<()> {
        self.future.as_mut().poll(context)
    }
}
