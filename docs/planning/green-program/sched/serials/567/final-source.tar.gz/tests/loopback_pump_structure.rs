use std::fs;
use std::path::{Path, PathBuf};

fn repo_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
}

fn repo_text(relative: &str) -> String {
    fs::read_to_string(repo_root().join(relative))
        .unwrap_or_else(|_| panic!("read repository file {relative}"))
}

fn code_mask(source: &str) -> Vec<bool> {
    let bytes = source.as_bytes();
    let mut mask = vec![true; bytes.len()];
    let mut line_comment = false;
    let mut block_comment_depth = 0usize;
    let mut string = false;
    let mut character = false;
    let mut raw_string_hashes = None;
    let mut escaped = false;
    let mut index = 0usize;

    while index < bytes.len() {
        let byte = bytes[index];
        if line_comment {
            if byte == b'\n' {
                line_comment = false;
            } else {
                mask[index] = false;
            }
            index += 1;
            continue;
        }
        if block_comment_depth != 0 {
            mask[index] = false;
            if byte == b'/' && bytes.get(index + 1) == Some(&b'*') {
                mask[index + 1] = false;
                block_comment_depth += 1;
                index += 2;
            } else if byte == b'*' && bytes.get(index + 1) == Some(&b'/') {
                mask[index + 1] = false;
                block_comment_depth -= 1;
                index += 2;
            } else {
                index += 1;
            }
            continue;
        }
        if let Some(hashes) = raw_string_hashes {
            mask[index] = false;
            if byte == b'"'
                && bytes
                    .get(index + 1..index + 1 + hashes)
                    .is_some_and(|suffix| suffix.iter().all(|byte| *byte == b'#'))
            {
                mask[index + 1..=index + hashes].fill(false);
                raw_string_hashes = None;
                index += hashes + 1;
            } else {
                index += 1;
            }
            continue;
        }
        if string || character {
            mask[index] = false;
            if escaped {
                escaped = false;
            } else if byte == b'\\' {
                escaped = true;
            } else if (string && byte == b'"') || (character && byte == b'\'') {
                string = false;
                character = false;
            }
            index += 1;
            continue;
        }
        if byte == b'/' && bytes.get(index + 1) == Some(&b'/') {
            mask[index] = false;
            mask[index + 1] = false;
            line_comment = true;
            index += 2;
            continue;
        }
        if byte == b'/' && bytes.get(index + 1) == Some(&b'*') {
            mask[index] = false;
            mask[index + 1] = false;
            block_comment_depth = 1;
            index += 2;
            continue;
        }
        if byte == b'r' {
            let mut quote = index + 1;
            while bytes.get(quote) == Some(&b'#') {
                quote += 1;
            }
            if bytes.get(quote) == Some(&b'"') {
                mask[index..=quote].fill(false);
                raw_string_hashes = Some(quote - index - 1);
                index = quote + 1;
                continue;
            }
        }
        if byte == b'"' {
            mask[index] = false;
            string = true;
            index += 1;
            continue;
        }
        if byte == b'\'' {
            let plain_char = bytes.get(index + 2) == Some(&b'\'');
            let escaped_char =
                bytes.get(index + 1) == Some(&b'\\') && bytes.get(index + 3) == Some(&b'\'');
            if plain_char || escaped_char {
                mask[index] = false;
                character = true;
            }
        }
        index += 1;
    }
    mask
}

fn identifier_byte(byte: u8) -> bool {
    byte == b'_' || byte.is_ascii_alphanumeric() || !byte.is_ascii()
}

fn identifier_offsets(source: &str, mask: &[bool], identifier: &str) -> Vec<usize> {
    let bytes = source.as_bytes();
    source
        .match_indices(identifier)
        .filter_map(|(offset, _)| {
            let end = offset + identifier.len();
            (mask.get(offset).copied().unwrap_or(false)
                && !offset
                    .checked_sub(1)
                    .and_then(|before| bytes.get(before))
                    .is_some_and(|byte| identifier_byte(*byte))
                && !bytes.get(end).is_some_and(|byte| identifier_byte(*byte)))
            .then_some(offset)
        })
        .collect()
}

fn braced_block<'a>(source: &'a str, mask: &[bool], start: usize) -> Option<&'a str> {
    let (open, close) = braced_block_span(source, mask, start)?;
    Some(&source[open..=close])
}

fn braced_block_span(source: &str, mask: &[bool], start: usize) -> Option<(usize, usize)> {
    let bytes = source.as_bytes();
    let open = (start..bytes.len()).find(|index| mask[*index] && bytes[*index] == b'{')?;
    let mut depth = 0usize;
    for index in open..bytes.len() {
        if !mask[index] {
            continue;
        }
        match bytes[index] {
            b'{' => depth += 1,
            b'}' => {
                depth = depth.checked_sub(1)?;
                if depth == 0 {
                    return Some((open, index));
                }
            }
            _ => {}
        }
    }
    None
}

fn function_open_brace(source: &str, mask: &[bool], start: usize) -> Option<usize> {
    let bytes = source.as_bytes();
    let mut parentheses = 0usize;
    let mut brackets = 0usize;
    for index in start..bytes.len() {
        if !mask[index] {
            continue;
        }
        match bytes[index] {
            b'(' => parentheses += 1,
            b')' => parentheses = parentheses.checked_sub(1)?,
            b'[' => brackets += 1,
            b']' => brackets = brackets.checked_sub(1)?,
            b'{' if parentheses == 0 && brackets == 0 => return Some(index),
            b';' if parentheses == 0 && brackets == 0 => return None,
            _ => {}
        }
    }
    None
}

#[derive(Debug)]
struct FunctionSpan {
    name: String,
    open: usize,
    close: usize,
}

fn function_spans(source: &str) -> Vec<FunctionSpan> {
    let mask = code_mask(source);
    let bytes = source.as_bytes();
    let mut spans = Vec::new();
    for function in identifier_offsets(source, &mask, "fn") {
        let mut cursor = function + 2;
        while cursor < bytes.len() && (!mask[cursor] || bytes[cursor].is_ascii_whitespace()) {
            cursor += 1;
        }
        let name_start = cursor;
        while cursor < bytes.len() && mask[cursor] && identifier_byte(bytes[cursor]) {
            cursor += 1;
        }
        if cursor == name_start {
            continue;
        }
        let Some(brace) = function_open_brace(source, &mask, cursor) else {
            continue;
        };
        let Some((open, close)) = braced_block_span(source, &mask, brace) else {
            continue;
        };
        spans.push(FunctionSpan {
            name: source[name_start..cursor].to_string(),
            open,
            close,
        });
    }
    spans
}

fn function_body<'a>(source: &'a str, name: &str) -> Option<&'a str> {
    function_spans(source)
        .into_iter()
        .find(|span| span.name == name)
        .map(|span| &source[span.open..=span.close])
}

fn normalized_code(fragment: &str) -> String {
    let mask = code_mask(fragment);
    let kept: Vec<u8> = fragment
        .bytes()
        .zip(mask)
        .filter_map(|(byte, code)| code.then_some(byte))
        .collect();
    String::from_utf8_lossy(&kept)
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
}

fn has_identifier(source: &str, identifier: &str) -> bool {
    !identifier_offsets(source, &code_mask(source), identifier).is_empty()
}

fn code_text_offset(source: &str, text: &str) -> Option<usize> {
    let mask = code_mask(source);
    source.match_indices(text).find_map(|(offset, _)| {
        mask[offset..offset + text.len()]
            .iter()
            .all(|code| *code)
            .then_some(offset)
    })
}

fn cfg_arch_block<'a>(scope: &'a str, arch: &str) -> Option<&'a str> {
    let mask = code_mask(scope);
    let bytes = scope.as_bytes();
    for target_arch in identifier_offsets(scope, &mask, "target_arch") {
        let attribute_end =
            (target_arch..bytes.len()).find(|index| mask[*index] && bytes[*index] == b']')?;
        if !scope[target_arch..=attribute_end].contains(&format!("\"{arch}\"")) {
            continue;
        }
        let block_start =
            (attribute_end + 1..bytes.len()).find(|index| mask[*index] && bytes[*index] == b'{')?;
        return braced_block(scope, &mask, block_start);
    }
    None
}

fn test_def_block<'a>(source: &'a str, name: &str) -> Option<&'a str> {
    let name_offset = source.find(&format!("name: \"{name}\""))?;
    let mask = code_mask(source);
    let test_def = identifier_offsets(&source[..name_offset], &mask[..name_offset], "TestDef")
        .into_iter()
        .last()?;
    braced_block(source, &mask, test_def + "TestDef".len())
}

fn compact_code(fragment: &str) -> String {
    normalized_code(fragment)
        .chars()
        .filter(|character| !character.is_whitespace())
        .collect()
}

/// The balanced argument text of each `.method(...)` call in compacted code.
///
/// Used instead of matching an exact call literal so that a caller may
/// STRENGTHEN a predicate -- add a conjunct, add a second adapter -- without
/// the rule reading that as the predicate having been removed.
fn compact_call_arguments(compact: &str, method: &str) -> Vec<String> {
    let needle = format!(".{method}(");
    let bytes = compact.as_bytes();
    let mut arguments = Vec::new();
    let mut search = 0usize;
    while let Some(relative) = compact[search..].find(&needle) {
        let open = search + relative + needle.len() - 1;
        let mut depth = 0usize;
        let mut close = None;
        for index in open..bytes.len() {
            match bytes[index] {
                b'(' => depth += 1,
                b')' => {
                    let Some(next) = depth.checked_sub(1) else {
                        break;
                    };
                    depth = next;
                    if depth == 0 {
                        close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let Some(close) = close else {
            break;
        };
        arguments.push(compact[open + 1..close].to_string());
        search = close;
    }
    arguments
}

/// Whether compacted code reads the field `.field` off some receiver other
/// than `self` -- that is, off a value, which for a pin is the pin itself.
///
/// Shape rather than literal, so the closure parameter may be named anything
/// and the read may sit anywhere in the chain.
fn compact_field_access(compact: &str, field: &str) -> bool {
    let needle = format!(".{field}");
    let bytes = compact.as_bytes();
    compact.match_indices(&needle).any(|(offset, _)| {
        let after = offset + needle.len();
        if bytes.get(after).is_some_and(|byte| identifier_byte(*byte)) {
            return false;
        }
        !compact[..offset].ends_with("self")
    })
}

/// The text with the first `.method(...)` call whose argument names `needle`
/// removed, parentheses balanced.
///
/// Fixture surgery by shape rather than by literal, so a mutation leg keeps
/// deleting the adapter it is about after that adapter's predicate has been
/// strengthened, and keeps picking the right one after a second adapter of the
/// same name is added ahead of it.
fn without_call_matching(text: &str, method: &str, needle: &str) -> Option<String> {
    let mask = code_mask(text);
    let bytes = text.as_bytes();
    let opener = format!(".{method}(");
    let mut search = 0usize;
    while let Some(relative) = text[search..].find(&opener) {
        let start = search + relative;
        if !mask[start] {
            search = start + opener.len();
            continue;
        }
        let open = start + method.len() + 1;
        let mut depth = 0usize;
        let mut close = None;
        for index in open..bytes.len() {
            if !mask[index] {
                continue;
            }
            match bytes[index] {
                b'(' => depth += 1,
                b')' => {
                    depth = depth.checked_sub(1)?;
                    if depth == 0 {
                        close = Some(index);
                        break;
                    }
                }
                _ => {}
            }
        }
        let close = close?;
        if text[open..close].contains(needle) {
            return Some(format!("{}{}", &text[..start], &text[close + 1..]));
        }
        search = close;
    }
    None
}

/// The text running from `from` through the end of the statement that
/// contains `through`.
fn statement_region<'a>(
    source: &'a str,
    mask: &[bool],
    from: usize,
    through: usize,
) -> Option<&'a str> {
    let bytes = source.as_bytes();
    let end = (through..bytes.len()).find(|index| mask[*index] && bytes[*index] == b';')?;
    Some(&source[from..=end])
}

fn compact_whitespace(fragment: &str) -> String {
    fragment
        .chars()
        .filter(|character| !character.is_whitespace())
        .collect()
}

fn loop_body_after_anchor<'a>(source: &'a str, anchor: &str) -> Option<&'a str> {
    let anchor_offset = source.find(anchor)?;
    let mask = code_mask(source);
    let loop_offset = identifier_offsets(source, &mask, "loop")
        .into_iter()
        .find(|offset| *offset > anchor_offset + anchor.len())?;
    braced_block(source, &mask, loop_offset + "loop".len())
}

fn remove_call_from_loop_after_anchor(source: &str, anchor: &str, call: &str) -> Option<String> {
    let anchor_offset = source.find(anchor)?;
    let mask = code_mask(source);
    let loop_offset = identifier_offsets(source, &mask, "loop")
        .into_iter()
        .find(|offset| *offset > anchor_offset + anchor.len())?;
    let (open, close) = braced_block_span(source, &mask, loop_offset + "loop".len())?;
    let call_offset = source[open..=close].find(call)? + open;
    let mut mutated = source.to_string();
    mutated.replace_range(call_offset..call_offset + call.len(), "");
    Some(mutated)
}

fn kernel_source_files(directory: &Path, files: &mut Vec<PathBuf>) {
    for entry in fs::read_dir(directory)
        .unwrap_or_else(|error| panic!("read kernel source {}: {error}", directory.display()))
    {
        let path = entry.expect("read kernel source directory entry").path();
        if path.is_dir() {
            kernel_source_files(&path, files);
        } else if path.extension().is_some_and(|extension| extension == "rs") {
            files.push(path);
        }
    }
}

fn kernel_sources() -> Vec<(String, String)> {
    let root = repo_root();
    let mut paths = Vec::new();
    kernel_source_files(&root.join("kernel/src"), &mut paths);
    paths.sort();
    paths
        .into_iter()
        .map(|path| {
            let relative = path
                .strip_prefix(&root)
                .expect("kernel source remains under repository root")
                .display()
                .to_string();
            let source = fs::read_to_string(&path)
                .unwrap_or_else(|error| panic!("read kernel source {}: {error}", path.display()));
            (relative, source)
        })
        .collect()
}

fn joined_sources(sources: impl Iterator<Item = String>) -> String {
    sources.collect::<Vec<_>>().join("\n")
}

fn net_source_text() -> String {
    joined_sources(
        kernel_sources()
            .into_iter()
            .filter(|(path, _)| {
                path == "kernel/src/net/mod.rs" || path.starts_with("kernel/src/net/")
            })
            .map(|(_, source)| source),
    )
}

fn kernel_source_text() -> String {
    joined_sources(kernel_sources().into_iter().map(|(_, source)| source))
}

fn inject_into_function(source: &str, name: &str, code: &str) -> String {
    let span = function_spans(source)
        .into_iter()
        .find(|span| span.name == name)
        .unwrap_or_else(|| panic!("find function {name} in fixture"));
    let mut mutated = source.to_string();
    mutated.insert_str(span.open + 1, code);
    mutated
}

fn inject_into_block_after_identifier(
    source: &str,
    function_name: &str,
    identifier: &str,
    code: &str,
) -> String {
    let span = function_spans(source)
        .into_iter()
        .find(|span| span.name == function_name)
        .unwrap_or_else(|| panic!("find function {function_name} in fixture"));
    let body = &source[span.open..=span.close];
    let mask = code_mask(body);
    let identifier = identifier_offsets(body, &mask, identifier)
        .into_iter()
        .next()
        .unwrap_or_else(|| panic!("find {identifier} in {function_name}"));
    let (open, _) = braced_block_span(body, &mask, identifier)
        .unwrap_or_else(|| panic!("find block after {identifier} in {function_name}"));
    let mut mutated = source.to_string();
    mutated.insert_str(span.open + open + 1, code);
    mutated
}

fn validate_pump_producer_seam_is_single(source: &str) -> Result<(), String> {
    let producers: Vec<_> = function_spans(source)
        .into_iter()
        .filter(|span| {
            let body = &source[span.open..=span.close];
            has_identifier(body, "LOOPBACK_QUEUE") && normalized_code(body).contains(".push(")
        })
        .collect();
    if producers.len() != 1 {
        return Err(format!(
            "expected one LOOPBACK_QUEUE producer, found {}",
            producers.len()
        ));
    }
    let body = &source[producers[0].open..=producers[0].close];
    if !normalized_code(body).contains("wake_loopback_pump()") {
        return Err("loopback producer does not wake kloopbackd".to_string());
    }
    Ok(())
}

fn validate_pump_wake_is_the_only_pump_wake_path(source: &str) -> Result<(), String> {
    let wake = function_body(source, "wake_loopback_pump")
        .ok_or_else(|| "missing wake_loopback_pump".to_string())?;
    if !has_identifier(wake, "wake_thread_any_context") {
        return Err("wake_loopback_pump does not call wake_thread_any_context".to_string());
    }
    for span in function_spans(source) {
        if span.name == "wake_loopback_pump" {
            continue;
        }
        let body = &source[span.open..=span.close];
        if has_identifier(body, "wake_thread_any_context")
            && has_identifier(body, "LOOPBACK_PUMP_TID")
        {
            return Err(format!("{} is a second pump wake path", span.name));
        }
    }
    Ok(())
}

fn validate_any_context_wake_never_takes_scheduler_lock_in_interrupt_context(
    source: &str,
) -> Result<(), String> {
    let wake = function_body(source, "wake_thread_any_context")
        .ok_or_else(|| "missing wake_thread_any_context".to_string())?;
    let mask = code_mask(wake);
    let interrupt = identifier_offsets(wake, &mask, "in_interrupt")
        .into_iter()
        .next()
        .ok_or_else(|| "wake_thread_any_context has no in_interrupt arm".to_string())?;
    let arm = braced_block(wake, &mask, interrupt)
        .ok_or_else(|| "cannot parse in_interrupt arm".to_string())?;
    for forbidden in ["with_scheduler", "lock_scheduler", "SCHEDULER"] {
        if has_identifier(arm, forbidden) {
            return Err(format!("interrupt wake arm references {forbidden}"));
        }
    }
    Ok(())
}

fn validate_wake_waiting_threads_is_arch_neutral(source: &str) -> Result<(), String> {
    let wake = function_body(source, "wake_waiting_threads")
        .ok_or_else(|| "missing wake_waiting_threads".to_string())?;
    if has_identifier(wake, "target_arch") {
        return Err("wake_waiting_threads contains target_arch cfg".to_string());
    }
    if !has_identifier(wake, "wake_thread_any_context") {
        return Err("wake_waiting_threads does not call wake_thread_any_context".to_string());
    }
    Ok(())
}

fn validate_waiter_lists_are_not_drained_before_the_wake(source: &str) -> Result<(), String> {
    for name in ["wake_connection_waiters", "wake_accept_waiters"] {
        let body = function_body(source, name).ok_or_else(|| format!("missing {name}"))?;
        if normalized_code(body).contains(".drain(") {
            return Err(format!("{name} drains its waiter list before wake"));
        }
    }
    Ok(())
}

fn validate_tcp_accept_inserts_before_pending_removal(source: &str) -> Result<(), String> {
    let accept =
        function_body(source, "tcp_accept").ok_or_else(|| "missing tcp_accept".to_string())?;
    let insert = code_text_offset(accept, "connections.insert(conn_id, conn)")
        .ok_or_else(|| "tcp_accept does not insert the accepted connection".to_string())?;
    let removal = code_text_offset(accept, "listener.pending.remove(position)")
        .ok_or_else(|| "tcp_accept does not remove the matched pending entry".to_string())?;

    if insert >= removal {
        return Err("tcp_accept removes the pending entry before connection insertion".to_string());
    }
    if code_text_offset(&accept[..insert], ".pop_front()").is_some() {
        return Err("tcp_accept pops a pending entry before connection insertion".to_string());
    }
    Ok(())
}

fn validate_tcp_accept_claims_pending_in_peek_closure(source: &str) -> Result<(), String> {
    let accept =
        function_body(source, "tcp_accept").ok_or_else(|| "missing tcp_accept".to_string())?;
    let selection_start = code_text_offset(accept, "let pending = with_tcp_listeners(|listeners|")
        .ok_or_else(|| "tcp_accept does not peek under the listeners lock".to_string())?;
    let mask = code_mask(&accept);
    let (selection_open, selection_close) = braced_block_span(&accept, &mask, selection_start)
        .ok_or_else(|| "cannot parse tcp_accept pending-selection closure".to_string())?;
    let selection = &accept[selection_open..=selection_close];
    let normalized = compact_code(selection);

    for required in [
        "listener.pending.iter_mut()",
        ".find(|pending|!pending.claimed)",
        "pending.claimed=true",
        "pending.clone()",
    ] {
        if !normalized.contains(required) {
            return Err(format!(
                "tcp_accept pending-selection closure is missing {required}"
            ));
        }
    }
    Ok(())
}

fn validate_general_idle_loops_drain_loopback(
    x86_source: &str,
    aarch64_source: &str,
) -> Result<(), String> {
    let x86_idle = function_body(x86_source, "idle_thread_fn")
        .ok_or_else(|| "missing x86 idle_thread_fn".to_string())?;
    if !has_identifier(x86_idle, "drain_loopback_from_idle") {
        return Err("x86 idle_thread_fn does not use the idle drain seam".to_string());
    }

    for (anchor, description) in [
        (
            r#"serial_print!("breenix> ");"#,
            "aarch64 testing boot-thread idle loop",
        ),
        (
            r#"serial_println!("[interactive] No userspace init — idling");"#,
            "aarch64 no-userspace boot-thread idle loop",
        ),
    ] {
        let body = loop_body_after_anchor(aarch64_source, anchor)
            .ok_or_else(|| format!("missing {description}"))?;
        if !body.contains(r#"core::arch::asm!("wfi", options(nomem, nostack))"#) {
            return Err(format!("{description} is not a wfi loop"));
        }
        if !has_identifier(body, "drain_loopback_from_idle") {
            return Err(format!("{description} does not use the idle drain seam"));
        }
    }
    Ok(())
}

fn validate_drain_exclusion_is_a_typed_guard(source: &str) -> Result<(), String> {
    let drain = function_body(source, "drain_loopback_rounds")
        .ok_or_else(|| "missing drain_loopback_rounds".to_string())?;
    if has_identifier(drain, "AtomicBool") {
        return Err("drain_loopback_rounds uses AtomicBool exclusion".to_string());
    }
    if code_text_offset(source, "struct LoopbackDrainGuard").is_none() {
        return Err("missing LoopbackDrainGuard type".to_string());
    }
    let implementation = code_text_offset(source, "impl Drop for LoopbackDrainGuard")
        .ok_or_else(|| "missing LoopbackDrainGuard Drop implementation".to_string())?;
    let drop_body = function_body(&source[implementation..], "drop")
        .ok_or_else(|| "missing LoopbackDrainGuard::drop".to_string())?;
    if !has_identifier(drop_body, "LOOPBACK_DRAIN_OWNER")
        || !has_identifier(drop_body, "compare_exchange")
        || !has_identifier(drop_body, "owner")
        || !has_identifier(drop_body, "Release")
    {
        return Err("LoopbackDrainGuard::drop does not release its own owner ticket".to_string());
    }
    Ok(())
}

fn validate_drain_guard_scope_excludes_delivery(source: &str) -> Result<(), String> {
    let take = function_body(source, "take_queued_loopback_packets")
        .ok_or_else(|| "missing take_queued_loopback_packets".to_string())?;
    for required in [
        "LoopbackDrainGuard",
        "LOOPBACK_QUEUE",
        "LOOPBACK_QUEUE_DEPTH",
        "take",
    ] {
        if !has_identifier(take, required) {
            return Err(format!("queue-take window is missing {required}"));
        }
    }
    for forbidden in ["handle_ipv4", "drain_deferred_tx", "tcp", "log"] {
        if has_identifier(take, forbidden) {
            return Err(format!(
                "queue-take window contains delivery/logging identifier {forbidden}"
            ));
        }
    }
    Ok(())
}

fn validate_no_force_release_of_the_drain_owner(source: &str) -> Result<(), String> {
    const COMPARE: &str = "LOOPBACK_DRAIN_OWNER.compare_exchange(";
    const STORE: &str = "LOOPBACK_DRAIN_OWNER.store(";

    let implementation = code_text_offset(source, "impl Drop for LoopbackDrainGuard")
        .ok_or_else(|| "missing LoopbackDrainGuard Drop implementation".to_string())?;
    let approved_drop = function_spans(&source[implementation..])
        .into_iter()
        .find(|span| span.name == "drop")
        .ok_or_else(|| "missing LoopbackDrainGuard::drop".to_string())?;
    let approved_drop_open = implementation + approved_drop.open;

    for span in function_spans(source) {
        let body = &source[span.open..=span.close];
        if span.open == approved_drop_open {
            continue;
        }

        let compact = compact_code(body);
        let mut cursor = 0usize;
        while let Some(relative) = compact[cursor..].find(COMPARE) {
            let arguments_start = cursor + relative + COMPARE.len();
            let arguments_end = compact[arguments_start..]
                .find(')')
                .map(|end| arguments_start + end)
                .ok_or_else(|| format!("{} has an unclosed owner CAS", span.name))?;
            let arguments: Vec<_> = compact[arguments_start..arguments_end].split(',').collect();
            if arguments.get(1).copied() == Some("0") {
                return Err(format!("{} force-releases LOOPBACK_DRAIN_OWNER", span.name));
            }
            cursor = arguments_end + 1;
        }

        if let Some(store) = compact.find(STORE) {
            let value = &compact[store + STORE.len()..];
            if value.starts_with("0,") || value.starts_with("0)") {
                return Err(format!("{} stores zero to LOOPBACK_DRAIN_OWNER", span.name));
            }
        }
    }
    Ok(())
}

fn validate_pump_does_not_halt_while_work_remains(source: &str) -> Result<(), String> {
    let pump = function_body(source, "loopback_pump_fn")
        .ok_or_else(|| "missing loopback_pump_fn".to_string())?;
    let more = code_text_offset(pump, "if more")
        .ok_or_else(|| "loopback_pump_fn has no more-work branch".to_string())?;
    let branch = braced_block(pump, &code_mask(pump), more)
        .ok_or_else(|| "cannot parse loopback pump more-work branch".to_string())?;
    if has_identifier(branch, "arch_halt_with_interrupts") {
        return Err("loopback pump halts while work remains".to_string());
    }
    if !has_identifier(branch, "yield_current") || !has_identifier(branch, "continue") {
        return Err("loopback pump more-work branch must yield and continue".to_string());
    }
    Ok(())
}

fn validate_net_lock_guard_disables_bottom_halves_not_softirq_execution(
    source: &str,
) -> Result<(), String> {
    let acquire = function_body(source, "net_lock_guard")
        .ok_or_else(|| "missing net_lock_guard".to_string())?;
    let acquire_x86 = cfg_arch_block(acquire, "x86_64")
        .ok_or_else(|| "missing x86_64 net_lock_guard arm".to_string())?;
    if !has_identifier(acquire_x86, "bh_disable") || has_identifier(acquire_x86, "softirq_enter") {
        return Err("x86 net_lock_guard does not use pure BH disable".to_string());
    }

    let implementation = code_text_offset(source, "impl Drop for NetLockGuard")
        .ok_or_else(|| "missing NetLockGuard Drop implementation".to_string())?;
    let drop = function_body(&source[implementation..], "drop")
        .ok_or_else(|| "missing NetLockGuard::drop".to_string())?;
    let drop_x86 = cfg_arch_block(drop, "x86_64")
        .ok_or_else(|| "missing x86_64 NetLockGuard::drop arm".to_string())?;
    if !has_identifier(drop_x86, "bh_enable") || has_identifier(drop_x86, "softirq_exit") {
        return Err("x86 NetLockGuard::drop does not use pure BH enable".to_string());
    }
    Ok(())
}

fn validate_any_context_wake_dispatches_on_execution_context(source: &str) -> Result<(), String> {
    let wake = function_body(source, "wake_thread_any_context")
        .ok_or_else(|| "missing wake_thread_any_context".to_string())?;
    if !has_identifier(wake, "in_interrupt") {
        return Err("wake_thread_any_context does not use in_interrupt".to_string());
    }
    for forbidden in ["in_softirq", "softirq_count"] {
        if has_identifier(wake, forbidden) {
            return Err(format!(
                "wake_thread_any_context branches on wide predicate {forbidden}"
            ));
        }
    }
    Ok(())
}

fn validate_generic_unblock_keeps_child_exit_dedicated(source: &str) -> Result<(), String> {
    let unblock =
        function_body(source, "unblock").ok_or_else(|| "missing Scheduler::unblock".to_string())?;
    for state in [
        "Blocked",
        "BlockedOnSignal",
        "BlockedOnTimer",
        "BlockedOnIO",
    ] {
        if !has_identifier(unblock, state) {
            return Err(format!("Scheduler::unblock does not handle {state}"));
        }
    }
    if has_identifier(unblock, "BlockedOnChildExit") {
        return Err("Scheduler::unblock wakes the dedicated child-exit state".to_string());
    }
    Ok(())
}

fn validate_io_wake_buffers_before_thread_context_overflow_fallback(
    source: &str,
) -> Result<(), String> {
    let io_wake = function_body(source, "isr_unblock_for_io")
        .ok_or_else(|| "missing isr_unblock_for_io".to_string())?;
    if compact_code(io_wake) != "{let_=buffer_isr_wakeup(tid);set_need_resched();}" {
        return Err(
            "isr_unblock_for_io must buffer and then request rescheduling unconditionally"
                .to_string(),
        );
    }

    let buffer = function_body(source, "buffer_isr_wakeup")
        .ok_or_else(|| "missing buffer_isr_wakeup".to_string())?;
    let full_offset = code_text_offset(buffer, "IsrWakePush::Full")
        .ok_or_else(|| "buffer helper has no full-buffer arm".to_string())?;
    let full = braced_block(buffer, &code_mask(buffer), full_offset)
        .ok_or_else(|| "cannot parse full-buffer arm".to_string())?;
    if !compact_code(full).contains("if!crate::per_cpu::in_interrupt()") {
        return Err("full-buffer fallback is not restricted to thread context".to_string());
    }

    let interrupt_offset = identifier_offsets(full, &code_mask(full), "in_interrupt")
        .into_iter()
        .next()
        .ok_or_else(|| "full-buffer arm does not inspect interrupt context".to_string())?;
    let thread_context = braced_block(full, &code_mask(full), interrupt_offset)
        .ok_or_else(|| "cannot parse thread-context overflow arm".to_string())?;
    for required in ["with_scheduler", "unblock", "Applied", "AlreadyRunnable"] {
        if !has_identifier(thread_context, required) {
            return Err(format!("thread-context overflow arm is missing {required}"));
        }
    }
    if has_identifier(thread_context, "ENQUEUE_ISR_BUFFER_FULL") {
        return Err("thread-context overflow is counted as an ISR drop".to_string());
    }

    let else_offset = code_text_offset(full, "else")
        .ok_or_else(|| "full-buffer arm has no real-interrupt rejection branch".to_string())?;
    let interrupt_context = braced_block(full, &code_mask(full), else_offset)
        .ok_or_else(|| "cannot parse real-interrupt overflow arm".to_string())?;
    for required in ["ENQUEUE_ISR_BUFFER_FULL", "Rejected"] {
        if !has_identifier(interrupt_context, required) {
            return Err(format!("real-interrupt overflow arm is missing {required}"));
        }
    }
    if has_identifier(interrupt_context, "with_scheduler") {
        return Err("real-interrupt overflow arm takes the scheduler lock".to_string());
    }
    Ok(())
}

fn validate_loopback_regression_tests_are_arch_neutral(source: &str) -> Result<(), String> {
    for name in [
        "loopback_recv_wake_when_idle",
        "loopback_recv_wake_under_load",
        "loopback_pump_does_not_busy_spin",
        "loopback_wake_loss_counters_are_zero",
        "tcp_final_ack_survives_accept_publish_race",
    ] {
        let definition =
            test_def_block(source, name).ok_or_else(|| format!("missing TestDef for {name}"))?;
        if !compact_code(definition).contains("arch:Arch::Any") {
            return Err(format!("{name} is not Arch::Any"));
        }
    }
    Ok(())
}

fn validate_x86_gate_requires_the_loopback_regression_tests(source: &str) -> Result<(), String> {
    if !source.contains("for _ in $(seq 1 900); do") {
        return Err("x86 gate does not allow 900 seconds for late registry tests".to_string());
    }
    for explanation in ["registry", "userspace programs", "slow-but-healthy"] {
        if !source[..source.find("set -euo pipefail").unwrap_or(0)].contains(explanation) {
            return Err(format!(
                "x86 gate header does not explain the 900-second bound ({explanation})"
            ));
        }
    }
    let required_name = "loopback_recv_wake";
    let required_marker = format!("\\[TEST:userspace:{required_name}:PASS\\]");
    if source.matches(&required_marker).count() != 2 {
        return Err(format!(
            "x86 gate does not poll and assert exactly-once evidence for {required_name}"
        ));
    }
    if !source.contains(&format!("grep -q '{required_marker}'")) {
        return Err(format!("x86 gate does not poll for {required_name}"));
    }
    let count_anchor = format!("grep -h -c '{required_marker}'");
    let count = source
        .find(&count_anchor)
        .ok_or_else(|| format!("x86 gate lost the exact PASS count for {required_name}"))?;
    let count_tail = &source[count..];
    let next_count = count_tail[1..]
        .find("test \"$(grep -h -c '")
        .map_or(count_tail.len(), |offset| offset + 1);
    if !count_tail[..next_count].contains("-eq 1") {
        return Err(format!(
            "x86 gate weakened the exactly-once PASS count for {required_name}"
        ));
    }
    if source.contains("\\[TEST:network:loopback_wake_loss_counters_are_zero:PASS\\]") {
        return Err("x86 gate still treats the boot-window counter marker as proof".to_string());
    }
    // Re-pinned per delta by P6a PR-2 (review finding F5): the tombstone join
    // oracle's fixture stages two rows that reach the real zombie state through
    // `terminate_minimal`, which is the tally's choke point, and the same
    // re-derivation closed a pre-existing one-row gap — the enumeration read 101
    // while the gate's own runs measured 102, because the RING3_SMOKE
    // `smoke_hello_time` process was never counted. 102 + 2 = 104.
    //
    // Re-pinned again to 105 by the #737 DF-oracle branch: `df_preempt_oracle`
    // joined the RING3_SMOKE roster as one more launched program that runs to
    // completion and exits once, which moves this floor by exactly 1. The gate
    // script carries the same derivation beside its own constant. This literal
    // and that one are the two halves of one pin, and when the branch moved the
    // script it left this half at 104, which is the finding this edit closes.
    // claim-lint:ok: 1 of 1 `readonly EXPECTED_USERSPACE_EXITS=` assignment in
    // docker/qemu/run-x86-boot-tests.sh reads 105 at this head, and the
    // mutation leg `x86_gate_validator_rejects_lower_userspace_exit_pin` below
    // reddens this validator by rewriting exactly that assignment. #737.
    if source
        .matches("readonly EXPECTED_USERSPACE_EXITS=105")
        .count()
        != 1
    {
        return Err("x86 gate does not pin the 105 expected userspace exits".to_string());
    }
    for rationale in [
        "B1",
        "bonus, not the proof",
        "before any user process exists",
        "three of its four counters are structurally zero",
        "cannot go red",
        "#545 regression",
        "mid-stream stall",
    ] {
        if !source.contains(rationale) {
            return Err(format!("x86 gate lost pinned rationale ({rationale})"));
        }
    }
    if !source.contains("scripts/score-boot-resume.py") {
        return Err("x86 gate lost the boot resume and scheduling loopback scorer".to_string());
    }
    for (failure_marker, description) in [
        ("\\[TEST:network:[^]]*:FAIL", "network"),
        ("\\[TEST:userspace:[^]]*:FAIL", "userspace"),
    ] {
        if source.matches(failure_marker).count() != 2 {
            return Err(format!(
                "x86 gate does not reject {description} test failures during and after polling"
            ));
        }
    }
    Ok(())
}

fn validate_x86_direct_loopback_gates(main: &str, registry: &str) -> Result<(), String> {
    let kernel_main = function_body(main, "kernel_main_on_kernel_stack")
        .ok_or_else(|| "missing kernel_main_on_kernel_stack".to_string())?;
    let cohort_call = kernel_main
        .find("teardown::run_x86_retire_cohort_gate();")
        .ok_or_else(|| "missing direct x86 retire-cohort gate call".to_string())?;
    let loopback_call = kernel_main
        .find("test_framework::registry::run_x86_loopback_gates();")
        .ok_or_else(|| "missing direct x86 loopback-gate call".to_string())?;
    let oracle_call = kernel_main
        .find("task::boot_resume_oracle::run();")
        .ok_or_else(|| "missing boot resume oracle".to_string())?;
    let next_cohort = kernel_main
        .find("teardown::run_x86_exec_cohort_gate();")
        .ok_or_else(|| "missing next cohort".to_string())?;
    if !(cohort_call < loopback_call && loopback_call < oracle_call && oracle_call < next_cohort) {
        return Err("x86 loopback gates lost their direct-call order or rationale".to_string());
    }

    let declaration = registry
        .find("pub fn run_x86_loopback_gates")
        .ok_or_else(|| "missing run_x86_loopback_gates wrapper".to_string())?;
    let cfg_start = registry[..declaration]
        .rfind("#[cfg(")
        .ok_or_else(|| "x86 loopback wrapper has no cfg attribute".to_string())?;
    let cfg = registry[cfg_start..declaration]
        .chars()
        .filter(|character| !character.is_whitespace())
        .collect::<String>();
    if cfg != "#[cfg(all(feature=\"boot_tests\",target_arch=\"x86_64\"))]" {
        return Err("x86 loopback wrapper is not boot_tests+x86_64 gated".to_string());
    }

    let wrapper = function_body(registry, "run_x86_loopback_gates")
        .ok_or_else(|| "cannot parse run_x86_loopback_gates wrapper".to_string())?;
    if wrapper.matches("let result = ").count() != 5 {
        return Err("x86 loopback wrapper does not contain exactly five gates".to_string());
    }
    for name in [
        "loopback_recv_wake_when_idle",
        "loopback_recv_wake_under_load",
        "loopback_pump_does_not_busy_spin",
        "tcp_final_ack_survives_accept_publish_race",
        "loopback_wake_loss_counters_are_zero",
    ] {
        let call = wrapper
            .find(&format!("let result = {name}();"))
            .ok_or_else(|| format!("x86 loopback wrapper does not call {name}"))?;
        let start = format!("[TEST:network:{name}:START]");
        let pass = format!("[TEST:network:{name}:PASS]");
        let fail = format!("[TEST:network:{name}:FAIL:");
        for marker in [&start, &pass, &fail] {
            if wrapper.matches(marker).count() != 1 || registry.matches(marker).count() != 1 {
                return Err(format!(
                    "x86 loopback wrapper is not the sole producer of {marker}"
                ));
            }
        }
        let start_offset = wrapper
            .find(&start)
            .ok_or_else(|| "x86 loopback wrapper lost its START marker".to_string())?;
        let pass_offset = wrapper
            .find(&pass)
            .ok_or_else(|| "x86 loopback wrapper lost its PASS marker".to_string())?;
        let fail_offset = wrapper
            .find(&fail)
            .ok_or_else(|| "x86 loopback wrapper lost its FAIL marker".to_string())?;
        if start_offset >= call
            || call >= pass_offset.min(fail_offset)
            || !wrapper.contains("match result")
        {
            return Err("x86 loopback wrapper lost START then PASS-or-FAIL discipline".to_string());
        }
        if wrapper.contains("panic!(")
            || wrapper.contains(".unwrap()")
            || wrapper.contains(".expect(")
        {
            return Err("x86 loopback wrapper may panic instead of emitting FAIL".to_string());
        }

        let body = function_body(registry, name)
            .ok_or_else(|| format!("missing loopback gate body {name}"))?;
        if body.contains(&format!("[TEST:network:{name}:")) {
            return Err(format!("{name} body emits its own x86 marker"));
        }
        if !wrapper.contains(&format!("x86 {name} failed")) {
            return Err(format!("missing assertion for {name}"));
        }
    }

    validate_loopback_regression_tests_are_arch_neutral(registry)
}

fn validate_x86_userspace_phase_launches_loopback_wake_test(source: &str) -> Result<(), String> {
    let kernel_main_continue = function_body(source, "kernel_main_continue")
        .ok_or_else(|| "missing kernel_main_continue".to_string())?;
    let compact = compact_whitespace(kernel_main_continue);
    let load = "kernel::userspace_test::get_test_binary(\"loopback_wake_test\")";
    if compact.matches(load).count() != 1 {
        return Err("kernel_main_continue must load loopback_wake_test exactly once".to_string());
    }
    let launch = "process::creation::create_user_process(String::from(\"loopback_wake_test\")";
    if compact.matches(launch).count() != 1 {
        return Err("kernel_main_continue must launch loopback_wake_test exactly once".to_string());
    }
    Ok(())
}

fn validate_schedule_rearms_a_blocked_pump(source: &str) -> Result<(), String> {
    let schedule = function_body(source, "schedule")
        .ok_or_else(|| "missing Scheduler::schedule".to_string())?;
    if !has_identifier(schedule, "loopback_queue_has_work") {
        return Err("Scheduler::schedule does not check for loopback work".to_string());
    }
    if !has_identifier(schedule, "loopback_pump_tid") {
        return Err("Scheduler::schedule does not load the loopback pump tid".to_string());
    }
    if !normalized_code(schedule).contains("self.unblock(pump_tid)") {
        return Err("Scheduler::schedule does not re-arm the blocked pump".to_string());
    }
    Ok(())
}

fn validate_wakeup_placement_is_bounded_by_online_cpus(source: &str) -> Result<(), String> {
    for name in ["find_target_cpu_for_wakeup", "least_loaded_cpu"] {
        let body = function_body(source, name).ok_or_else(|| format!("missing {name}"))?;
        let compact = compact_code(body);
        if !has_identifier(body, "online_cpu_count") {
            return Err(format!("{name} does not reference online_cpu_count"));
        }
        if !has_identifier(body, "cpu_accepts_wakeups") {
            return Err(format!("{name} does not consult CPU scheduling liveness"));
        }
        if !compact.contains(
            "(0..self.online_cpu_count()).filter(|&cpu|self.cpu_accepts_wakeups(cpu)).min_by_key(",
        ) {
            return Err(format!(
                "{name} does not select from scheduling CPUs in the online range"
            ));
        }
        if compact.contains("(0..MAX_CPUS).min_by_key(") {
            return Err(format!("{name} selects from all MAX_CPUS queues"));
        }
        // The pairing rule, which is what makes this validator see arms that
        // did not exist when it was written. Each placement arm in these
        // functions bounds a CPU choice by the online range AND filters it
        // through scheduling liveness, so the two references come in pairs.
        // Counting the pair rather than naming the arms is deliberate: the pin
        // arm this slice adds is a second arm, and the 4 substring rules above
        // describe the least-loaded arm only -- they stay green whatever the
        // pin arm does. A new arm that brings one half of the pair reddens
        // this, whatever it is called; a new arm that brings both passes.
        let mask = code_mask(body);
        let bounds = identifier_offsets(body, &mask, "online_cpu_count").len();
        let liveness = identifier_offsets(body, &mask, "cpu_accepts_wakeups").len();
        if bounds != liveness {
            return Err(format!(
                "{name} has {bounds} online-range test(s) but {liveness} scheduling-liveness test(s): every placement arm must consult both"
            ));
        }

        // And the rule the pairing count alone cannot enforce: a placement made
        // from a thread's stored CPU pin is a placement like any other, so the
        // block that reads cpu_affinity must consult the online range and
        // scheduling liveness BEFORE it returns a CPU. Deleting both halves of
        // that condition together keeps the counts balanced, so without this
        // the pairing rule stays green on exactly the shape the finding was
        // about. Located by the cpu_affinity read, not by arm name.
        for offset in identifier_offsets(body, &mask, "cpu_affinity") {
            let block = braced_block(body, &mask, offset)
                .ok_or_else(|| format!("{name} reads cpu_affinity outside any block"))?;
            if !has_identifier(block, "online_cpu_count") {
                return Err(format!(
                    "{name} returns a pinned CPU without bounding it by the online range"
                ));
            }
            if !has_identifier(block, "cpu_accepts_wakeups") {
                return Err(format!(
                    "{name} returns a pinned CPU without consulting scheduling liveness"
                ));
            }
            let block_mask = code_mask(block);
            let first_return = identifier_offsets(block, &block_mask, "return")
                .into_iter()
                .next();
            let first_liveness = identifier_offsets(block, &block_mask, "cpu_accepts_wakeups")
                .into_iter()
                .next();
            if let (Some(returned), Some(checked)) = (first_return, first_liveness) {
                if returned < checked {
                    return Err(format!(
                        "{name} returns from the pin block before consulting scheduling liveness"
                    ));
                }
            }
        }
    }
    Ok(())
}

/// A refused pinned wake is HELD, not destroyed.
///
/// Three separate rules, because the finding this replaces was three defects
/// wearing one shape. The refusal must not consume the wake (the hold writes no
/// thread state, so the `Ready` its caller published stands and the blocked
/// kind it woke from is not collapsed), it must not undo a publication some
/// other path made (the hold writes no queue), and something must place the
/// wake later (both scheduler entry points run the delivery, which enqueues).
///
/// The first two are enforced by the RECEIVER: `&self` cannot write a thread
/// row or a queue, so those rules hold by type rather than by substring, and
/// the leg for them mutates the receiver rather than the body. The pin rule is
/// the one the earlier park carried: `Thread::cpu_affinity` exists in two
/// copies, so writing it from here would leave the process-table row naming a
/// CPU the scheduler's copy does not.
/// claim-lint:ok: 6 of 6 legs for these rules -- the live source, a `&mut self`
/// receiver, an injected state write, an injected queue write, a deleted
/// enqueue, and a deleted delivery call -- are the tests below
fn validate_pinned_hold_preserves_the_wake(source: &str) -> Result<(), String> {
    if !source.contains("fn hold_pinned_wake_for_home(&self, thread_id: u64)") {
        return Err(
            "the hold must take &self, so that it cannot write a thread row or a queue".to_string(),
        );
    }
    let body = function_body(source, "hold_pinned_wake_for_home")
        .ok_or_else(|| "the pinned-wake hold disposition is missing".to_string())?;
    let compact = compact_code(body);
    if !compact.contains("PINNED_HOME_CPU_UNAVAILABLE.fetch_add(") {
        return Err("the hold must count itself, or no gate can see it".to_string());
    }
    if compact.contains("ThreadState::") || compact.contains("set_ready(") {
        return Err(
            "the hold writes thread state; the wake it was given would be lost".to_string(),
        );
    }
    if compact.contains("per_cpu_queues") {
        return Err("the hold writes a ready queue; it may only refuse a placement".to_string());
    }
    if compact.contains("cpu_affinity=") {
        return Err(
            "the hold writes a pin; the two copies of the field would disagree".to_string(),
        );
    }

    let delivery = function_body(source, "deliver_pinned_wakes_for_this_cpu")
        .ok_or_else(|| "nothing places a held wake; the refusal would be permanent".to_string())?;
    let delivery_compact = compact_code(delivery);
    if !delivery_compact.contains("self.per_cpu_queues[cpu].push_back(") {
        return Err("the delivery does not place the held wake on a ready queue".to_string());
    }
    if !delivery_compact.contains("PINNED_WAKES_DELIVERED.fetch_add(") {
        return Err("the delivery does not count itself, so a recovery is invisible".to_string());
    }
    for name in ["schedule", "schedule_deferred_requeue"] {
        let entry = function_body(source, name).ok_or_else(|| format!("missing {name}"))?;
        if !compact_code(entry).contains("self.deliver_pinned_wakes_for_this_cpu()") {
            return Err(format!(
                "{name} does not place the wakes this CPU is holding, so entering the scheduler is not what ends a hold"
            ));
        }
    }
    Ok(())
}

/// Slice 3e's migration guard, judged on what it does rather than on being
/// present.
///
/// The census rule above only asks whether a function CONSULTS the pin. A
/// guard that read the pin and then moved the thread anyway would satisfy it,
/// which is why this rule reads the guard itself. Five facts, and each of them
/// has a mutation leg:
///
///   1. it reads `cpu_affinity` and separates the two pin kinds by
///      `per_cpu_worker`, because slice 3d gave them opposite dispositions;
///   2. it short-circuits when the destination the caller chose already IS the
///      pinned CPU, so an on-home placement is not counted as a refusal;
///   3. it bounds the pinned CPU by the online range before indexing a queue
///      with it;
///   4. it can answer BOTH ways -- at least one `true` and at least one
///      `false` return. An "unconditional move" mutation removes the `true`
///      answers and is exactly what this catches;
///   5. when it does refuse, the thread goes to the pinned CPU's queue or its
///      wake is held for that CPU by slice 3d's hold -- and to `taking_cpu`,
///      the destination it just refused, on 0 of its arms.
fn validate_pin_guard_refuses_a_foreign_placement(source: &str) -> Result<(), String> {
    let body = function_body(source, "retain_cpu_affine_thread")
        .ok_or("kernel/src/task/scheduler.rs defines no retain_cpu_affine_thread guard")?;
    let compact = compact_code(body);

    if !compact.contains("CPU_PINS_STAMPED.load(Ordering::Relaxed)==0") {
        return Err(
            "the migration guard's constant-cost arm is not conditioned on 0 pins having been \
             minted, so its early return is not the answer the full path would give"
                .into(),
        );
    }
    if !body.contains("cpu_affinity") {
        return Err("the migration guard does not read Thread::cpu_affinity".into());
    }
    if !body.contains("per_cpu_worker") {
        return Err(
            "the migration guard does not separate a per-CPU worker pin from a hold pen".into(),
        );
    }
    if !compact.contains("pin.cpu==taking_cpu") {
        return Err(
            "the migration guard does not short-circuit when the caller's destination is \
             already the pinned CPU"
                .into(),
        );
    }
    if !compact.contains("pin.cpu>=self.online_cpu_count()") {
        return Err(
            "the migration guard indexes a queue by the pinned CPU without bounding it by the \
             online range"
                .into(),
        );
    }
    let refusals = compact.matches("returntrue;").count() + compact.matches("}true}").count();
    if refusals == 0 {
        return Err(
            "the migration guard has no arm that refuses: every path returns false, so every \
             site places the thread exactly where it would have without the guard"
                .into(),
        );
    }
    if !compact.contains("returnfalse;") {
        return Err(
            "the migration guard never declines, so an unpinned thread no longer takes the \
             caller's own placement"
                .into(),
        );
    }
    if !compact.contains("self.per_cpu_queues[pin.cpu].push_back(thread_id)") {
        return Err("the migration guard never places the thread on the pinned CPU".into());
    }
    if !compact.contains("self.hold_pinned_wake_for_home(thread_id)") {
        return Err(
            "the migration guard does not use slice 3d's hold when the pinned CPU is not \
             accepting wakeups"
                .into(),
        );
    }
    if !compact.contains("self.pinned_wake_is_waiting_here(thread_id,pin.cpu)") {
        return Err(
            "the migration guard holds a wake without checking that the hold is in the shape \
             its delivery recognises"
                .into(),
        );
    }
    if compact.contains("per_cpu_queues[taking_cpu]") {
        return Err(
            "the migration guard places the thread on the very CPU whose placement it refused"
                .into(),
        );
    }
    Ok(())
}

/// Each call of the guard decides a placement.
///
/// A site that called `retain_cpu_affine_thread` and discarded the answer would
/// satisfy the census -- its body would contain the marker -- while migrating
/// the thread anyway. So each call outside the definition must be the condition
/// of an `if`, which is the 1 shape that can suppress the caller's own push.
fn validate_pin_guard_calls_decide_the_placement(source: &str) -> Result<(), String> {
    // Normalised rather than compacted: the receiver keeps its space from the
    // `if`, so `if self.` cannot be misread as one identifier.
    let normalised = normalized_code(source);
    let mut searched = 0usize;
    let mut calls = 0usize;
    while let Some(relative) = normalised[searched..].find("retain_cpu_affine_thread(") {
        let offset = searched + relative;
        searched = offset + "retain_cpu_affine_thread(".len();
        let before = &normalised[..offset];
        if before.ends_with("fn ") {
            continue;
        }
        calls += 1;
        let conditional = ["if self.", "if !self.", "if sched.", "if !sched."]
            .iter()
            .any(|shape| before.ends_with(shape));
        if !conditional {
            return Err(format!(
                "a retain_cpu_affine_thread call is not the condition of an if -- it reads \
                 `...{}`, so its answer cannot suppress the caller's own placement",
                &before[before.len().saturating_sub(48)..]
            ));
        }
    }
    if calls == 0 {
        return Err("no site calls the migration guard".into());
    }
    Ok(())
}

fn validate_scheduling_paths_reclaim_unschedulable_cpu_queues(source: &str) -> Result<(), String> {
    for name in ["schedule", "schedule_deferred_requeue"] {
        let body = function_body(source, name).ok_or_else(|| format!("missing {name}"))?;
        if !compact_code(body).contains("self.reclaim_unschedulable_cpu_queues()") {
            return Err(format!("{name} does not reclaim unschedulable CPU queues"));
        }
    }
    Ok(())
}

/// A thread that carries a CPU pin is queued to the CPU that pin names.
///
/// The placement functions are DERIVED, not listed: a scheduler function that
/// resolves a ready-queue target through `least_loaded_cpu()` is one, which is
/// 1 of 1 today (`add_thread_inner`), so a second cannot appear without this
/// rule seeing it and renaming the current one does not silence it. Each must
/// read the thread's own `cpu_affinity` pin BEFORE the least-loaded choice,
/// resolve that pin to the CPU it names, reject a pin outside the online
/// range, and fall through to `least_loaded_cpu()` when there is no pin --
/// which is the path taken today, `spawn_on_cpu` having 0 callers.
///
/// Each of those 4 is checked by SHAPE, not against the exact expression this
/// tree carries today, because the neighbourhood is scheduled to change: the
/// bound has to gain the scheduling-liveness conjunct the fall-through already
/// applies, and the arm has to learn to tell a per-CPU-worker pin from a hold
/// pen. A rule that matched today's literal would redden on both -- it would
/// forbid its own repair, with a message saying the opposite of what the code
/// did. What is required is that the pin's CPU be REJECTED when it fails the
/// bound (a `filter` adapter) rather than rewritten, and 3 tests below assert
/// that a strictly stronger bound and a pin-kind pre-filter both pass.
fn validate_thread_placement_honours_the_cpu_pin(source: &str) -> Result<(), String> {
    let mut placements: Vec<(String, String)> = Vec::new();
    for span in function_spans(source) {
        let body = source[span.open..=span.close].to_string();
        if !has_identifier(&body, "least_loaded_cpu") {
            continue;
        }
        // Skip an enclosing scope that merely contains a placement function.
        let nested = function_spans(&body)
            .into_iter()
            .any(|inner| has_identifier(&body[inner.open..=inner.close], "least_loaded_cpu"));
        if nested {
            continue;
        }
        placements.push((span.name.clone(), body));
    }

    if placements.is_empty() {
        return Err(
            "no scheduler function resolves a queue target through least_loaded_cpu(): the placement census is empty"
                .to_string(),
        );
    }

    for (name, body) in placements {
        let mask = code_mask(&body);
        let Some(pin_read) = identifier_offsets(&body, &mask, "cpu_affinity")
            .into_iter()
            .next()
        else {
            return Err(format!(
                "{name} chooses a queue without reading the thread's cpu_affinity pin"
            ));
        };
        let Some(least_loaded) = identifier_offsets(&body, &mask, "least_loaded_cpu")
            .into_iter()
            .next()
        else {
            return Err(format!("{name} lost its least_loaded_cpu() fall-through"));
        };
        if pin_read > least_loaded {
            return Err(format!(
                "{name} consults least_loaded_cpu() before the thread's own pin"
            ));
        }
        // The statement that resolves the target, from the pin read through the
        // fall-through, so a `filter` elsewhere in the function cannot stand in
        // for the one that bounds the pin.
        let Some(region) = statement_region(&body, &mask, pin_read, least_loaded) else {
            return Err(format!(
                "{name} has no statement that resolves the queue target"
            ));
        };
        let compact = compact_code(region);
        if !compact_field_access(&compact, "cpu") {
            return Err(format!(
                "{name} does not resolve the thread's pin to the CPU it names"
            ));
        }
        if !compact_call_arguments(&compact, "filter")
            .iter()
            .any(|argument| argument.contains("online_cpu_count"))
        {
            return Err(format!(
                "{name} does not reject a pinned CPU outside the online range"
            ));
        }
        if !compact_call_arguments(&compact, "unwrap_or_else")
            .iter()
            .any(|argument| argument.contains("least_loaded_cpu"))
        {
            return Err(format!(
                "{name} does not fall through to least_loaded_cpu() for an unpinned thread"
            ));
        }
    }
    Ok(())
}

/// A pin records WHY it exists, and each of the 2 ways of building one says so.
///
/// Censused over the constructors of `CpuPin` rather than named one by one: a
/// constructor added later that leaves the reason implicit reddens this. The
/// reason is not decoration -- the two kinds need opposite treatment when the
/// home CPU stops dispatching, and a bare CPU index on `Thread` cannot carry
/// the distinction at all.
///
/// A CONSTRUCTOR is a function whose body builds a pin, which is 2 of the 2
/// functions `impl CpuPin` holds today. A function that builds no pin -- an
/// accessor or a predicate, which is how slice 3e's reclaim disposition will
/// read the kind -- has no reason to name, and demanding one of it would
/// redden this rule on a change that cannot weaken it.
fn validate_cpu_pin_records_its_reason(source: &str) -> Result<(), String> {
    let mask = code_mask(source);
    if !compact_code(source).contains("pubcpu_affinity:Option<CpuPin>") {
        return Err("Thread::cpu_affinity does not carry a CpuPin".to_string());
    }

    let struct_offset = code_text_offset(source, "struct CpuPin")
        .ok_or_else(|| "CpuPin is not defined".to_string())?;
    let fields = braced_block(source, &mask, struct_offset)
        .ok_or_else(|| "CpuPin has no field block".to_string())?;
    for field in ["cpu", "per_cpu_worker"] {
        if !has_identifier(fields, field) {
            return Err(format!("CpuPin does not carry the {field} field"));
        }
    }

    let impl_offset = code_text_offset(source, "impl CpuPin")
        .ok_or_else(|| "CpuPin has no constructors".to_string())?;
    let constructors = braced_block(source, &mask, impl_offset)
        .ok_or_else(|| "impl CpuPin has no block".to_string())?;
    let mut kinds: Vec<bool> = Vec::new();
    for span in function_spans(constructors) {
        let body = compact_code(&constructors[span.open..=span.close]);
        if !body.contains("Self{") && !body.contains("CpuPin{") {
            continue;
        }
        if body.contains("per_cpu_worker:true") {
            kinds.push(true);
        } else if body.contains("per_cpu_worker:false") {
            kinds.push(false);
        } else {
            return Err(format!(
                "CpuPin::{} builds a pin without naming the reason it exists",
                span.name
            ));
        }
    }
    if kinds.is_empty() {
        return Err("CpuPin has no constructor to census".to_string());
    }
    if !kinds.contains(&true) || !kinds.contains(&false) {
        return Err(
            "CpuPin cannot express both reasons: a per-CPU worker and a hold pen are the two a later reclaim disposition has to tell apart"
                .to_string(),
        );
    }
    Ok(())
}

#[test]
fn pump_producer_seam_is_single() {
    validate_pump_producer_seam_is_single(&net_source_text()).expect("single producer seam");
}

#[test]
fn pump_producer_seam_validator_rejects_second_producer() {
    let source = net_source_text();
    let mutated = format!(
        "{source}\nfn rogue_producer() {{ let mut queue = LOOPBACK_QUEUE.lock(); queue.push(packet); }}"
    );
    assert!(validate_pump_producer_seam_is_single(&mutated).is_err());
}

#[test]
fn pump_wake_is_the_only_pump_wake_path() {
    validate_pump_wake_is_the_only_pump_wake_path(&kernel_source_text())
        .expect("single pump wake path");
}

#[test]
fn pump_wake_validator_rejects_second_wake_path() {
    let source = kernel_source_text();
    let mutated = format!(
        "{source}\nfn rogue_wake() {{ let tid = LOOPBACK_PUMP_TID.load(Ordering::Acquire); wake_thread_any_context(tid); }}"
    );
    assert!(validate_pump_wake_is_the_only_pump_wake_path(&mutated).is_err());
}

#[test]
fn any_context_wake_never_takes_the_scheduler_lock_in_interrupt_context() {
    validate_any_context_wake_never_takes_scheduler_lock_in_interrupt_context(&repo_text(
        "kernel/src/task/scheduler.rs",
    ))
    .expect("interrupt arm remains lock-free");
}

#[test]
fn any_context_wake_validator_rejects_interrupt_scheduler_lock() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let mutated = inject_into_block_after_identifier(
        &source,
        "wake_thread_any_context",
        "in_interrupt",
        "with_scheduler(|scheduler| scheduler.unblock(tid));",
    );
    assert!(
        validate_any_context_wake_never_takes_scheduler_lock_in_interrupt_context(&mutated)
            .is_err()
    );
}

#[test]
fn wake_waiting_threads_is_arch_neutral() {
    validate_wake_waiting_threads_is_arch_neutral(&repo_text("kernel/src/net/tcp.rs"))
        .expect("TCP wake remains arch-neutral");
}

#[test]
fn wake_waiting_threads_validator_rejects_arch_cfg() {
    let source = repo_text("kernel/src/net/tcp.rs");
    let mutated = inject_into_function(
        &source,
        "wake_waiting_threads",
        "#[cfg(target_arch = \"aarch64\")] { return Vec::new(); }",
    );
    assert!(validate_wake_waiting_threads_is_arch_neutral(&mutated).is_err());
}

#[test]
fn waiter_lists_are_not_drained_before_the_wake() {
    validate_waiter_lists_are_not_drained_before_the_wake(&repo_text("kernel/src/net/tcp.rs"))
        .expect("waiters remain registered until wake acceptance");
}

#[test]
fn waiter_list_validator_rejects_pre_wake_drain() {
    let source = repo_text("kernel/src/net/tcp.rs");
    let mutated = inject_into_function(
        &source,
        "wake_connection_waiters",
        "conn.waiting_threads.lock().drain(..);",
    );
    assert!(validate_waiter_lists_are_not_drained_before_the_wake(&mutated).is_err());
}

#[test]
fn tcp_accept_inserts_before_pending_removal() {
    validate_tcp_accept_inserts_before_pending_removal(&repo_text("kernel/src/net/tcp.rs"))
        .expect("accepted connection is visible before its pending entry is removed");
}

#[test]
fn tcp_accept_order_validator_rejects_remove_before_insert() {
    let source = repo_text("kernel/src/net/tcp.rs");
    let accept = function_body(&source, "tcp_accept").expect("find tcp_accept fixture");
    let mask = code_mask(accept);

    let insert_start = code_text_offset(accept, "with_tcp_connections(|connections|")
        .expect("find connection insertion fixture");
    let (_, insert_close) =
        braced_block_span(accept, &mask, insert_start).expect("parse connection insertion fixture");
    let insert_end = insert_close
        + accept[insert_close..]
            .find(';')
            .expect("find connection insertion terminator")
        + 1;

    let removal_start = code_text_offset(accept, "let final_pending = with_tcp_listeners")
        .expect("find pending removal fixture");
    let (_, removal_close) =
        braced_block_span(accept, &mask, removal_start).expect("parse pending removal fixture");
    let removal_end = removal_close
        + accept[removal_close..]
            .find(';')
            .expect("find pending removal terminator")
        + 1;

    assert!(
        insert_end <= removal_start,
        "fixture must insert before removing"
    );
    let mutated_accept = format!(
        "{}{}{}{}{}",
        &accept[..insert_start],
        &accept[removal_start..removal_end],
        &accept[insert_end..removal_start],
        &accept[insert_start..insert_end],
        &accept[removal_end..]
    );
    let mutated = source.replacen(accept, &mutated_accept, 1);
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_tcp_accept_inserts_before_pending_removal(&mutated).is_err());
}

#[test]
fn tcp_accept_claims_pending_in_peek_closure() {
    validate_tcp_accept_claims_pending_in_peek_closure(&repo_text("kernel/src/net/tcp.rs")).expect(
        "tcp_accept claims an unclaimed pending entry while peeking under the listener lock",
    );
}

#[test]
fn tcp_accept_claim_validator_rejects_claim_outside_listener_lock() {
    let source = repo_text("kernel/src/net/tcp.rs");
    let without_claim = source.replacen("pending.claimed = true;", "", 1);
    assert_ne!(without_claim, source, "fixture mutation must apply");
    let marker = "let copied_early_data_len = pending.early_data.len();";
    let moved_claim = without_claim.replacen(
        marker,
        "let mut pending = pending;\n    pending.claimed = true;\n    let copied_early_data_len = pending.early_data.len();",
        1,
    );
    assert_ne!(moved_claim, without_claim, "fixture mutation must apply");
    assert!(validate_tcp_accept_claims_pending_in_peek_closure(&moved_claim).is_err());
}

#[test]
fn general_idle_loops_drain_loopback() {
    validate_general_idle_loops_drain_loopback(
        &repo_text("kernel/src/main.rs"),
        &repo_text("kernel/src/main_aarch64.rs"),
    )
    .expect("general idle backstops use the idle drain seam");
}

#[test]
fn general_idle_loop_validator_rejects_missing_x86_drain() {
    let x86_source = repo_text("kernel/src/main.rs");
    let aarch64_source = repo_text("kernel/src/main_aarch64.rs");
    let mutated = x86_source.replacen("crate::net::drain_loopback_from_idle();", "", 1);
    assert_ne!(mutated, x86_source, "fixture mutation must apply");
    assert!(validate_general_idle_loops_drain_loopback(&mutated, &aarch64_source).is_err());
}

#[test]
fn general_idle_loop_validator_rejects_missing_aarch64_testing_drain() {
    let x86_source = repo_text("kernel/src/main.rs");
    let aarch64_source = repo_text("kernel/src/main_aarch64.rs");
    let mutated = remove_call_from_loop_after_anchor(
        &aarch64_source,
        r#"serial_print!("breenix> ");"#,
        "kernel::net::drain_loopback_from_idle();",
    )
    .expect("fixture mutation must apply");
    assert!(validate_general_idle_loops_drain_loopback(&x86_source, &mutated).is_err());
}

#[test]
fn general_idle_loop_validator_rejects_missing_aarch64_no_userspace_drain() {
    let x86_source = repo_text("kernel/src/main.rs");
    let aarch64_source = repo_text("kernel/src/main_aarch64.rs");
    let mutated = remove_call_from_loop_after_anchor(
        &aarch64_source,
        r#"serial_println!("[interactive] No userspace init — idling");"#,
        "kernel::net::drain_loopback_from_idle();",
    )
    .expect("fixture mutation must apply");
    assert!(validate_general_idle_loops_drain_loopback(&x86_source, &mutated).is_err());
}

#[test]
fn drain_exclusion_is_a_typed_guard() {
    validate_drain_exclusion_is_a_typed_guard(&repo_text("kernel/src/net/mod.rs"))
        .expect("drain exclusion remains typed RAII");
}

#[test]
fn drain_exclusion_validator_rejects_atomic_bool() {
    let source = repo_text("kernel/src/net/mod.rs");
    let mutated = inject_into_function(
        &source,
        "drain_loopback_rounds",
        "let exclusion = AtomicBool::new(false); drop(exclusion);",
    );
    assert!(validate_drain_exclusion_is_a_typed_guard(&mutated).is_err());
}

#[test]
fn drain_guard_scope_excludes_delivery() {
    validate_drain_guard_scope_excludes_delivery(&repo_text("kernel/src/net/mod.rs"))
        .expect("drain guard remains limited to queue take");
}

#[test]
fn drain_guard_scope_validator_rejects_delivery_in_take_window() {
    let source = repo_text("kernel/src/net/mod.rs");
    let mutated = inject_into_function(
        &source,
        "take_queued_loopback_packets",
        "tcp::drain_deferred_tx();",
    );
    assert!(validate_drain_guard_scope_excludes_delivery(&mutated).is_err());
}

#[test]
fn no_force_release_of_the_drain_owner() {
    validate_no_force_release_of_the_drain_owner(&repo_text("kernel/src/net/mod.rs"))
        .expect("only LoopbackDrainGuard::drop releases its owner ticket");
}

#[test]
fn drain_owner_validator_rejects_force_release() {
    let source = repo_text("kernel/src/net/mod.rs");
    let mutated = inject_into_function(
        &source,
        "acquire",
        "LOOPBACK_DRAIN_OWNER.store(0, Ordering::Release);",
    );
    assert!(validate_no_force_release_of_the_drain_owner(&mutated).is_err());
}

#[test]
fn pump_does_not_halt_while_work_remains() {
    validate_pump_does_not_halt_while_work_remains(&repo_text("kernel/src/net/loopback_pump.rs"))
        .expect("pump yields and continues while work remains");
}

#[test]
fn pump_more_branch_validator_rejects_halt() {
    let source = repo_text("kernel/src/net/loopback_pump.rs");
    let mutated = inject_into_block_after_identifier(
        &source,
        "loopback_pump_fn",
        "more",
        "crate::arch_halt_with_interrupts();",
    );
    assert!(validate_pump_does_not_halt_while_work_remains(&mutated).is_err());
}

#[test]
fn net_lock_guard_disables_bottom_halves_not_softirq_execution() {
    validate_net_lock_guard_disables_bottom_halves_not_softirq_execution(&repo_text(
        "kernel/src/net/mod.rs",
    ))
    .expect("x86 net guard uses BH-disable accounting");
}

#[test]
fn net_lock_guard_context_validator_rejects_softirq_execution_entry() {
    let source = repo_text("kernel/src/net/mod.rs");
    let acquire = function_body(&source, "net_lock_guard").expect("find net_lock_guard fixture");
    let mutated_acquire = acquire.replacen(
        "crate::per_cpu::bh_disable()",
        "crate::per_cpu::softirq_enter()",
        1,
    );
    assert_ne!(mutated_acquire, acquire, "fixture mutation must apply");
    let mutated = source.replacen(acquire, &mutated_acquire, 1);
    assert!(
        validate_net_lock_guard_disables_bottom_halves_not_softirq_execution(&mutated).is_err()
    );
}

#[test]
fn any_context_wake_dispatches_on_execution_context() {
    validate_any_context_wake_dispatches_on_execution_context(&repo_text(
        "kernel/src/task/scheduler.rs",
    ))
    .expect("any-context wake uses the execution-context predicate");
}

#[test]
fn any_context_wake_dispatch_validator_rejects_wide_softirq_predicate() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let wake = function_body(&source, "wake_thread_any_context")
        .expect("find wake_thread_any_context fixture");
    let mutated_wake = wake.replacen("in_interrupt", "in_softirq", 1);
    assert_ne!(mutated_wake, wake, "fixture mutation must apply");
    let mutated = source.replacen(wake, &mutated_wake, 1);
    assert!(validate_any_context_wake_dispatches_on_execution_context(&mutated).is_err());
}

#[test]
fn generic_unblock_keeps_child_exit_dedicated() {
    validate_generic_unblock_keeps_child_exit_dedicated(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("generic unblock does not wake waitpid sleepers");
}

#[test]
fn generic_unblock_validator_rejects_child_exit_wake() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let unblock = function_body(&source, "unblock").expect("find Scheduler::unblock fixture");
    let mutated_unblock = unblock.replacen(
        "|| thread.state == ThreadState::BlockedOnTimer",
        "|| thread.state == ThreadState::BlockedOnChildExit\n                || thread.state == ThreadState::BlockedOnTimer",
        1,
    );
    assert_ne!(mutated_unblock, unblock, "fixture mutation must apply");
    let mutated = source.replacen(unblock, &mutated_unblock, 1);
    assert!(validate_generic_unblock_keeps_child_exit_dedicated(&mutated).is_err());
}

#[test]
fn io_wake_buffers_before_thread_context_overflow_fallback() {
    validate_io_wake_buffers_before_thread_context_overflow_fallback(&repo_text(
        "kernel/src/task/scheduler.rs",
    ))
    .expect("I/O completion wake keeps the lock-free buffer dependency break");
}

#[test]
fn io_wake_validator_rejects_direct_any_context_routing() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let mutated = source.replacen(
        "let _ = buffer_isr_wakeup(tid);\n    set_need_resched();",
        "let _ = wake_thread_any_context(tid);\n    set_need_resched();",
        1,
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_io_wake_buffers_before_thread_context_overflow_fallback(&mutated).is_err());
}

#[test]
fn io_wake_validator_rejects_interrupt_context_inline_fallback() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let mutated = source.replacen(
        "if !crate::per_cpu::in_interrupt()",
        "if crate::per_cpu::in_interrupt()",
        1,
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_io_wake_buffers_before_thread_context_overflow_fallback(&mutated).is_err());
}

#[test]
fn loopback_regression_tests_are_arch_neutral() {
    validate_loopback_regression_tests_are_arch_neutral(&repo_text(
        "kernel/src/test_framework/registry.rs",
    ))
    .expect("all loopback regression TestDefs remain Arch::Any");
}

#[test]
fn loopback_arch_validator_rejects_arch_specific_test() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    let definition = test_def_block(&source, "loopback_recv_wake_when_idle")
        .expect("find loopback recv wake TestDef fixture");
    let mutated_definition = definition.replacen("Arch::Any", "Arch::X86_64", 1);
    assert_ne!(
        mutated_definition, definition,
        "fixture mutation must apply"
    );
    let mutated = source.replacen(definition, &mutated_definition, 1);
    assert!(validate_loopback_regression_tests_are_arch_neutral(&mutated).is_err());
}

/// The loopback wake diagnostic must classify from the reader's own state.
///
/// #586: the selector read only `queue_depth` and `tcp_has_data` and printed
/// "the recv waiter was never woken" for a reader the same diagnostic line
/// reported as `Ready`. The two facts are independent -- what the delivery did,
/// and where the reader sat -- so the selector must read both. This is a shape
/// check, not a list of the strings: the arms may be re-worded freely, and a
/// new delivery or reader case may be added, so long as every arm's text is
/// distinct and the reader fact is derived from `reader_state` and consulted.
/// One exception: no arm may claim "never woken" verbatim, in any cell,
/// however the rest of that arm is worded. None of `queue_depth`,
/// `client_has_data` or `reader_fact` observes whether a wake happened --
/// `reader_fact` only observes where the reader sits now -- so the phrase is
/// unsupportable by any fact this selector reads, in every cell, not only the
/// one cell #586 hit.
/// claim-lint:ok: 1 of 1 preserved specimen, the service-sequence max boot 24
/// at 5c53ba59, printed reader_state=Ready beside the "never woken" text;
/// the specimen is not committed in-repo -- see
/// docs/planning/green-program/network/586-PR1-2026-09-07.md Step 0 for its
/// path and the exact bytes quoted verbatim. See #586.
fn validate_loopback_wake_classification_reads_reader_state(source: &str) -> Result<(), String> {
    let body = function_body(source, "run_loopback_recv_wake_test_inner")
        .ok_or_else(|| "missing run_loopback_recv_wake_test_inner".to_string())?;

    let derivation_start = code_text_offset(body, "let reader_fact =").ok_or_else(|| {
        "the loopback wake diagnostic derives no reader fact from reader_state".to_string()
    })?;
    let selector_start = code_text_offset(body, "let diagnostic_message =")
        .ok_or_else(|| "missing the loopback wake classification selector".to_string())?;
    if derivation_start >= selector_start {
        return Err("the reader fact is not derived before the classification".to_string());
    }
    let derivation = &body[derivation_start..selector_start];
    if !has_identifier(derivation, "reader_state") {
        return Err("the reader fact is not derived from reader_state".to_string());
    }
    if !has_identifier(derivation, "is_blocked") {
        return Err("the reader fact does not distinguish a blocked reader".to_string());
    }

    let selector_tail = &body[selector_start..];
    let selector_end = code_text_offset(selector_tail, "\n    };")
        .ok_or_else(|| "the classification selector is unterminated".to_string())?;
    let selector = &selector_tail[..selector_end];

    for fact in ["queue_depth", "client_has_data", "reader_fact"] {
        if !has_identifier(selector, fact) {
            return Err(format!(
                "the loopback wake classification does not select on {fact}"
            ));
        }
    }

    // Every non-code run inside the selector is one classification string; the
    // selector carries no comments, so this is a census of the arms rather than
    // a list of their words.
    // claim-lint:ok: code_mask marks exactly comment and literal bytes, and
    // the selector slice ends before the next statement, so the runs are the
    // 12 of 12 arm strings; see #586 and the mutation legs below.
    let mask = code_mask(selector);
    let mut arms: Vec<&str> = Vec::new();
    let mut open: Option<usize> = None;
    for (index, code) in mask.iter().enumerate() {
        if *code {
            if let Some(start) = open.take() {
                if let Some(text) = selector.get(start..index) {
                    arms.push(text);
                }
            }
        } else if open.is_none() {
            open = Some(index);
        }
    }
    if let Some(start) = open {
        if let Some(text) = selector.get(start..) {
            arms.push(text);
        }
    }
    if arms.len() < 4 {
        return Err(format!(
            "the loopback wake classification has {} arms; two facts cannot be told apart",
            arms.len()
        ));
    }
    for (position, arm) in arms.iter().enumerate() {
        if arms[..position].contains(arm) {
            return Err(format!(
                "two loopback wake classifications share the text {arm}"
            ));
        }
    }
    // #586's own misreport claimed a fact the selector cannot observe: the
    // selector reads 3 facts -- `queue_depth`, `client_has_data`,
    // `reader_fact` -- and 0 of 3 witness whether a wake happened, only where
    // the reader sits now. The shape checks above let the arms be reworded
    // freely and still pass with this exact phrase sitting in a different
    // cell (V-4: reproduced by moving it into the LeftBlocked arm without
    // touching the arm count, arm distinctness, or reader-fact derivation),
    // so this is a dedicated content check, not a shape one.
    const MISREPORT_PHRASE: &str = "never woken";
    for arm in &arms {
        if arm.contains(MISREPORT_PHRASE) {
            return Err(format!(
                "a loopback wake classification claims \"{MISREPORT_PHRASE}\" -- no fact this selector reads can prove that (#586)"
            ));
        }
    }
    Ok(())
}

#[test]
fn loopback_wake_classification_reads_reader_state() {
    validate_loopback_wake_classification_reads_reader_state(&repo_text(
        "kernel/src/test_framework/registry.rs",
    ))
    .expect("the loopback wake diagnostic classifies from delivery AND reader state");
}

#[test]
fn loopback_wake_classification_validator_rejects_a_deleted_reader_state_arm() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    validate_loopback_wake_classification_reads_reader_state(&source)
        .expect("baseline source must pass, or the mutations below prove nothing");

    // Delete-mutation: drop the reader fact from the selector's scrutinee. That
    // is the #586 defect exactly -- classify from the delivery alone.
    let dropped_arm = source.replacen(
        "match (queue_depth > 0, client_has_data, reader_fact)",
        "match (queue_depth > 0, client_has_data, ())",
        1,
    );
    assert_ne!(dropped_arm, source, "selector mutation must apply");
    assert!(
        validate_loopback_wake_classification_reads_reader_state(&dropped_arm).is_err(),
        "a selector that stops reading the reader fact must redden the validator"
    );

    // Delete-mutation: keep the scrutinee but stop deriving the fact from the
    // reader's own state.
    let dropped_derivation = source.replacen(
        "let reader_fact = match reader_state {",
        "let reader_fact = match () {",
        1,
    );
    assert_ne!(dropped_derivation, source, "derivation mutation must apply");
    assert!(
        validate_loopback_wake_classification_reads_reader_state(&dropped_derivation).is_err(),
        "a reader fact not derived from reader_state must redden the validator"
    );
}

/// V-4: the 4 shape checks above (arm count, arm distinctness, reader fact
/// derived from `reader_state` and `is_blocked`, the selector's 3-fact read)
/// stayed green 4 of 4 when the review reproduced this by replacing only the
/// LeftBlocked arm's text with the verbatim #586 misreport string -- 0 of 4
/// moved, so 0 of 4 could catch it. This is the content check that does.
#[test]
fn loopback_wake_classification_validator_rejects_the_586_misreport_phrase() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    validate_loopback_wake_classification_reads_reader_state(&source)
        .expect("baseline source must pass, or the mutation below proves nothing");

    let reintroduced = source.replacen(
        "\"delivery landed and the recv waiter left Blocked but had not run by the deadline\"",
        "\"delivery landed but the recv waiter was never woken\"",
        1,
    );
    assert_ne!(reintroduced, source, "misreport mutation must apply");
    assert!(
        validate_loopback_wake_classification_reads_reader_state(&reintroduced).is_err(),
        "the #586 misreport text returning verbatim into a different cell must redden the validator"
    );
}

#[test]
fn x86_loopback_gates_are_direct_reachable_and_have_one_marker_producer() {
    validate_x86_direct_loopback_gates(
        &repo_text("kernel/src/main.rs"),
        &repo_text("kernel/src/test_framework/registry.rs"),
    )
    .expect("x86 loopback gates remain directly reachable and exactly marked");
}

#[test]
fn deliberately_broken_x86_loopback_gate_variants_fail_the_validator() {
    let main = repo_text("kernel/src/main.rs");
    let registry = repo_text("kernel/src/test_framework/registry.rs");

    let missing_call = main.replacen(
        "kernel::test_framework::registry::run_x86_loopback_gates();",
        "",
        1,
    );
    assert_ne!(missing_call, main, "direct-call mutation must apply");
    assert!(validate_x86_direct_loopback_gates(&missing_call, &registry).is_err());

    let weak_cfg = registry.replacen(
        "#[cfg(all(feature = \"boot_tests\", target_arch = \"x86_64\"))]\n\
         pub fn run_x86_loopback_gates",
        "#[cfg(feature = \"boot_tests\")]\n\
         pub fn run_x86_loopback_gates",
        1,
    );
    assert_ne!(weak_cfg, registry, "cfg-gate mutation must apply");
    assert!(validate_x86_direct_loopback_gates(&main, &weak_cfg).is_err());

    let duplicate_marker = registry.replacen(
        "pub fn run_x86_loopback_gates() {",
        "pub fn run_x86_loopback_gates() {\n\
             crate::serial_println!(\"[TEST:network:loopback_wake_loss_counters_are_zero:PASS]\");",
        1,
    );
    assert_ne!(
        duplicate_marker, registry,
        "marker-producer mutation must apply"
    );
    assert!(validate_x86_direct_loopback_gates(&main, &duplicate_marker).is_err());

    let missing_test = registry.replacen(
        "let result = loopback_recv_wake_when_idle();",
        "let result = TestResult::Pass;",
        1,
    );
    assert_ne!(missing_test, registry, "missing-test mutation must apply");
    assert!(validate_x86_direct_loopback_gates(&main, &missing_test).is_err());
}

#[test]
fn x86_userspace_phase_launches_loopback_wake_test() {
    validate_x86_userspace_phase_launches_loopback_wake_test(&repo_text("kernel/src/main.rs"))
        .expect("kernel_main_continue loads and launches loopback_wake_test exactly once");
}

#[test]
fn x86_gate_requires_the_loopback_regression_tests() {
    validate_x86_gate_requires_the_loopback_regression_tests(&repo_text(
        "docker/qemu/run-x86-boot-tests.sh",
    ))
    .expect("x86 gate requires exactly the executable loopback regression markers");
}

#[test]
fn x86_gate_validator_rejects_missing_loopback_marker() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let marker = "\\[TEST:userspace:loopback_recv_wake:PASS\\]";
    let mutated = source.replace(marker, "");
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_weak_loopback_marker_count() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let marker = "\\[TEST:userspace:loopback_recv_wake:PASS\\]";
    let count_anchor = format!("grep -h -c '{marker}'");
    let count = source
        .find(&count_anchor)
        .expect("find userspace loopback marker count fixture");
    let weak_count_tail = source[count..].replacen("-eq 1", "-ge 1", 1);
    let mutated = format!("{}{weak_count_tail}", &source[..count]);
    assert_ne!(mutated, source, "exact-count mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_missing_userspace_failure_trap() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let failure_marker = "\\[TEST:userspace:[^]]*:FAIL";
    let mutated = source.replace(failure_marker, "");
    assert_ne!(mutated, source, "userspace FAIL trap mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_lower_userspace_exit_pin() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let mutated = source.replacen(
        "readonly EXPECTED_USERSPACE_EXITS=105",
        "readonly EXPECTED_USERSPACE_EXITS=104",
        1,
    );
    assert_ne!(mutated, source, "userspace exit-pin mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_missing_http_deadline_tally_disclosure() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let mutated = source.replacen("mid-stream stall", "", 1);
    assert_ne!(
        mutated, source,
        "http deadline disclosure mutation must apply"
    );
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_userspace_launch_validator_rejects_missing_loopback_binary_load() {
    let source = repo_text("kernel/src/main.rs");
    let mutated = source.replacen(
        "kernel::userspace_test::get_test_binary(\"loopback_wake_test\")",
        "kernel::userspace_test::get_test_binary(\"loopback_wake_test_removed\")",
        1,
    );
    assert_ne!(mutated, source, "loopback binary-load mutation must apply");
    assert!(validate_x86_userspace_phase_launches_loopback_wake_test(&mutated).is_err());
}

#[test]
fn x86_userspace_launch_validator_rejects_missing_loopback_process_launch() {
    let source = repo_text("kernel/src/main.rs");
    let launch = "process::creation::create_user_process(\n                    String::from(\"loopback_wake_test\")";
    let mutated = source.replacen(
        launch,
        "process::creation::create_user_process_removed(\n                    String::from(\"loopback_wake_test\")",
        1,
    );
    assert_ne!(
        mutated, source,
        "loopback process-launch mutation must apply"
    );
    assert!(validate_x86_userspace_phase_launches_loopback_wake_test(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_missing_resume_scorer() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let mutated = source.replace("scripts/score-boot-resume.py", "scripts/removed.py");
    assert_ne!(mutated, source, "scorer mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn x86_gate_validator_rejects_short_registry_poll_bound() {
    let source = repo_text("docker/qemu/run-x86-boot-tests.sh");
    let mutated = source.replacen("for _ in $(seq 1 900); do", "for _ in $(seq 1 300); do", 1);
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_x86_gate_requires_the_loopback_regression_tests(&mutated).is_err());
}

#[test]
fn schedule_rearms_a_blocked_pump() {
    validate_schedule_rearms_a_blocked_pump(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("Scheduler::schedule re-arms a blocked pump when loopback work remains");
}

#[test]
fn schedule_rearm_validator_rejects_missing_unblock() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let schedule = function_body(&source, "schedule").expect("find Scheduler::schedule fixture");
    let call = "self.unblock(pump_tid)";
    assert!(
        schedule.contains(call),
        "fixture mutation target must exist"
    );
    let mutated_schedule = schedule.replacen(call, "false", 1);
    let mutated = source.replacen(schedule, &mutated_schedule, 1);
    assert!(validate_schedule_rearms_a_blocked_pump(&mutated).is_err());
}

#[test]
fn wakeup_placement_is_bounded_by_online_cpus() {
    validate_wakeup_placement_is_bounded_by_online_cpus(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("wakeup and spawn placement remain online-bounded");
}

#[test]
fn wakeup_placement_validator_rejects_max_cpu_selection() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let wakeup = function_body(&source, "find_target_cpu_for_wakeup")
        .expect("find wakeup placement fixture");
    let mutated_wakeup = wakeup.replacen("self.online_cpu_count()", "MAX_CPUS", 1);
    assert_ne!(mutated_wakeup, wakeup, "fixture mutation must apply");
    let mutated = source.replacen(wakeup, &mutated_wakeup, 1);
    assert!(validate_wakeup_placement_is_bounded_by_online_cpus(&mutated).is_err());
}

#[test]
fn wakeup_placement_validator_rejects_missing_scheduling_liveness_check() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let least_loaded =
        function_body(&source, "least_loaded_cpu").expect("find spawn placement fixture");
    let mutated_least_loaded = least_loaded.replacen("self.cpu_accepts_wakeups(cpu)", "true", 1);
    assert_ne!(
        mutated_least_loaded, least_loaded,
        "fixture mutation must apply"
    );
    let mutated = source.replacen(least_loaded, &mutated_least_loaded, 1);
    assert!(validate_wakeup_placement_is_bounded_by_online_cpus(&mutated).is_err());
}

#[test]
fn wakeup_placement_validator_rejects_unfiltered_affinity_arm() {
    // The arm as the parked branch first wrote it: a pinned CPU returned early,
    // bounded by the online range with no scheduling-liveness check.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let wakeup = function_body(&source, "find_target_cpu_for_wakeup")
        .expect("find wakeup placement fixture");
    let mutated_wakeup = wakeup.replacen(
        "(home_is_this_cpu || self.cpu_accepts_wakeups(pin.cpu))",
        "true",
        1,
    );
    assert_ne!(mutated_wakeup, wakeup, "fixture mutation must apply");
    let mutated = source.replacen(wakeup, &mutated_wakeup, 1);
    assert!(validate_wakeup_placement_is_bounded_by_online_cpus(&mutated).is_err());
}

#[test]
fn wakeup_placement_validator_rejects_max_cpu_bound_on_the_affinity_arm() {
    // The other half of the same arm: a pinned CPU judged against MAX_CPUS
    // instead of the online range.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let wakeup = function_body(&source, "find_target_cpu_for_wakeup")
        .expect("find wakeup placement fixture");
    let mutated_wakeup =
        wakeup.replacen("pin.cpu < self.online_cpu_count()", "pin.cpu < MAX_CPUS", 1);
    assert_ne!(mutated_wakeup, wakeup, "fixture mutation must apply");
    let mutated = source.replacen(wakeup, &mutated_wakeup, 1);
    assert!(validate_wakeup_placement_is_bounded_by_online_cpus(&mutated).is_err());
}

#[test]
fn wakeup_placement_validator_rejects_deleting_the_liveness_filter_alone() {
    // The third leg, and the one the pairing rule exists for: the pin arm keeps
    // its online bound and loses its liveness test, which no substring rule
    // written against the least-loaded arm can see.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let wakeup = function_body(&source, "find_target_cpu_for_wakeup")
        .expect("find wakeup placement fixture");
    let mutated_wakeup = wakeup.replacen(
        "(home_is_this_cpu || self.cpu_accepts_wakeups(pin.cpu))",
        "home_is_this_cpu",
        1,
    );
    assert_ne!(mutated_wakeup, wakeup, "fixture mutation must apply");
    let mutated = source.replacen(wakeup, &mutated_wakeup, 1);
    let error = validate_wakeup_placement_is_bounded_by_online_cpus(&mutated)
        .expect_err("the pairing rule must see a pin arm that lost its liveness test");
    assert!(error.contains("scheduling-liveness test(s)"), "{error}");
}

#[test]
fn wakeup_placement_validator_accepts_the_live_source() {
    // Anti-vacuity for the mutation legs above: they mean nothing unless the
    // unmutated source passes, so that is asserted rather than implied.
    // claim-lint:ok: 3 of 3 mutation legs above depend on this control
    validate_wakeup_placement_is_bounded_by_online_cpus(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("live scheduler source passes the placement validator");
}

#[test]
fn pinned_hold_preserves_the_wake() {
    // Anti-vacuity for the five mutation legs below.
    // claim-lint:ok: 5 of 5 mutation legs below depend on this control
    validate_pinned_hold_preserves_the_wake(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("a refused pinned wake is held for its home CPU and later placed");
}

#[test]
fn pinned_hold_validator_rejects_a_hold_that_can_write_scheduler_state() {
    // The receiver IS the rule: `&mut self` is what a hold would need before it
    // could publish a blocked state or empty a queue, so taking it away is the
    // leg for both.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let mutated = source.replacen(
        "fn hold_pinned_wake_for_home(&self, thread_id: u64)",
        "fn hold_pinned_wake_for_home(&mut self, thread_id: u64)",
        1,
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_pinned_hold_preserves_the_wake(&mutated).is_err());
}

#[test]
fn pinned_hold_validator_rejects_a_hold_that_publishes_a_blocked_state() {
    // The defect the earlier park shipped, as a leg: a refusal that writes
    // `Blocked` consumes the wake its caller just published, and 0 of the paths
    // in this tree re-arm it. Injected rather than deleted, because the repair
    // is the ABSENCE of the write and a deletion leg cannot see an absence.
    // claim-lint:ok: 1 of 1 injection, on 1 of 1 hold function
    let source = repo_text("kernel/src/task/scheduler.rs");
    let hold = function_body(&source, "hold_pinned_wake_for_home").expect("find the hold fixture");
    let mutated_hold = hold.replacen(
        "let holds = ",
        "if let Some(thread) = self.get_thread_mut(thread_id) { thread.state = ThreadState::Blocked; }\n        let holds = ",
        1,
    );
    assert_ne!(mutated_hold, hold, "fixture mutation must apply");
    let mutated = source.replacen(hold, &mutated_hold, 1);
    assert!(validate_pinned_hold_preserves_the_wake(&mutated).is_err());
}

#[test]
fn pinned_hold_validator_rejects_a_hold_that_empties_a_ready_queue() {
    // The other half of the same defect: a refusal that empties each of the
    // MAX_CPUS queues reverses a publication some other path may have made.
    // claim-lint:ok: 1 of 1 injection, on 1 of 1 hold function
    let source = repo_text("kernel/src/task/scheduler.rs");
    let hold = function_body(&source, "hold_pinned_wake_for_home").expect("find the hold fixture");
    let mutated_hold = hold.replacen(
        "let holds = ",
        "for queue in self.per_cpu_queues.iter_mut() { queue.retain(|&id| id != thread_id); }\n        let holds = ",
        1,
    );
    assert_ne!(mutated_hold, hold, "fixture mutation must apply");
    let mutated = source.replacen(hold, &mutated_hold, 1);
    assert!(validate_pinned_hold_preserves_the_wake(&mutated).is_err());
}

#[test]
fn pinned_hold_validator_rejects_a_hold_that_rewrites_the_pin() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let hold = function_body(&source, "hold_pinned_wake_for_home").expect("find the hold fixture");
    let mutated_hold = hold.replacen(
        "let holds = ",
        "if let Some(thread) = self.get_thread_mut(thread_id) { thread.cpu_affinity = None; }\n        let holds = ",
        1,
    );
    assert_ne!(mutated_hold, hold, "fixture mutation must apply");
    let mutated = source.replacen(hold, &mutated_hold, 1);
    assert!(validate_pinned_hold_preserves_the_wake(&mutated).is_err());
}

#[test]
fn pinned_hold_validator_rejects_a_delivery_that_never_enqueues() {
    // Without this leg the rules above describe a refusal that is polite about
    // the thread's state and still leaves it in 0 ready queues for good.
    // claim-lint:ok: 1 of 1 enqueue in the delivery is the mutation target
    let source = repo_text("kernel/src/task/scheduler.rs");
    let delivery = function_body(&source, "deliver_pinned_wakes_for_this_cpu")
        .expect("find the delivery fixture");
    let mutated_delivery =
        delivery.replacen("self.per_cpu_queues[cpu].push_back(", "let _dropped = (", 1);
    assert_ne!(mutated_delivery, delivery, "fixture mutation must apply");
    let mutated = source.replacen(delivery, &mutated_delivery, 1);
    assert!(validate_pinned_hold_preserves_the_wake(&mutated).is_err());
}

#[test]
fn pinned_hold_validator_rejects_a_scheduler_entry_that_skips_the_delivery() {
    // A delivery that 1 of the 2 entry points runs is a delivery the other
    // path's CPUs do not make, so 2 of 2 are named and 2 of 2 are legged.
    let source = repo_text("kernel/src/task/scheduler.rs");
    for name in ["schedule", "schedule_deferred_requeue"] {
        let entry = function_body(&source, name).expect("find a scheduler entry fixture");
        let mutated_entry = entry.replacen("self.deliver_pinned_wakes_for_this_cpu();", "", 1);
        assert_ne!(
            mutated_entry, entry,
            "fixture mutation must apply for {name}"
        );
        let mutated = source.replacen(entry, &mutated_entry, 1);
        let error = validate_pinned_hold_preserves_the_wake(&mutated)
            .expect_err("a scheduler entry that skips the delivery must redden");
        assert!(error.contains(name), "{error}");
    }
}

/// Score `serial` with `gate`'s OWN verdict code, without booting.
///
/// Each aarch64 gate exposes a scoring-only entry point through an environment
/// variable; setting it makes the script skip the QEMU boot and run its verdict
/// block against the named serial. The `contains` check is a guard, not the
/// assertion: if the entry point were removed, invoking the script here would
/// boot QEMU out of a unit test, so this fails first instead.
fn score_with_gate(gate: &str, variable: &str, serial: &Path) -> (bool, String) {
    let script = repo_text(gate);
    assert!(
        script.contains(variable),
        "{gate} has no {variable} scoring-only entry point, so its verdict rules cannot be run \
         from a test -- and invoking it without one would boot QEMU"
    );
    let output = std::process::Command::new("bash")
        .arg(repo_root().join(gate))
        .env(variable, serial)
        .current_dir(repo_root())
        .output()
        .unwrap_or_else(|error| panic!("run {gate} in scoring-only mode: {error}"));
    let mut text = String::from_utf8_lossy(&output.stdout).into_owned();
    text.push_str(&String::from_utf8_lossy(&output.stderr));
    (output.status.success(), text)
}

/// `serial` with every pinned-placement census line rewritten to `replacement`,
/// or deleted when there is none.
/// claim-lint:ok: 2 of 2 uses of this helper are legs C and B below
fn rewrite_pinned_census_lines(serial: &str, replacement: Option<&str>) -> String {
    let mut out = String::new();
    for line in serial.lines() {
        if line.contains("[PINNED_HOME_CPU_UNAVAILABLE:") {
            if let Some(text) = replacement {
                out.push_str(text);
                out.push('\n');
            }
        } else {
            out.push_str(line);
            out.push('\n');
        }
    }
    out
}

#[test]
fn both_aarch64_gates_fail_on_a_pinned_placement_refusal() {
    // The gates are RUN, not grepped: a script whose census assertions have
    // been deleted still contains its pattern variables, so only the exit
    // status measures the rule. Four legs against each gate.
    let gates = [
        (
            "docker/qemu/run-aarch64-boot-test-strict.sh",
            "BREENIX_STRICT_SCORE_ONLY",
            "tests/fixtures/udp-socket-lock-aarch64-serial.txt",
        ),
        (
            "docker/qemu/run-aarch64-prod-profile-boot-test.sh",
            "BREENIX_PROD_SCORE_ONLY",
            "docs/planning/green-program/aarch64-testing/serials/slice3e/02-prod-boot1-serial.txt",
        ),
    ];
    let scratch =
        std::env::temp_dir().join(format!("breenix-pinned-gate-legs-{}", std::process::id()));
    fs::create_dir_all(&scratch).expect("create the scratch directory for the gate legs");
    for (gate, variable, baseline) in gates {
        let mut serial = repo_text(baseline);
        // Synthetic scorer fixture extension for the new production control;
        // the saved historical serial remains unchanged. This is not a boot.
        if variable == "BREENIX_PROD_SCORE_ONLY" {
            serial.push_str(
                "\n[INPUT_INJECT_NEGATIVE_CONTROL:request=0xb8130004:probe=-25:verdict=PASS]\n",
            );
        }
        assert!(
            serial.contains(
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=0:stack_home_conflict=0]"
            ),
            "{baseline} is the green baseline for {gate} and must carry the census"
        );
        let leg = |name: &str, body: &str| {
            let path = scratch.join(format!("{variable}-{name}.txt"));
            fs::write(&path, body).expect("write a gate leg serial");
            score_with_gate(gate, variable, &path)
        };

        // Leg A. Anti-vacuity for the four below: a gate that rejected every
        // serial would satisfy them without scoring anything.
        // claim-lint:ok: 1 of 5 legs is this one, and it is what keeps the
        // other 4 from being satisfied by a gate that rejects everything
        let (passed, output) = leg("green", &serial);
        assert!(
            passed,
            "{gate} must pass the extended scorer fixture, or the failing legs below \
             say nothing: {output}"
        );

        // Leg B. One census line reports a refusal. That is the class the
        // counter exists for.
        let (passed, output) = leg(
            "refused",
            &serial.replacen(
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=0:stack_home_conflict=0]",
                "[PINNED_HOME_CPU_UNAVAILABLE:count=3:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=0:stack_home_conflict=0]",
                1,
            ),
        );
        assert!(
            !passed,
            "{gate} passed a serial reporting a pinned-placement refusal: {output}"
        );

        // Leg C. The census never printed. A gate that only fails on a non-zero
        // reading is satisfied by a kernel that stopped reporting.
        // claim-lint:ok: this leg deletes 4 of 4 census lines in the strict
        // baseline and 1 of 1 in the production one
        let (passed, output) = leg("missing", &rewrite_pinned_census_lines(&serial, None));
        assert!(
            !passed,
            "{gate} passed a serial with no pinned-placement census at all: {output}"
        );

        // Leg D. A hold happened AFTER the last census emission, so every
        // census line still reads zero and only the one-shot marker says so.
        // Without this leg the production gate, whose census is emitted once
        // before userspace, would score such a boot green.
        // claim-lint:ok: 1 of 1 census line in the production baseline reads
        // count=0, so only the appended marker distinguishes this leg
        let mut late_hold = serial.clone();
        late_hold.push_str("[PINNED_HOME_CPU_UNAVAILABLE:first:tid=7:home=1:cpu=0:count=1]\n");
        let (passed, output) = leg("late-hold", &late_hold);
        assert!(
            !passed,
            "{gate} passed a serial whose one-shot marker reports a hold: {output}"
        );

        // Leg E. A hold-pen pin was overridden. The gate scores a census line
        // by comparing it against the zero literal rather than by matching each
        // field, so 1 of the 2 fields this round added is gated by the same
        // rule as the 2 that were there before it -- which is what this leg
        // measures.
        // claim-lint:ok: 4 of 4 census fields are covered by the comparison,
        // and 2 of them are varied by a leg here
        let (passed, output) = leg(
            "hold-pen",
            &serial.replacen(
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=0:stack_home_conflict=0]",
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=2:delivered=0:migration_refused=0:stack_home_conflict=0]",
                1,
            ),
        );
        assert!(
            !passed,
            "{gate} passed a serial reporting a silently overridden hold-pen pin: {output}"
        );

        // Leg F. A migration site refused to move a pinned thread. That is the
        // field slice 3e added, and it is gated by the same whole-line
        // comparison as the 4 before it -- which is what this leg measures, on
        // the field that was not there yesterday.
        // claim-lint:ok: 6 of 6 census fields are covered by the comparison,
        // and 3 of them are varied by a leg here
        let (passed, output) = leg(
            "migration-refused",
            &serial.replacen(
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=0:stack_home_conflict=0]",
                "[PINNED_HOME_CPU_UNAVAILABLE:count=0:publish_discarded=0:hold_pen_migrated=0:delivered=0:migration_refused=5:stack_home_conflict=0]",
                1,
            ),
        );
        assert!(
            !passed,
            "{gate} passed a serial reporting a refused migration: {output}"
        );
    }

    fs::remove_dir_all(&scratch).ok();
}

/// The strict gate scores slice 3e's pin-guard oracle, and the production gate
/// refuses to see it at all.
///
/// Two directions, because the two gates want opposite things. On the strict
/// profile the line must be there and must say PASS: a verdict of FAIL is the
/// shape `origin/main` prints -- the FAIL line below is the one
/// `serials/slice3e/03-red-on-main-oracle-serial.txt` carries, quoted rather
/// than invented -- and a missing line is a kernel that stopped measuring. On
/// the production profile the line must be absent, because the probe is
/// boot-tests-only scaffolding and its presence would mean it reached a shipped
/// kernel.
/// claim-lint:ok: 4 of 4 legs here run the gates' own verdict code, and 3 of
/// the 4 expect a red
#[test]
fn the_gates_score_the_pin_guard_oracle_in_opposite_directions() {
    let scratch = std::env::temp_dir().join(format!(
        "breenix-pin-guard-gate-legs-{}",
        std::process::id()
    ));
    fs::create_dir_all(&scratch).expect("create the scratch directory for the oracle gate legs");
    let leg = |name: &str, body: &str, gate: &str, variable: &str| {
        let path = scratch.join(format!("{variable}-{name}.txt"));
        fs::write(&path, body).expect("write an oracle gate leg serial");
        score_with_gate(gate, variable, &path)
    };

    let strict = "docker/qemu/run-aarch64-boot-test-strict.sh";
    let strict_serial = repo_text("tests/fixtures/udp-socket-lock-aarch64-serial.txt");
    let pass_line = strict_serial
        .lines()
        .find(|line| line.contains("[PIN_GUARD_ORACLE:aarch64:"))
        .expect("the strict baseline carries the oracle line")
        .to_string();
    assert!(
        pass_line.contains(":verdict=PASS]"),
        "the strict baseline's oracle line must be the green one: {pass_line}"
    );

    // Leg A. Anti-vacuity: the gate accepts the serial it was recorded on.
    let (passed, output) = leg("green", &strict_serial, strict, "BREENIX_STRICT_SCORE_ONLY");
    assert!(
        passed,
        "{strict} must pass the extended scorer fixture: {output}"
    );

    // Leg B. The oracle's verdict is FAIL -- the reading origin/main produces.
    let red_line = repo_text(
        "docs/planning/green-program/aarch64-testing/serials/slice3e/03-red-on-main-oracle-serial.txt",
    )
    .lines()
    .find(|line| line.contains("[PIN_GUARD_ORACLE:aarch64:"))
    .expect("the red-on-main capture carries the oracle line")
    .to_string();
    assert!(
        red_line.contains(":verdict=FAIL]"),
        "the red-on-main capture's oracle line must be the failing one: {red_line}"
    );
    let (passed, output) = leg(
        "verdict-fail",
        &strict_serial.replacen(pass_line.as_str(), red_line.as_str(), 1),
        strict,
        "BREENIX_STRICT_SCORE_ONLY",
    );
    assert!(
        !passed,
        "{strict} passed a serial whose pin-guard oracle reported FAIL: {output}"
    );

    // Leg C. The oracle line is gone. A gate that only fails on a FAIL verdict
    // is satisfied by a kernel that stopped running the oracle.
    let without_oracle: String = strict_serial
        .lines()
        .filter(|line| !line.contains("[PIN_GUARD_ORACLE:"))
        .map(|line| format!("{line}\n"))
        .collect();
    let (passed, output) = leg(
        "missing",
        &without_oracle,
        strict,
        "BREENIX_STRICT_SCORE_ONLY",
    );
    assert!(
        !passed,
        "{strict} passed a serial with no pin-guard oracle line at all: {output}"
    );

    // Leg D. The production gate must refuse the oracle's presence.
    let production = "docker/qemu/run-aarch64-prod-profile-boot-test.sh";
    let mut production_serial = repo_text(
        "docs/planning/green-program/aarch64-testing/serials/slice3e/02-prod-boot1-serial.txt",
    );
    assert!(
        !production_serial.contains("[PIN_GUARD_ORACLE:"),
        "the production baseline must not carry the boot-tests-only oracle line"
    );
    production_serial.push_str(&pass_line);
    production_serial.push('\n');
    let (passed, output) = leg(
        "oracle-in-production",
        &production_serial,
        production,
        "BREENIX_PROD_SCORE_ONLY",
    );
    assert!(
        !passed,
        "{production} passed a serial carrying the boot-tests-only pin-guard oracle: {output}"
    );

    fs::remove_dir_all(&scratch).ok();
}

#[test]
fn scheduling_paths_reclaim_unschedulable_cpu_queues() {
    validate_scheduling_paths_reclaim_unschedulable_cpu_queues(&repo_text(
        "kernel/src/task/scheduler.rs",
    ))
    .expect("both scheduling paths reclaim unschedulable CPU queues");
}

#[test]
fn unschedulable_reclaim_validator_rejects_missing_deferred_reclaim() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let deferred = function_body(&source, "schedule_deferred_requeue")
        .expect("find deferred scheduling fixture");
    let mutated_deferred = deferred.replacen("self.reclaim_unschedulable_cpu_queues();", "", 1);
    assert_ne!(mutated_deferred, deferred, "fixture mutation must apply");
    let mutated = source.replacen(deferred, &mutated_deferred, 1);
    assert!(validate_scheduling_paths_reclaim_unschedulable_cpu_queues(&mutated).is_err());
}

/// A pin-blind migration site: a function in `kernel/src/task/scheduler.rs`
/// that pushes a thread onto a `per_cpu_queues` slot without reading the pin
/// anywhere in its own body -- neither the `cpu_affinity` field nor `CpuPin`
/// directly, nor through any of the 3 functions that read the field on this
/// file's behalf (`find_target_cpu_for_wakeup`, the wake path's placement
/// rule; `pinned_wake_is_waiting_here`, the hold's delivery predicate; and
/// `retain_cpu_affine_thread`, slice 3e's migration guard).
///
/// Slice 3d enumerated 11 of these and owed the guard at 11 of 11. Slice 3e
/// landed it, so the expected count below is 0: the number of places in this
/// file that can move a thread between per-CPU queues without asking whether
/// it is allowed to.
///
/// Census-shaped, not a name list: this walks each `.push_back(` /
/// `.push_front(` call on a `per_cpu_queues[..]` slot in the file and
/// classifies each one by what its own function body does, so a new
/// pin-blind push added anywhere in the file changes the count and reddens
/// `pin_blind_migration_census_matches_the_slice_3e_table` -- a table of
/// today's sites by name would not catch that.
///
/// Two shapes are excluded because they provably cannot move a pinned
/// thread anywhere its pin forbids:
///   1. the pushed value is `current_id` or `next_thread_id` -- this file's
///      two names for the thread the scheduling decision already concerns,
///      going back onto the CPU it is already the current or next thread
///      of, having stayed on it the whole time;
///   2. the push is preceded, in the same function, by a `.pop_front()` on
///      the textually identical `per_cpu_queues[<idx>]` slot -- a decline
///      that puts a thread back exactly where it was just taken from.
/// A third exclusion is scope, not shape: the 3 functions gated behind a
/// test-only feature (`coreproof`, `ec0_fault_inject`, `boot_tests`)
/// manufacture state for a different primitive's test and do not ship in a
/// production kernel, so they are not counted.
///
/// `add_thread_inner` (the publish-time placement arm) and the 6 wake-path
/// functions (`unblock`, `unblock_for_signal`, `unblock_for_child_exit`,
/// `wake_io_thread_locked`, `wake_expired_timers`, and the hold's own
/// delivery, `deliver_pinned_wakes_for_this_cpu`) are excluded by the pin
/// check itself: each reads `cpu_affinity` in its own body or is the
/// delivery predicate that does.
#[derive(Debug)]
struct PinBlindSite {
    line: usize,
    function: String,
    index_expr: String,
}

fn pin_blind_migration_sites(source: &str) -> Vec<PinBlindSite> {
    let mask = code_mask(source);
    let masked_bytes: Vec<u8> = source
        .bytes()
        .zip(mask.iter().copied())
        .map(|(byte, code)| if code { byte } else { b' ' })
        .collect();
    let masked =
        String::from_utf8(masked_bytes).expect("scheduler.rs is ASCII outside comments/strings");

    let spans = function_spans(source);
    let test_only_features = [
        "feature = \"coreproof\"",
        "feature = \"ec0_fault_inject\"",
        "feature = \"boot_tests\"",
    ];

    let mut sites = Vec::new();
    let mut search_from = 0usize;
    while let Some(rel) = masked[search_from..].find("per_cpu_queues[") {
        let bracket_open = search_from + rel + "per_cpu_queues[".len();
        let Some(rel_close) = masked[bracket_open..].find(']') else {
            break;
        };
        let idx_text = masked[bracket_open..bracket_open + rel_close]
            .trim()
            .to_string();
        let after_bracket = bracket_open + rel_close + 1;
        let tail = &masked[after_bracket..];
        let trimmed_tail = tail.trim_start();
        search_from = after_bracket + 1;

        let call_kind_len = if trimmed_tail.starts_with(".push_back(") {
            Some(".push_back(".len())
        } else if trimmed_tail.starts_with(".push_front(") {
            Some(".push_front(".len())
        } else {
            None
        };
        let Some(call_kind_len) = call_kind_len else {
            continue;
        };
        let arg_text = trimmed_tail[call_kind_len..].trim_start();
        let arg: String = arg_text
            .chars()
            .take_while(|c| c.is_alphanumeric() || *c == '_')
            .collect();

        let Some(span) = spans
            .iter()
            .filter(|s| s.open <= bracket_open && bracket_open <= s.close)
            .min_by_key(|s| s.close - s.open)
        else {
            continue;
        };

        let body = normalized_code(&source[span.open..=span.close]);
        let pin_aware = body.contains("cpu_affinity")
            || body.contains("CpuPin")
            || body.contains("find_target_cpu_for_wakeup(")
            || body.contains("pinned_wake_is_waiting_here(")
            || body.contains("retain_cpu_affine_thread(");
        if pin_aware {
            continue;
        }

        // Scope exclusion: skip a function gated behind a test-only
        // feature. The attribute region is the raw source between the end
        // of the nearest earlier function (in file order) and this
        // function's own open brace, which is where an item's
        // `#[cfg(...)]` attributes live.
        let prev_close = spans
            .iter()
            .filter(|s| s.close < span.open)
            .map(|s| s.close)
            .max()
            .unwrap_or(0);
        let attr_region = &source[prev_close..span.open];
        if test_only_features
            .iter()
            .any(|marker| attr_region.contains(marker))
        {
            continue;
        }

        if arg == "current_id" || arg == "next_thread_id" {
            continue;
        }

        // Same-index decline exclusion: any earlier `.pop_front()` in this
        // same function on the textually identical `per_cpu_queues[<idx>]`
        // slot means this push puts the thread back where it was just
        // taken from.
        let scan_region = &masked[span.open..bracket_open];
        let mut declined = false;
        let mut pop_search_from = 0usize;
        while let Some(rel) = scan_region[pop_search_from..].find("per_cpu_queues[") {
            let pop_bracket_open = pop_search_from + rel + "per_cpu_queues[".len();
            let Some(pop_rel_close) = scan_region[pop_bracket_open..].find(']') else {
                break;
            };
            let pop_idx = scan_region[pop_bracket_open..pop_bracket_open + pop_rel_close].trim();
            let pop_after = pop_bracket_open + pop_rel_close + 1;
            if pop_idx == idx_text
                && scan_region[pop_after..]
                    .trim_start()
                    .starts_with(".pop_front(")
            {
                declined = true;
                break;
            }
            pop_search_from = pop_after + 1;
        }
        if declined {
            continue;
        }

        let line = source[..bracket_open].matches('\n').count() + 1;
        sites.push(PinBlindSite {
            line,
            function: span.name.clone(),
            index_expr: idx_text,
        });
    }
    sites
}

/// Slice 3d's R157 ruling left 11 of 11 reclaim, steal and requeue sites
/// unguarded and enumerated them (SLICE3D-2026-09-05.md section 13, "What is
/// not claimed"). Slice 3e closed the list: the table in
/// SLICE3E-2026-09-05.md names 11 of 11 with the consultation each one gained,
/// and the count this rule pins is now 0.
///
/// It stays a census rather than becoming a "the guard is called 11 times"
/// count, because the thing worth forbidding is a NEW pin-blind push, and a
/// call count would not see one added inside a function that already calls the
/// guard. The count is 0 exactly when no such push exists.
#[test]
fn pin_blind_migration_census_matches_the_slice_3e_table() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let sites = pin_blind_migration_sites(&source);
    assert_eq!(
        sites.len(),
        0,
        "kernel/src/task/scheduler.rs has {} pin-blind per_cpu_queues \
         migration sites (found: {:?}); slice 3e closed the 11 that \
         SLICE3D-2026-09-05.md section 13 enumerated and SLICE3E-2026-09-05.md \
         tables, so every migration site must consult the thread's pin before \
         it pushes -- add the `retain_cpu_affine_thread` guard at the site, or \
         table the new site and its argument before changing this expectation",
        sites.len(),
        sites
            .iter()
            .map(|s| format!("{}:{}({})", s.function, s.line, s.index_expr))
            .collect::<Vec<_>>()
    );
}

/// Anti-vacuity for the census above, in both directions. A rule that expects
/// 0 is satisfied by a detector that finds 0 sites in any source at all, so the
/// detector is fed 1 source it must count and 1 it must not.
///
/// These are synthetic fixtures rather than mutations of the live file so they
/// run on each pass of the suite rather than only when someone remembers to
/// mutate the kernel by hand.
#[test]
fn pin_blind_migration_census_counts_a_bare_push() {
    let synthetic = "impl Scheduler {\n\
        fn spare_migration_probe(&mut self, thread_id: u64, cpu: usize) {\n\
            self.per_cpu_queues[cpu].push_back(thread_id);\n\
        }\n\
    }\n";
    let sites = pin_blind_migration_sites(synthetic);
    assert_eq!(
        sites.len(),
        1,
        "the census must count a bare per_cpu_queues push that reads no pin \
         (found: {:?})",
        sites
            .iter()
            .map(|s| format!("{}({})", s.function, s.index_expr))
            .collect::<Vec<_>>()
    );
    assert_eq!(sites[0].function, "spare_migration_probe");
}

#[test]
fn pin_blind_migration_census_does_not_count_a_guarded_push() {
    let synthetic = "impl Scheduler {\n\
        fn spare_migration_probe(&mut self, thread_id: u64, cpu: usize) {\n\
            if !self.retain_cpu_affine_thread(thread_id, cpu) {\n\
                self.per_cpu_queues[cpu].push_back(thread_id);\n\
            }\n\
        }\n\
    }\n";
    assert!(
        pin_blind_migration_sites(synthetic).is_empty(),
        "the census must not count a push whose function consults the pin guard"
    );
}

#[test]
fn pin_guard_refuses_a_foreign_placement() {
    validate_pin_guard_refuses_a_foreign_placement(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("the migration guard keeps a per-CPU worker on the CPU its pin names");
}

#[test]
fn pin_guard_validator_rejects_an_unconditional_move() {
    // The mutation the rule exists for: the guard still reads the pin, still
    // counts, and then returns false on 1 of 1 remaining arm -- so 11 of 11
    // sites place the thread exactly where they would have without a guard,
    // while the census above stays green because the marker is still there.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").expect("find the guard fixture");
    let mutated_body = body.replace("return true;", "return false;");
    let mutated_body = {
        let tail = mutated_body
            .rfind("        true\n")
            .expect("the guard's trailing refusal");
        format!(
            "{}        false\n{}",
            &mutated_body[..tail],
            &mutated_body[tail + "        true\n".len()..]
        )
    };
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_pin_guard_refuses_a_foreign_placement(&mutated).is_err());
}

#[test]
fn pin_guard_validator_rejects_a_guard_that_never_places_on_the_pinned_cpu() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").expect("find the guard fixture");
    let mutated_body = body.replace(
        "self.per_cpu_queues[pin.cpu].push_back(thread_id);",
        "self.per_cpu_queues[taking_cpu].push_back(thread_id);",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_pin_guard_refuses_a_foreign_placement(&mutated).is_err());
}

#[test]
fn pin_guard_validator_rejects_a_refusal_that_drops_the_hold() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").expect("find the guard fixture");
    let mutated_body = body.replace(
        "self.hold_pinned_wake_for_home(thread_id);",
        "let _ = thread_id;",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_pin_guard_refuses_a_foreign_placement(&mutated).is_err());
}

#[test]
fn pin_guard_validator_rejects_an_unbounded_pinned_index() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").expect("find the guard fixture");
    let mutated_body = body.replace(
        "if pin.cpu >= self.online_cpu_count() {",
        "if pin.cpu >= MAX_CPUS {",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_pin_guard_refuses_a_foreign_placement(&mutated).is_err());
}

#[test]
fn pin_guard_validator_rejects_a_fast_path_that_reads_no_pin_count() {
    // The mutation that would turn the constant-cost arm into a plain early
    // return: the guard keeps its 9 later arms and reaches 0 of them.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").expect("find the guard fixture");
    let mutated_body = body.replace(
        "super::thread::CPU_PINS_STAMPED.load(Ordering::Relaxed) == 0",
        "taking_cpu == usize::MAX",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_pin_guard_refuses_a_foreign_placement(&mutated).is_err());
}

#[test]
fn pin_guard_calls_decide_the_placement() {
    validate_pin_guard_calls_decide_the_placement(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("every migration site acts on the guard's answer");
}

#[test]
fn pin_guard_call_validator_rejects_a_discarded_answer() {
    // A site that consults the pin and then pushes anyway: the census sees the
    // marker and passes, so this is the rule that catches it.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let mutated = source.replacen(
        "if !self.retain_cpu_affine_thread(previous, cpu) {\n                self.per_cpu_queues[cpu].push_back(previous);\n            }",
        "let _ = self.retain_cpu_affine_thread(previous, cpu);\n            self.per_cpu_queues[cpu].push_back(previous);",
        1,
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_pin_guard_calls_decide_the_placement(&mutated).is_err());
}

/// The selection-side per-CPU stack reroute reports the pin it overrules.
///
/// `percpu_stack_home_cpu` decides 4 of this file's pushes -- the steal-loop
/// reroute in `schedule` and in `schedule_deferred_requeue` -- and each of
/// those pushes `continue`s before `retain_cpu_affine_thread` is reached, so
/// the guard's own arm 7 sees 0 of the 4. Overruling the pin there is correct:
/// the per-CPU stack slot under a saved SP is a hardware fact and a pin is a
/// software claim. Being the last reader of the disagreement is what obliges
/// this function to count it into the same gate-failing counter arm 7 uses,
/// rather than leaving 4 arms where a violated pin moves a thread in silence.
fn validate_percpu_stack_reroute_counts_a_pin_conflict(source: &str) -> Result<(), String> {
    if compact_code(source)
        .matches("PINNED_STACK_HOME_CONFLICT.fetch_add(")
        .count()
        != 2
    {
        return Err("PINNED_STACK_HOME_CONFLICT requires its two documented writers".into());
    }
    let body = function_body(source, "percpu_stack_home_cpu")
        .ok_or("kernel/src/task/scheduler.rs defines no percpu_stack_home_cpu reroute")?;
    let compact = compact_code(body);
    if !compact.contains("cpu_affinity") {
        return Err(
            "the per-CPU stack reroute never reads the pin it overrules, so the 4 pushes it \
             decides cannot report a pin the reroute contradicts"
                .into(),
        );
    }
    if !compact.contains("PINNED_STACK_HOME_CONFLICT.fetch_add(1,Ordering::Relaxed)") {
        return Err(
            "the per-CPU stack reroute overrules a pin without counting it, so a per-CPU \
             worker can be moved off the CPU its pin names with 0 counters moving"
                .into(),
        );
    }
    if !compact.contains("pin.per_cpu_worker&&pin.cpu!=slot") {
        return Err(
            "the per-CPU stack reroute counts something other than a per-CPU worker pin \
             disagreeing with the slot its saved kernel SP stands in"
                .into(),
        );
    }
    Ok(())
}

#[test]
fn percpu_stack_reroute_counts_a_pin_conflict() {
    validate_percpu_stack_reroute_counts_a_pin_conflict(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("the per-CPU stack reroute counts the pin it overrules");
}

#[test]
fn percpu_stack_reroute_validator_rejects_a_silent_override() {
    // The state the rule exists for, and the one round 1 of this branch
    // shipped: the reroute reads the pin, decides against it, and reports 0.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "percpu_stack_home_cpu").expect("find the reroute fixture");
    let mutated_body = body.replace(
        "PINNED_STACK_HOME_CONFLICT.fetch_add(1, Ordering::Relaxed);",
        "let _ = slot;",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_percpu_stack_reroute_counts_a_pin_conflict(&mutated).is_err());
}

#[test]
fn percpu_stack_reroute_validator_rejects_a_reroute_that_reads_no_pin() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "percpu_stack_home_cpu").expect("find the reroute fixture");
    let mutated_body = body.replace(
        "let affinity = thread.cpu_affinity;",
        "let affinity: Option<super::thread::CpuPin> = None;",
    );
    assert_ne!(mutated_body, body, "fixture mutation must apply");
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_percpu_stack_reroute_counts_a_pin_conflict(&mutated).is_err());
}

/// A `CpuPin` value in the kernel is built by a constructor that counts it.
///
/// `retain_cpu_affine_thread` answers "no constraint" from
/// `CPU_PINS_STAMPED == 0` without reading a thread row, so that counter is
/// what makes the guard cost 1 load and 1 compare at each of its 11 sites in a
/// profile that stamps no pin. A pin that reached a thread without passing
/// through a counting constructor would switch the guard off at 11 of 11 sites
/// and move 0 counters doing it. Two shapes hold it down: both constructors
/// count, and kernel/src holds 0 `CpuPin { .. }` literals outside the type's
/// own definition -- a struct literal being the 1 way to build one without a
/// constructor.
fn validate_every_cpu_pin_is_minted(sources: &[(String, String)]) -> Result<(), String> {
    let thread_rs = sources
        .iter()
        .find(|(path, _)| path == "kernel/src/task/thread.rs")
        .map(|(_, text)| text.as_str())
        .ok_or("kernel/src/task/thread.rs is not among the kernel sources")?;

    for constructor in ["per_cpu_worker", "hold_pen"] {
        let body = function_body(thread_rs, constructor)
            .ok_or_else(|| format!("kernel/src/task/thread.rs defines no CpuPin::{constructor}"))?;
        if !compact_code(body).contains("CPU_PINS_STAMPED.fetch_add(1,Ordering::Relaxed)") {
            return Err(format!(
                "CpuPin::{constructor} builds a pin without counting it, so a thread can carry \
                 a pin while CPU_PINS_STAMPED reads 0 and the migration guard skips its arms"
            ));
        }
    }

    let mut literals = Vec::new();
    for (path, text) in sources {
        let mask = code_mask(text);
        let masked: String = text
            .bytes()
            .zip(mask.iter().copied())
            .map(|(byte, code)| if code { byte as char } else { ' ' })
            .collect();
        let mut searched = 0usize;
        while let Some(relative) = masked[searched..].find("CpuPin") {
            let offset = searched + relative;
            searched = offset + "CpuPin".len();
            if !masked[searched..].trim_start().starts_with('{') {
                continue;
            }
            // Two `CpuPin {` openings are not literals: the type's own
            // definition, and the `impl` block that holds the 2 constructors.
            let before = masked[..offset].trim_end();
            if before.ends_with("struct") || before.ends_with("impl") {
                continue;
            }
            let line = text[..offset].matches('\n').count() + 1;
            literals.push(format!("{path}:{line}"));
        }
    }
    if !literals.is_empty() {
        return Err(format!(
            "kernel/src builds a CpuPin by struct literal at {literals:?}, bypassing the \
             constructors that count into CPU_PINS_STAMPED"
        ));
    }
    Ok(())
}

#[test]
fn every_cpu_pin_is_minted_by_a_counting_constructor() {
    validate_every_cpu_pin_is_minted(&kernel_sources())
        .expect("every CpuPin is built by a constructor that counts it");
}

#[test]
fn cpu_pin_mint_validator_rejects_an_uncounted_constructor() {
    let mut sources = kernel_sources();
    let thread_rs = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/task/thread.rs")
        .expect("find the thread source fixture");
    let mutated = thread_rs
        .1
        .replacen("CPU_PINS_STAMPED.fetch_add(1, Ordering::Relaxed);", "", 1);
    assert_ne!(mutated, thread_rs.1, "fixture mutation must apply");
    thread_rs.1 = mutated;
    assert!(validate_every_cpu_pin_is_minted(&sources).is_err());
}

#[test]
fn cpu_pin_mint_validator_rejects_a_struct_literal() {
    let mut sources = kernel_sources();
    let scheduler = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/task/scheduler.rs")
        .expect("find the scheduler source fixture");
    scheduler.1.push_str(
        "\nfn spare_pin_probe(cpu: usize) -> super::thread::CpuPin {\n    \
         super::thread::CpuPin { cpu, per_cpu_worker: true }\n}\n",
    );
    assert!(validate_every_cpu_pin_is_minted(&sources).is_err());
}

/// Site 9 drains its own handoff slot before it asks the guard where to place.
///
/// `resolve_exception_cleanup_previous_thread` reads 5 predicates, then places.
/// The guard's hold arm asks whether any reachability record still names the
/// thread, and this CPU's `previous_thread` slot is 1 of the 5 records it asks
/// about -- so clearing the slot after the placement leaves this site's own
/// about-to-be-cleared slot answering "yes" on 1 of 1 pass, and the hold can
/// never be taken from here. 0 of the 5 predicates read this slot
/// (`is_other_deferred` skips this CPU), so the clear is free to move ahead of
/// them.
fn validate_previous_thread_slot_clears_before_the_guard(source: &str) -> Result<(), String> {
    let body = function_body(source, "resolve_exception_cleanup_previous_thread").ok_or(
        "kernel/src/task/scheduler.rs defines no resolve_exception_cleanup_previous_thread",
    )?;
    let compact = compact_code(body);
    let clear = compact
        .find("self.cpu_state[cpu].previous_thread=None;")
        .ok_or("the previous-thread drain never clears the slot it drained")?;
    let guard = compact
        .find("self.retain_cpu_affine_thread(previous,cpu)")
        .ok_or("the previous-thread drain never consults the migration guard")?;
    if clear > guard {
        return Err(
            "the previous-thread drain clears its slot after it consults the guard, so the \
             guard's hold arm reads this CPU's own stale slot and 0 holds can be taken here"
                .into(),
        );
    }
    Ok(())
}

#[test]
fn previous_thread_slot_clears_before_the_guard() {
    validate_previous_thread_slot_clears_before_the_guard(&repo_text(
        "kernel/src/task/scheduler.rs",
    ))
    .expect("site 9 drains its handoff slot before it consults the guard");
}

#[test]
fn previous_thread_order_validator_rejects_a_late_clear() {
    // The order round 1 of this branch shipped.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "resolve_exception_cleanup_previous_thread")
        .expect("find the drain fixture");
    let clear = "        self.cpu_state[cpu].previous_thread = None;\n";
    assert!(body.contains(clear), "fixture statement must be present");
    let without = body.replacen(clear, "", 1);
    let close = without.rfind('}').expect("the drain's closing brace");
    let mutated_body = format!("{}{}{}", &without[..close], clear, &without[close..]);
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_previous_thread_slot_clears_before_the_guard(&mutated).is_err());
}

#[test]
fn thread_placement_honours_the_cpu_pin() {
    validate_thread_placement_honours_the_cpu_pin(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("a pinned thread is queued to the CPU its pin names");
}

#[test]
fn thread_placement_validator_rejects_a_deleted_pin_arm() {
    // The mutation this rule exists to catch: the placement arm reverts to the
    // unconditional least-loaded choice, so a thread that names a CPU is queued
    // wherever load balancing puts it instead.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let placement = function_body(&source, "add_thread_inner").expect("find placement fixture");
    let arm_start = placement
        .find("let target = cpu_affinity")
        .expect("find the pin arm");
    let arm_end = arm_start
        + placement[arm_start..]
            .find(';')
            .expect("the pin arm terminates")
        + 1;
    let mutated_placement = format!(
        "{}let target = self.least_loaded_cpu();{}",
        &placement[..arm_start],
        &placement[arm_end..]
    );
    assert_ne!(mutated_placement, placement, "fixture mutation must apply");
    let mutated = source.replacen(placement, &mutated_placement, 1);
    assert!(validate_thread_placement_honours_the_cpu_pin(&mutated).is_err());
}

#[test]
fn thread_placement_validator_rejects_an_unbounded_pin() {
    // A pin that names a queue above the online count starves, in the words of
    // the comment on `online_cpu_count` itself: no thread runs there and the
    // reschedule IPI helpers refuse the target.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let placement = function_body(&source, "add_thread_inner").expect("find placement fixture");
    let mutated_placement = without_call_matching(placement, "filter", "online_cpu_count")
        .expect("the pin arm bounds by the online range");
    assert_ne!(mutated_placement, placement, "fixture mutation must apply");
    let mutated = source.replacen(placement, &mutated_placement, 1);
    assert!(validate_thread_placement_honours_the_cpu_pin(&mutated).is_err());
}

#[test]
fn cpu_pin_records_its_reason() {
    validate_cpu_pin_records_its_reason(&repo_text("kernel/src/task/thread.rs"))
        .expect("every CpuPin constructor names the reason the pin exists");
}

#[test]
fn cpu_pin_reason_validator_rejects_a_kindless_constructor() {
    let source = repo_text("kernel/src/task/thread.rs");
    let mutated = source.replacen("            per_cpu_worker: false,\n", "", 1);
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_cpu_pin_records_its_reason(&mutated).is_err());
}

#[test]
fn cpu_pin_reason_validator_rejects_a_bare_cpu_index() {
    let source = repo_text("kernel/src/task/thread.rs");
    let mutated = source.replacen(
        "pub cpu_affinity: Option<CpuPin>",
        "pub cpu_affinity: Option<usize>",
        1,
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_cpu_pin_records_its_reason(&mutated).is_err());
}

#[test]
fn thread_placement_validator_accepts_a_stronger_bound() {
    // The repair slice 3d owes this arm: bound the pinned CPU by the
    // scheduling-liveness test the fall-through already applies, instead of by
    // the online range alone. The rule must not forbid its own repair.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let placement = function_body(&source, "add_thread_inner").expect("find placement fixture");
    let strengthened = placement.replacen(
        "*cpu < self.online_cpu_count()",
        "*cpu < self.online_cpu_count() && self.cpu_accepts_wakeups(*cpu)",
        1,
    );
    assert_ne!(strengthened, placement, "fixture mutation must apply");
    let mutated = source.replacen(placement, &strengthened, 1);
    validate_thread_placement_honours_the_cpu_pin(&mutated)
        .expect("a strictly stronger placement bound satisfies the rule");
}

#[test]
fn thread_placement_validator_accepts_a_pin_kind_prefilter() {
    // The other repair the neighbourhood is heading for: a per-CPU-worker pin
    // and a hold pen need different dispositions, so the arm may filter on the
    // pin's kind before resolving it to a CPU.
    let source = repo_text("kernel/src/task/scheduler.rs");
    let placement = function_body(&source, "add_thread_inner").expect("find placement fixture");
    let prefiltered = placement.replacen(
        ".map(|pin| pin.cpu)",
        ".filter(|pin| pin.per_cpu_worker)\n            .map(|pin| pin.cpu)",
        1,
    );
    assert_ne!(prefiltered, placement, "fixture mutation must apply");
    let mutated = source.replacen(placement, &prefiltered, 1);
    validate_thread_placement_honours_the_cpu_pin(&mutated)
        .expect("a pin-kind pre-filter satisfies the rule");
}

#[test]
fn cpu_pin_reason_validator_accepts_a_non_constructor_method() {
    // An accessor builds no pin, so it has no reason to name. It is the shape
    // slice 3e's reclaim disposition reads the kind through.
    let source = repo_text("kernel/src/task/thread.rs");
    let accessor = "impl CpuPin {\n    pub const fn is_per_cpu_worker(&self) -> bool {\n        self.per_cpu_worker\n    }\n";
    let mutated = source.replacen("impl CpuPin {\n", accessor, 1);
    assert_ne!(mutated, source, "fixture mutation must apply");
    validate_cpu_pin_records_its_reason(&mutated)
        .expect("a method that builds no pin is not a constructor");
}

/// Every loopback enqueue must schedule its own delivery.
///
/// Census-shaped on purpose: the check counts the functions in `kernel/src/net/mod.rs`
/// that push onto `LOOPBACK_QUEUE` and requires every one of them to raise the
/// softirq that owns delivery. A new enqueue site added later without a kick
/// changes the census and reddens this, which a named list of today's one site
/// would not.
fn validate_loopback_enqueue_owns_its_delivery(source: &str) -> Result<(), String> {
    let mut pushers = Vec::new();
    let mut kickers = 0usize;
    for span in function_spans(source) {
        let body = normalized_code(&source[span.open..=span.close]);
        // Skip enclosing scopes that merely contain a pushing function.
        if !body.contains("queue.push(LoopbackPacket") {
            continue;
        }
        let inner = function_spans(&source[span.open..=span.close])
            .into_iter()
            .any(|nested| {
                normalized_code(&source[span.open..=span.close][nested.open..=nested.close])
                    .contains("queue.push(LoopbackPacket")
            });
        if inner {
            continue;
        }
        pushers.push(span.name.clone());
        if body.contains("kick_loopback_delivery()") {
            kickers += 1;
        }
    }

    if pushers.is_empty() {
        return Err("no loopback enqueue site found in kernel/src/net/mod.rs".to_string());
    }
    if kickers != pushers.len() {
        return Err(format!(
            "{} of {} loopback enqueue sites raise the delivery softirq: {:?}",
            kickers,
            pushers.len(),
            pushers
        ));
    }

    let kick = function_body(source, "kick_loopback_delivery")
        .ok_or_else(|| "kick_loopback_delivery is not defined".to_string())?;
    if !normalized_code(kick).contains("raise_softirq(SoftirqType::NetRx)") {
        return Err("kick_loopback_delivery does not raise the NetRx softirq".to_string());
    }

    let handler = function_body(source, "net_rx_softirq_handler")
        .ok_or_else(|| "net_rx_softirq_handler is not defined".to_string())?;
    if !normalized_code(handler)
        .contains("drain_loopback_rounds(MAX_DRAIN_ROUNDS, LoopbackDrainSource::Softirq)")
    {
        return Err("the NetRx softirq does not drain the loopback queue".to_string());
    }

    Ok(())
}

/// No exit from the loopback drain may leave queued work without an owner.
///
/// Census-shaped: it counts the `return` statements in `drain_loopback_rounds`
/// and requires each one to be preceded, within its own statement group, by the
/// deferred-TX flush; and it requires every early return that can leave packets
/// queued to hand them back to the softirq. Adding a new early return reddens
/// this until that return is given the same discharge.
fn validate_loopback_drain_exits_own_their_leftovers(source: &str) -> Result<(), String> {
    let body = function_body(source, "drain_loopback_rounds")
        .ok_or_else(|| "drain_loopback_rounds is not defined".to_string())?;
    let code = normalized_code(body);

    let returns = code.matches("return ").count();
    let flushes = code.matches("tcp::drain_deferred_tx();").count();
    if returns == 0 {
        return Err("drain_loopback_rounds has no return statements to audit".to_string());
    }
    if flushes < returns {
        return Err(format!(
            "drain_loopback_rounds has {returns} returns but only {flushes} deferred-TX flushes"
        ));
    }
    if !code.contains("LoopbackTake::Empty => { tcp::drain_deferred_tx(); return false; }") {
        return Err("the empty-queue exit does not flush deferred TX".to_string());
    }
    if !code.contains(
        "LoopbackTake::Contended => { tcp::drain_deferred_tx(); return rearm_if_work_remains(); }",
    ) {
        return Err("the contended exit does not re-arm delivery".to_string());
    }
    if !code.ends_with("rearm_if_work_remains() }") {
        return Err("the exhausted-budget exit does not re-arm delivery".to_string());
    }

    let rearm = function_body(source, "rearm_if_work_remains")
        .ok_or_else(|| "rearm_if_work_remains is not defined".to_string())?;
    let rearm_code = normalized_code(rearm);
    if !rearm_code.contains("kick_loopback_delivery()") {
        return Err("rearm_if_work_remains does not kick delivery".to_string());
    }

    Ok(())
}

#[test]
fn loopback_enqueue_owns_its_delivery() {
    validate_loopback_enqueue_owns_its_delivery(&repo_text("kernel/src/net/mod.rs"))
        .expect("every loopback enqueue raises the softirq that delivers it");
}

#[test]
fn loopback_enqueue_validator_rejects_a_missing_kick() {
    let source = repo_text("kernel/src/net/mod.rs");
    let call =
        "kick_loopback_delivery();\n        crate::net::loopback_pump::wake_loopback_pump();";
    assert!(source.contains(call), "fixture mutation target must exist");
    let mutated = source.replacen(call, "crate::net::loopback_pump::wake_loopback_pump();", 1);
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_loopback_enqueue_owns_its_delivery(&mutated).is_err());
}

#[test]
fn loopback_enqueue_validator_rejects_a_softirq_that_does_not_drain() {
    let source = repo_text("kernel/src/net/mod.rs");
    let handler =
        function_body(&source, "net_rx_softirq_handler").expect("find the NetRx handler fixture");
    let drain = "let _ = drain_loopback_rounds(MAX_DRAIN_ROUNDS, LoopbackDrainSource::Softirq);";
    assert!(
        handler.contains(drain),
        "fixture mutation target must exist"
    );
    let mutated_handler = handler.replacen(drain, "", 1);
    let mutated = source.replacen(handler, &mutated_handler, 1);
    assert!(validate_loopback_enqueue_owns_its_delivery(&mutated).is_err());
}

#[test]
fn loopback_drain_exits_own_their_leftovers() {
    validate_loopback_drain_exits_own_their_leftovers(&repo_text("kernel/src/net/mod.rs"))
        .expect("every loopback drain exit flushes deferred TX and re-arms remaining work");
}

#[test]
fn loopback_drain_validator_rejects_an_unflushed_empty_exit() {
    let source = repo_text("kernel/src/net/mod.rs");
    let body = function_body(&source, "drain_loopback_rounds").expect("find the drain fixture");
    let arm = "LoopbackTake::Empty => {\n                tcp::drain_deferred_tx();\n                return false;\n            }";
    assert!(body.contains(arm), "fixture mutation target must exist");
    let mutated_body = body.replacen(arm, "LoopbackTake::Empty => return false,", 1);
    let mutated = source.replacen(body, &mutated_body, 1);
    assert!(validate_loopback_drain_exits_own_their_leftovers(&mutated).is_err());
}

#[test]
fn loopback_drain_validator_rejects_a_dropped_rearm() {
    let source = repo_text("kernel/src/net/mod.rs");
    let rearm = function_body(&source, "rearm_if_work_remains").expect("find the re-arm fixture");
    let mutated_rearm = rearm.replacen("kick_loopback_delivery();", "", 1);
    assert_ne!(mutated_rearm, rearm, "fixture mutation must apply");
    let mutated = source.replacen(rearm, &mutated_rearm, 1);
    assert!(validate_loopback_drain_exits_own_their_leftovers(&mutated).is_err());
}

/// The masked source with whitespace removed, plus the original byte offset of
/// each kept byte, so a match in the compacted text can be reported as a line.
fn masked_compact_with_offsets(text: &str) -> (String, Vec<usize>) {
    let mask = code_mask(text);
    let mut compact = String::new();
    let mut offsets = Vec::new();
    for (index, byte) in text.bytes().enumerate() {
        if !mask[index] || (byte as char).is_whitespace() {
            continue;
        }
        compact.push(byte as char);
        offsets.push(index);
    }
    (compact, offsets)
}

fn line_at_offset(text: &str, offset: usize) -> usize {
    text[..offset].matches('\n').count() + 1
}

/// The balanced parenthesised group opening at `open`, in compacted code.
fn balanced_group(compact: &str, open: usize) -> Option<&str> {
    let bytes = compact.as_bytes();
    if bytes.get(open) != Some(&b'(') {
        return None;
    }
    let mut depth = 0usize;
    for index in open..bytes.len() {
        if bytes[index] == b'(' {
            depth += 1;
        } else if bytes[index] == b')' {
            depth -= 1;
            if depth == 0 {
                return Some(&compact[open + 1..index]);
            }
        }
    }
    None
}

fn is_screaming_snake(name: &str) -> bool {
    !name.is_empty()
        && name.chars().all(|character| {
            character.is_ascii_uppercase() || character.is_ascii_digit() || character == '_'
        })
}

/// The counters the pinned-placement census emits, discovered from that
/// function's own format arguments rather than read off a literal name list --
/// the #549 and #551 rule, so a counter added to the census later is policed on
/// the day it appears rather than on the day someone widens a list.
fn pinned_census_counters(scheduler: &str) -> Result<Vec<String>, String> {
    let body = function_body(scheduler, "emit_pinned_placement_census")
        .ok_or("kernel/src/task/scheduler.rs defines no emit_pinned_placement_census")?;
    let compact = compact_code(body);
    let mut counters: Vec<String> = Vec::new();
    let mut searched = 0usize;
    while let Some(relative) = compact[searched..].find(".load(") {
        let offset = searched + relative;
        searched = offset + ".load(".len();
        let head = &compact[..offset];
        let start = head
            .rfind(|character: char| !(character.is_ascii_alphanumeric() || character == '_'))
            .map(|index| index + 1)
            .unwrap_or(0);
        let name = &head[start..];
        if is_screaming_snake(name) && !counters.contains(&name.to_string()) {
            counters.push(name.to_string());
        }
    }
    if counters.len() < 2 {
        return Err(format!(
            "the census discovery found {} counters in emit_pinned_placement_census, so the \
             two rules below would police almost nothing -- the discovery broke, not the kernel",
            counters.len()
        ));
    }
    Ok(counters)
}

fn scheduler_source(sources: &[(String, String)]) -> Result<&str, String> {
    sources
        .iter()
        .find(|(path, _)| path == "kernel/src/task/scheduler.rs")
        .map(|(_, text)| text.as_str())
        .ok_or_else(|| "kernel/src/task/scheduler.rs is not among the kernel sources".to_string())
}

/// No counter the pinned-placement census emits has a decrementing writer.
///
/// The census is what the two aarch64 boot gates score, and it reports boot
/// health: a writer that can take a counter back down can erase a real event
/// the gates were meant to fail on. The pin-guard oracle used to do exactly
/// that -- it subtracted the refusals its own probe manufactured, so a real
/// refusal landing in the same window was subtracted with them.
///
/// Two decrement shapes are policed, not one: the atomic methods that lower a
/// counter, and a `store` of an expression that subtracts. Matching the literal
/// `fetch_sub` alone would be satisfied by writing the same defect longhand.
fn validate_census_counters_have_no_decrementing_writer(
    sources: &[(String, String)],
) -> Result<(), String> {
    let counters = pinned_census_counters(scheduler_source(sources)?)?;
    let lowering = [
        "fetch_sub",
        "fetch_min",
        "fetch_and",
        "fetch_nand",
        "fetch_xor",
    ];
    let mut offenders = Vec::new();
    for (path, text) in sources {
        let (compact, offsets) = masked_compact_with_offsets(text);
        for counter in &counters {
            for method in lowering {
                let needle = format!("{counter}.{method}(");
                let mut searched = 0usize;
                while let Some(relative) = compact[searched..].find(&needle) {
                    let offset = searched + relative;
                    searched = offset + needle.len();
                    let line = line_at_offset(text, offsets[offset]);
                    offenders.push(format!("{path}:{line} ({counter}.{method}())"));
                }
            }
            let store = format!("{counter}.store(");
            let mut searched = 0usize;
            while let Some(relative) = compact[searched..].find(&store) {
                let offset = searched + relative;
                searched = offset + store.len();
                let Some(argument) = balanced_group(&compact, offset + store.len() - 1) else {
                    continue;
                };
                if argument.contains('-') || argument.contains("sub") {
                    let line = line_at_offset(text, offsets[offset]);
                    offenders.push(format!("{path}:{line} ({counter}.store of a subtraction)"));
                }
            }
        }
    }
    if !offenders.is_empty() {
        return Err(format!(
            "a pinned-placement census counter is written downward at {offenders:?}; the census \
             reports boot health to the 2 aarch64 gates, so a counter that can be taken back \
             down can lose a real event the gates exist to fail on"
        ));
    }
    Ok(())
}

/// Each census counter appears in both of the pin-guard oracle's snapshots.
///
/// `census_clean` is the oracle's own report that its probe moved 0 census
/// fields. It compares a before tuple with an after tuple, so a field missing
/// from the tuples is a field `census_clean` cannot see move -- and the field
/// the tuples used to omit was the one the oracle was subtracting.
fn validate_oracle_snapshots_cover_the_census(scheduler: &str) -> Result<(), String> {
    let counters = pinned_census_counters(scheduler)?;
    let body = function_body(scheduler, "run_pin_guard_oracle")
        .ok_or("kernel/src/task/scheduler.rs defines no run_pin_guard_oracle")?;
    let compact = compact_code(body);
    for binding in ["census_before", "census_after"] {
        let anchor = format!("let{binding}=(");
        let offset = compact
            .find(&anchor)
            .ok_or_else(|| format!("run_pin_guard_oracle takes no {binding} snapshot"))?;
        let group = balanced_group(&compact, offset + anchor.len() - 1)
            .ok_or_else(|| format!("the {binding} snapshot is not a closed tuple"))?;
        for counter in &counters {
            if !group.contains(&format!("{counter}.load(")) {
                return Err(format!(
                    "{counter} is emitted by the pinned-placement census but absent from the \
                     oracle's {binding} snapshot, so census_clean reports on fewer fields than \
                     the gates score"
                ));
            }
        }
    }
    Ok(())
}

/// `emit_pin_guard_oracle` has exactly 1 call site per architecture.
///
/// Its `refused=` field reads a cumulative counter rather than a delta taken
/// around the probe, which is only the probe's own count while the probe runs
/// once. A second caller -- in either architecture entry point, or anywhere
/// else -- would run the probe again and print the sum of both runs, and the
/// oracle's `refused=3` would silently become `refused=6`.
fn validate_pin_guard_oracle_call_sites(sources: &[(String, String)]) -> Result<(), String> {
    const ENTRY_POINTS: [&str; 2] = ["kernel/src/main.rs", "kernel/src/main_aarch64.rs"];
    let mut sites: Vec<(String, usize)> = Vec::new();
    for (path, text) in sources {
        let mask = code_mask(text);
        for offset in identifier_offsets(text, &mask, "emit_pin_guard_oracle") {
            // The 2 definitions are the 2 `fn emit_pin_guard_oracle` headers,
            // one per architecture; the remaining appearances are calls.
            if text[..offset].trim_end().ends_with("fn") {
                continue;
            }
            sites.push((path.clone(), line_at_offset(text, offset)));
        }
    }
    for (path, line) in &sites {
        if !ENTRY_POINTS.contains(&path.as_str()) {
            return Err(format!(
                "emit_pin_guard_oracle is called at {path}:{line}, outside the 2 architecture \
                 entry points; its refused= field is a cumulative total, so a second caller \
                 prints the sum of two probe runs"
            ));
        }
    }
    for entry in ENTRY_POINTS {
        let count = sites.iter().filter(|(path, _)| path == entry).count();
        if count != 1 {
            return Err(format!(
                "{entry} holds {count} call sites of emit_pin_guard_oracle, not 1; its refused= \
                 field is a cumulative total and is the probe's own count only while the probe \
                 runs once per boot"
            ));
        }
    }
    Ok(())
}

#[test]
fn census_counters_have_no_decrementing_writer() {
    validate_census_counters_have_no_decrementing_writer(&kernel_sources())
        .expect("no pinned-placement census counter is written downward");
}

#[test]
fn census_decrement_validator_rejects_a_reintroduced_fetch_sub() {
    let mut sources = kernel_sources();
    let counter =
        pinned_census_counters(scheduler_source(&sources).expect("find the scheduler source"))
            .expect("discover the census counters")
            .remove(0);
    let scheduler = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/task/scheduler.rs")
        .expect("find the scheduler source fixture");
    scheduler.1.push_str(&format!(
        "
fn spare_refusal_correction(refused: u64) {{
    {counter}.fetch_sub(refused, Ordering::Relaxed);
}}
"
    ));
    assert!(validate_census_counters_have_no_decrementing_writer(&sources).is_err());
}

#[test]
fn census_decrement_validator_rejects_a_load_subtract_store() {
    let mut sources = kernel_sources();
    let counter =
        pinned_census_counters(scheduler_source(&sources).expect("find the scheduler source"))
            .expect("discover the census counters")
            .remove(0);
    let scheduler = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/task/scheduler.rs")
        .expect("find the scheduler source fixture");
    scheduler.1.push_str(&format!(
        "
fn spare_refusal_correction_longhand(refused: u64) {{
    let previous = {counter}.load(Ordering::Relaxed);
    {counter}.store(previous - refused, Ordering::Relaxed);
}}
"
    ));
    assert!(validate_census_counters_have_no_decrementing_writer(&sources).is_err());
}

#[test]
fn census_rules_track_a_consistent_rename_of_every_counter() {
    let counters = pinned_census_counters(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("discover the census counters");
    let mut sources = kernel_sources();
    for (_, text) in sources.iter_mut() {
        for counter in &counters {
            *text = text.replace(counter.as_str(), &format!("RENAMED_{counter}"));
        }
    }
    validate_census_counters_have_no_decrementing_writer(&sources)
        .expect("the decrement rule follows the census by shape, not by the names of the day");
    let renamed = scheduler_source(&sources)
        .expect("find the renamed scheduler source")
        .to_string();
    validate_oracle_snapshots_cover_the_census(&renamed)
        .expect("the snapshot rule follows the census by shape, not by the names of the day");
}

#[test]
fn oracle_snapshots_cover_the_census() {
    validate_oracle_snapshots_cover_the_census(&repo_text("kernel/src/task/scheduler.rs"))
        .expect("both oracle snapshots load every counter the census emits");
}

#[test]
fn oracle_snapshot_validator_rejects_a_counter_dropped_from_census_before() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let anchor = "let census_before = (";
    let start = source
        .find(anchor)
        .expect("find the census_before snapshot");
    let end = start
        + source[start..]
            .find(");")
            .expect("find the end of the census_before snapshot");
    let dropped = source[start..end]
        .lines()
        .find(|line| line.contains(".load(Ordering::Relaxed)"))
        .expect("the census_before snapshot loads at least one counter")
        .to_string();
    let mutated = format!(
        "{}{}{}",
        &source[..start],
        source[start..end].replacen(dropped.as_str(), "", 1),
        &source[end..]
    );
    assert_ne!(mutated, source, "fixture mutation must apply");
    assert!(validate_oracle_snapshots_cover_the_census(&mutated).is_err());
}

#[test]
fn pin_guard_oracle_has_one_call_site_per_architecture() {
    validate_pin_guard_oracle_call_sites(&kernel_sources())
        .expect("emit_pin_guard_oracle has one call site per architecture");
}

#[test]
fn pin_guard_oracle_call_site_validator_rejects_a_second_entry_point_caller() {
    let mut sources = kernel_sources();
    let main_aarch64 = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/main_aarch64.rs")
        .expect("find the aarch64 entry point fixture");
    main_aarch64.1.push_str(
        "
fn spare_oracle_rerun() {
    kernel::task::scheduler::emit_pin_guard_oracle();
}
",
    );
    assert!(validate_pin_guard_oracle_call_sites(&sources).is_err());
}

#[test]
fn pin_guard_oracle_call_site_validator_rejects_a_caller_outside_the_entry_points() {
    let mut sources = kernel_sources();
    let kthread = sources
        .iter_mut()
        .find(|(path, _)| path == "kernel/src/task/kthread.rs")
        .expect("find the kthread source fixture");
    kthread.1.push_str(
        "
fn spare_oracle_caller() {
    crate::task::scheduler::emit_pin_guard_oracle();
}
",
    );
    assert!(validate_pin_guard_oracle_call_sites(&sources).is_err());
}

#[test]
fn code_mask_raw_string_close_preserves_next_byte() {
    // Check scanner correctness with a consistent live-code token.
    // Hash counts 0, 1, 2, and 3 are exercised directly here, not just 0 and 1.
    for fixture in [
        r##"r"x"serial_println!"##,
        r##"r#"x"#serial_println!"##,
        r####"r##"x"##serial_println!"####,
        r#####"r###"x"###serial_println!"#####,
    ] {
        let mask = code_mask(fixture);
        let offset = fixture.find("serial_println!").unwrap();
        assert!(mask[offset], "raw-string close swallowed the next byte");
    }
    // A skipped ordinary identifier byte stays true in the default mask.
    // A skipped raw opener instead changes lexical state: the embedded quote
    // closes an ordinary string, hiding the real token after the raw close.
    // Exercised at a 0-then-1 hash boundary and again at a 1-then-2 hash
    // boundary, so the compound-skip fix is checked past the smallest counts too.
    for fixture in [
        r###"r"x"r#"a"b"#serial_println!"###,
        r######"r#"x"#r##"a"b"##serial_println!"######,
    ] {
        let mask = code_mask(fixture);
        let offset = fixture.find("serial_println!").unwrap();
        assert!(mask[offset], "raw-string close swallowed the next byte");
    }
}

// PR 2: discover rescue candidates from peer-queue pops, anchored to the
// migration census' function spans and comment/string mask. Names and counts
// of retention call sites are deliberately not an input to this rule.
#[derive(Debug)]
struct RescueRetentionSite {
    function: String,
    ordinal: usize,
    queue: String,
    tid: String,
    between: String,
}

fn rescue_retention_sites(source: &str) -> Vec<RescueRetentionSite> {
    let mut sites = Vec::new();
    for span in function_spans(source) {
        let body = compact_code(&source[span.open..=span.close]);
        for (ordinal, (offset, _)) in body.match_indices(".pop_front()").enumerate() {
            let before = &body[..offset];
            let Some(queue_start) = before.rfind("self.per_cpu_queues[") else {
                continue;
            };
            let queue = &before[queue_start + "self.per_cpu_queues[".len()..];
            let Some(queue) = queue.strip_suffix(']') else {
                continue;
            };
            if queue == "current_cpu" {
                continue;
            }
            let Some(binding) = before[..queue_start].rfind("letSome(") else {
                continue;
            };
            let binding = &before[binding + "letSome(".len()..queue_start];
            let Some((tid, _)) = binding.split_once(")=") else {
                continue;
            };
            let after = &body[offset + ".pop_front()".len()..];
            // Bound the candidate's window by the next pop: a later rescue
            // cannot discharge an earlier candidate's obligation.
            let window = after.split(".pop_front()").next().unwrap();
            let guard = format!("self.retain_cpu_affine_thread({tid},current_cpu)");
            if let Some(guard_at) = window.find(&guard) {
                sites.push(RescueRetentionSite {
                    function: span.name.clone(),
                    ordinal,
                    queue: queue.into(),
                    tid: tid.into(),
                    between: window[..guard_at].into(),
                });
            }
        }
    }
    sites
}

fn retention_helper_name(source: &str) -> Result<String, String> {
    let helpers: Vec<_> = function_spans(source)
        .into_iter()
        .filter(|span| {
            let body = compact_code(&source[span.open..=span.close]);
            body.contains("self.per_cpu_queues[source_cpu].push_back(thread_id)")
                && body.contains("CPU_PINS_STAMPED.load")
        })
        .collect();
    if helpers.len() != 1 {
        return Err(format!(
            "expected one source-queue retention helper, found {}",
            helpers.len()
        ));
    }
    Ok(helpers[0].name.clone())
}

// Keep aarch64 string tokens visible for cfg checks, while comments and other
// strings remain masked. A comment containing the literal cannot supply it.
fn compact_code_with_aarch64_literal(source: &str) -> String {
    let mask = code_mask(source);
    let mut normalized: Vec<u8> = source
        .bytes()
        .zip(&mask)
        .map(|(byte, live)| if *live { byte } else { b' ' })
        .collect();
    let mut at = 0;
    while at < mask.len() {
        if mask[at] {
            at += 1;
            continue;
        }
        let start = at;
        while at < mask.len() && !mask[at] {
            at += 1;
        }
        if &source[start..at] == "\"aarch64\"" {
            normalized[start..at].copy_from_slice(b"\"aarch64\"");
        }
    }
    compact_whitespace(&String::from_utf8(normalized).expect("masked Rust source"))
}

#[test]
fn aarch64_literal_mask_rejects_comment_and_string_decoys() {
    for source in [
        r#"#[cfg(target_arch = /* "aarch64" */ "x86_64")]"#,
        r#"// #[cfg(target_arch = "aarch64")]
#[cfg(target_arch = "x86_64")]"#,
        r##"r#"#[cfg(target_arch = "aarch64")]"#"##,
    ] {
        assert!(!compact_code_with_aarch64_literal(source).contains("aarch64"));
    }
    assert_eq!(
        compact_code_with_aarch64_literal(r#"#[cfg(target_arch = "aarch64")]"#),
        r#"#[cfg(target_arch="aarch64")]"#
    );
}

fn validate_retention_helper_placement(source: &str) -> Result<(), String> {
    let name = retention_helper_name(source)?;
    let spans = function_spans(source);
    let test = spans
        .iter()
        .position(|span| span.name == "retain_cpu_affine_test_thread")
        .ok_or("missing test retention helper")?;
    if spans.get(test + 1).is_none_or(|span| span.name != name) {
        return Err(
            "source retention helper must immediately follow the test retention helper".into(),
        );
    }
    Ok(())
}

#[test]
fn rescue_retention_helpers_are_adjacent() {
    validate_retention_helper_placement(&repo_text("kernel/src/task/scheduler.rs")).unwrap();
}

#[test]
fn rescue_retention_placement_rejects_intervening_function() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let name = retention_helper_name(&source).unwrap();
    let at = source.find(&format!("    fn {name}(")).unwrap();
    let mutated = format!("{}fn unrelated() {{}}\n{}", &source[..at], &source[at..]);
    assert!(validate_retention_helper_placement(&mutated).is_err());
}

#[test]
fn rescue_retention_rejects_wrong_kick_architecture() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let body = function_body(&source, "retain_cpu_affine_thread").unwrap();
    let kick =
        "#[cfg(target_arch = \"aarch64\")]\n            self.send_resched_ipi_to_cpu(pin.cpu);";
    let sites: Vec<_> = body.match_indices(kick).collect();
    assert_eq!(sites.len(), 3, "exercise every kick disposition");
    for (offset, _) in sites {
        for arch in ["x86_64", "riscv64"] {
            let mut changed = body.to_string();
            changed.replace_range(offset..offset + kick.len(), &kick.replace("aarch64", arch));
            let mutated = source.replacen(body, &changed, 1);
            assert!(
                validate_rescue_retention(&mutated).is_err(),
                "kick at {offset} accepted {arch}"
            );
        }
    }
}

fn validate_rescue_retention(source: &str) -> Result<(), String> {
    let sites = rescue_retention_sites(source);
    if sites.is_empty() {
        return Err("rescue pop/guard census is empty".into());
    }
    let name = retention_helper_name(source);
    let mut errors = Vec::new();
    for site in &sites {
        let call = name
            .as_ref()
            .map(|name| format!("ifself.{name}({},{}){{continue;}}", site.queue, site.tid));
        if !call.as_ref().is_ok_and(|call| site.between.contains(call)) {
            errors.push(format!("kernel/src/task/scheduler.rs:{} pop {} queue {} tid {}: missing source retention before guard", site.function, site.ordinal, site.queue, site.tid));
        }
    }
    if !errors.is_empty() {
        return Err(errors.join("\n"));
    }
    let name = name?;
    let body = compact_code(function_body(source, &name).unwrap());
    let arms = [
        "ifsuper::thread::CPU_PINS_STAMPED.load(Ordering::Relaxed)==0{returnfalse;}",
        "ifsource_cpu>=self.online_cpu_count(){returnfalse;}",
        "letSome(thread)=self.get_thread(thread_id)else{returnfalse;};",
        "ifthread.state==ThreadState::Terminated{returnfalse;}",
        "letSome(pin)=thread.cpu_affinityelse{returnfalse;};",
        "if!pin.per_cpu_worker||pin.cpu!=source_cpu{returnfalse;}",
        "ifletSome(slot)=crate::arch_impl::aarch64::constants::percpu_stack_slot_of(thread.context.sp){ifslot!=pin.cpu{returnfalse;}}",
        "self.per_cpu_queues[source_cpu].push_back(thread_id);true",
    ];
    let mut cursor = 0;
    for arm in arms {
        let Some(at) = body[cursor..].find(arm) else {
            return Err(format!(
                "kernel/src/task/scheduler.rs:{name}: missing/changed retention arm {arm}"
            ));
        };
        cursor += at + arm.len();
    }
    if body.contains("fetch_add") || body.contains("send_resched") {
        return Err("retention must neither count nor kick".into());
    }
    let guard = compact_code_with_aarch64_literal(
        function_body(source, "retain_cpu_affine_thread").ok_or("missing guard")?,
    );
    for disposition in [
        "self.per_cpu_queues[pin.cpu].push_back(thread_id);#[cfg(target_arch=\"aarch64\")]self.send_resched_ipi_to_cpu(pin.cpu);returntrue;",
        "self.hold_pinned_wake_for_home(thread_id);#[cfg(target_arch=\"aarch64\")]self.send_resched_ipi_to_cpu(pin.cpu);",
        "else{self.per_cpu_queues[pin.cpu].push_back(thread_id);#[cfg(target_arch=\"aarch64\")]self.send_resched_ipi_to_cpu(pin.cpu);}",
    ] {
        if !guard.contains(disposition) { return Err(format!("guard disposition missing aarch64 targeted kick: {disposition}")); }
    }
    validate_percpu_stack_reroute_counts_a_pin_conflict(source)
}

#[test]
fn rescue_retention_census() {
    let source = repo_text("kernel/src/task/scheduler.rs");
    validate_rescue_retention(&source).unwrap_or_else(|error| panic!("{error}"));
}

/// Execute the source's reclaim/retention/guard bodies on isolated host state.
/// This extends the pin-guard probe's queue staging with a fourth rescue leg;
/// the offline case deliberately counts a discard, so it runs in a fresh
/// process rather than contaminating a live boot's placement census. Hardware
/// dispatch, SGI delivery and stack address decoding are outside this harness.
fn forced_retention_probe(offline: bool) {
    let source = repo_text("kernel/src/task/scheduler.rs");
    let helper = retention_helper_name(&source).expect("retention helper");
    let mut harness = String::from(
        r#"
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::collections::VecDeque;
const MAX_CPUS: usize = 4;
const CPU_STALL_TICKS: u64 = 20;
const PIN_GUARD_ORACLE_HELD: usize = 255;
static PINNED_HOME_CPU_UNAVAILABLE: AtomicU64 = AtomicU64::new(0);
static PINNED_HOME_CPU_UNAVAILABLE_MARKED: AtomicBool = AtomicBool::new(false);
static PINNED_PUBLISH_DISCARDED: AtomicU64 = AtomicU64::new(0);
static PINNED_HOLD_PEN_MIGRATED: AtomicU64 = AtomicU64::new(0);
static PINNED_MIGRATION_REFUSED: AtomicU64 = AtomicU64::new(0);
static PINNED_STACK_HOME_CONFLICT: AtomicU64 = AtomicU64::new(0);
static PIN_GUARD_ORACLE_PROBE_TID: AtomicU64 = AtomicU64::new(7);
static PIN_GUARD_ORACLE_REFUSED: AtomicU64 = AtomicU64::new(0);
static ENQUEUE_OFFLINE_RECLAIMED: AtomicU64 = AtomicU64::new(0);
static ENQUEUE_STALLED_RECLAIMED: AtomicU64 = AtomicU64::new(0);
mod thread { pub static CPU_PINS_STAMPED: std::sync::atomic::AtomicU64 = std::sync::atomic::AtomicU64::new(1); }
mod time { pub fn get_ticks() -> u64 { 100 } }
mod arch_impl { pub mod aarch64 { pub mod constants { pub fn percpu_stack_slot_of(sp: u64) -> Option<usize> { assert_eq!(sp, 0); None } } } }
mod tracing { pub mod output { pub fn raw_serial_str(s: &str) { print!("{s}"); } pub fn raw_serial_dec(n: u64) { print!("{n}"); } } }
fn arch_can_dispatch_here() -> bool { true }
#[derive(Clone, Copy, PartialEq)] enum ThreadState { Ready, Terminated }
#[derive(Clone, Copy)] struct CpuPin { cpu: usize, per_cpu_worker: bool }
struct Context { sp: u64 }
struct Thread { state: ThreadState, cpu_affinity: Option<CpuPin>, context: Context }
struct CpuState { last_schedule_ticks: u64, current_thread: Option<u64>, previous_thread: Option<u64>, pending_next: Option<u64> }
mod scheduler {
use super::*;
struct Scheduler { per_cpu_queues: [VecDeque<u64>; MAX_CPUS], cpu_state: [CpuState; MAX_CPUS], thread: Thread }
impl Scheduler {
fn current_cpu_id() -> usize { 0 }
fn online_cpu_count(&self) -> usize { 2 }
fn get_thread(&self, tid: u64) -> Option<&Thread> { (tid == 7).then_some(&self.thread) }
fn get_thread_mut(&mut self, tid: u64) -> Option<&mut Thread> { (tid == 7).then_some(&mut self.thread) }
fn is_in_deferred_requeue(&self, tid: u64) -> bool { assert_eq!(tid, 7); false }
fn send_resched_ipi_to_cpu(&self, cpu: usize) { assert!(cpu < MAX_CPUS); }
"#,
    );
    for (name, signature) in [
        (
            helper.as_str(),
            format!("fn {helper}(&mut self, source_cpu: usize, thread_id: u64) -> bool"),
        ),
        (
            "reclaim_unschedulable_cpu_queues",
            "fn reclaim_unschedulable_cpu_queues(&mut self)".into(),
        ),
        (
            "retain_cpu_affine_thread",
            "fn retain_cpu_affine_thread(&mut self, thread_id: u64, taking_cpu: usize) -> bool"
                .into(),
        ),
        (
            "cpu_accepts_wakeups",
            "fn cpu_accepts_wakeups(&self, cpu: usize) -> bool".into(),
        ),
        (
            "cpu_dispatch_stale",
            "fn cpu_dispatch_stale(&self, cpu: usize) -> bool".into(),
        ),
        (
            "pinned_wake_is_waiting_here",
            "fn pinned_wake_is_waiting_here(&self, tid: u64, cpu: usize) -> bool".into(),
        ),
        (
            "hold_pinned_wake_for_home",
            "fn hold_pinned_wake_for_home(&self, thread_id: u64)".into(),
        ),
        (
            "pin_guard_oracle_where",
            "fn pin_guard_oracle_where(&self, tid: u64) -> usize".into(),
        ),
    ] {
        let body = function_body(&source, name)
            .expect("production/probe method body")
            .replace(
                "#[cfg(all(target_arch = \"aarch64\", feature = \"boot_tests\"))]",
                "#[cfg(any())]",
            )
            .replace("#[cfg(target_arch = \"aarch64\")]", "#[cfg(all())]");
        harness.push_str(&format!("{signature} {body}\n"));
    }
    harness.push_str("}\nfn count_pinned_migration_refusal(thread_id: u64)");
    harness.push_str(function_body(&source, "count_pinned_migration_refusal").unwrap());
    harness.push_str(r#"
pub fn run(offline: bool) {
    let home = if offline { 2 } else { 1 };
    let mut s = Scheduler {
        per_cpu_queues: std::array::from_fn(|_| VecDeque::new()),
        cpu_state: std::array::from_fn(|_| CpuState { last_schedule_ticks: 0, current_thread: None, previous_thread: None, pending_next: None }),
        thread: Thread { state: ThreadState::Ready, cpu_affinity: Some(CpuPin { cpu: home, per_cpu_worker: true }), context: Context { sp: 0 } },
    };
    assert!(offline || s.cpu_dispatch_stale(home));
    s.per_cpu_queues[home].push_back(7);
    s.reclaim_unschedulable_cpu_queues();
    assert_eq!(s.pin_guard_oracle_where(7), if offline { 0 } else { home });
    assert_eq!(s.per_cpu_queues.iter().map(VecDeque::len).sum::<usize>(), 1);
    assert_eq!(PINNED_PUBLISH_DISCARDED.load(Ordering::Relaxed), u64::from(offline));
    assert_eq!(s.thread.cpu_affinity.is_none(), offline);
    assert_eq!(PINNED_HOME_CPU_UNAVAILABLE.load(Ordering::Relaxed), 0);
    assert!(!PINNED_HOME_CPU_UNAVAILABLE_MARKED.load(Ordering::Relaxed));
    assert_eq!(PINNED_MIGRATION_REFUSED.load(Ordering::Relaxed), 0);
    assert_eq!(PIN_GUARD_ORACLE_REFUSED.load(Ordering::Relaxed), 0);
    assert_eq!(PINNED_STACK_HOME_CONFLICT.load(Ordering::Relaxed), 0);
    println!("forced-{}-home: queue={} discard={} pin_cleared={} held=0 refused=0 first_marker=false PASS", if offline { "offline" } else { "stalled" }, s.pin_guard_oracle_where(7), PINNED_PUBLISH_DISCARDED.load(Ordering::Relaxed), s.thread.cpu_affinity.is_none());
}
}
"#);
    harness.push_str(&format!("fn main() {{ scheduler::run({offline}); }}\n"));
    let scratch =
        std::env::temp_dir().join(format!("retention-probe-{}-{offline}", std::process::id()));
    fs::create_dir_all(&scratch).unwrap();
    let input = scratch.join("probe.rs");
    let binary = scratch.join("probe");
    fs::write(&input, harness).unwrap();
    let build = std::process::Command::new("rustc")
        .args(["--edition=2021", "-Dwarnings"])
        .arg(&input)
        .arg("-o")
        .arg(&binary)
        .output()
        .unwrap();
    assert!(
        build.status.success(),
        "host probe compile: {}",
        String::from_utf8_lossy(&build.stderr)
    );
    let run = std::process::Command::new(&binary).output().unwrap();
    let stdout = String::from_utf8_lossy(&run.stdout);
    println!("{stdout}");
    assert!(
        run.status.success(),
        "probe failed: {}",
        String::from_utf8_lossy(&run.stderr)
    );
    assert!(!stdout.contains("[PINNED_HOME_CPU_UNAVAILABLE:first:"));
    fs::remove_dir_all(scratch).unwrap();
}

#[test]
fn forced_stalled_home_retention() {
    forced_retention_probe(false);
}

#[test]
fn forced_offline_home_declines_retention() {
    forced_retention_probe(true);
}

/// The wake-budget marker is printed on the passing path and on every
/// failing path, from one producer, over three bracketed clocks.
/// claim-lint:ok: "every failing path" is the 2 failing returns and 1
/// passing return this validator enumerates below, 3 of 3, and the mutation
/// test beneath reddens on deleting either print; see #586.
///
/// #586 PR 2. The budget window is bracketed by a tick clock
/// (`get_monotonic_time`, which advances only on delivered timer
/// interrupts), a counter clock (`monotonic_now_ns`, CNTVCT_EL0 on aarch64
/// and the TSC on x86_64, which advances with the host), and
/// `CTX_SWITCH_TOTAL`, the switches the guest performed. A marker printed
/// only on the failing path would have no green population to be read
/// against, and the two verdict constants were chosen from exactly that
/// population, so "printed on both paths" is the load-bearing property here
/// rather than a convenience.
///
/// This is a shape check: the field values, the wording of the
/// classification and the arithmetic of the verdict may all change. What it
/// pins is that the grammar carries its 13 fields, that each of the 3 clock
/// stamps straddles the sleep, and that no exit of the function returns
/// without a call to the single emitter.
/// claim-lint:ok: "may all change" scopes what this validator does NOT pin;
/// the 3 properties it does pin are enumerated in the same sentence, 3 of 3;
/// see #586.
fn validate_loopback_wake_budget_marker(source: &str) -> Result<(), String> {
    // The literal as a producer writes it: opening quote included, so the
    // prose above and in the kernel comments -- which spell the marker in
    // backticks -- is not counted as a second producer.
    const MARKER: &'static str = "\"[LOOPBACK_WAKE_BUDGET:";
    let producers = source.matches(MARKER).count();
    if producers != 1 {
        return Err(format!(
            "the wake-budget marker has {producers} producers; exactly 1 is the contract"
        ));
    }

    let body = function_body(source, "run_loopback_recv_wake_test_inner")
        .ok_or_else(|| "missing run_loopback_recv_wake_test_inner".to_string())?;

    let grammar_start = body.find(MARKER).ok_or_else(|| {
        "the wake-budget marker is not produced inside the loopback wake test".to_string()
    })?;
    let grammar_len = body[grammar_start..]
        .find(']')
        .ok_or_else(|| "the wake-budget marker literal is unterminated".to_string())?;
    let grammar = &body[grammar_start + 1..grammar_start + grammar_len];
    for field in [
        "arch=",
        "test=",
        "budget_ms=",
        "elapsed_tick_ms=",
        "elapsed_ctr_ms=",
        "ctx_delta=",
        "extensions=",
        "reader_state=",
        "queued_cpu=",
        "queued_idx=",
        "idle_cpus=",
        "cpu_silence_ms=",
        "silence_cpu=",
        "woke_ms=",
        "verdict=",
    ] {
        if !grammar.contains(field) {
            return Err(format!("the wake-budget marker omits the {field} field"));
        }
    }
    let sleep = code_text_offset(body, "sleep_current_thread_ms(LOOPBACK_WAKE_BUDGET_MS)")
        .ok_or_else(|| "the wake budget is not spent in one named sleep".to_string())?;
    for (before, after, clock) in [
        (
            "let tick_before_ms",
            "let tick_after_ms",
            "get_monotonic_time",
        ),
        ("let ctr_before_ns", "let ctr_after_ns", "monotonic_now_ns"),
        ("let ctx_before", "let ctx_after", "CTX_SWITCH_TOTAL"),
    ] {
        let before_at = code_text_offset(body, before)
            .ok_or_else(|| format!("the wake budget is not stamped by {before}"))?;
        let after_at = code_text_offset(body, after)
            .ok_or_else(|| format!("the wake budget is not stamped by {after}"))?;
        if before_at >= sleep || after_at <= sleep {
            return Err(format!(
                "{before} and {after} do not straddle the wake budget"
            ));
        }
        for (statement_at, label) in [(before_at, before), (after_at, after)] {
            let statement_len = body[statement_at..]
                .find(';')
                .ok_or_else(|| format!("{label} is unterminated"))?;
            let statement = &body[statement_at..statement_at + statement_len];
            if !has_identifier(statement, clock) {
                return Err(format!("{label} does not read {clock}"));
            }
        }
    }
    let verdict_at = code_text_offset(body, "let verdict =")
        .ok_or_else(|| "the wake budget reaches no verdict".to_string())?;
    let verdict_len = body[verdict_at..]
        .find("\n    };")
        .ok_or_else(|| "the verdict selector is unterminated".to_string())?;
    let verdict = &body[verdict_at..verdict_at + verdict_len];
    for token in ["ok", "wake", "starved", "dispatch"] {
        if !verdict.contains(&format!("\"{token}\"")) {
            return Err(format!("the wake-budget verdict cannot read {token}"));
        }
    }

    if !has_identifier(body, "thread_placement_facts") {
        return Err("the wake-budget marker reads no placement facts".to_string());
    }

    let emitter_at = code_text_offset(body, "let emit_wake_budget =")
        .ok_or_else(|| "the wake-budget marker has no single emitter".to_string())?;
    let tail = &body[emitter_at..];
    let mask = code_mask(tail);
    let mut exits: Vec<usize> = Vec::new();
    for pattern in ["TestResult::Fail", "TestResult::Pass"] {
        for (offset, _) in tail.match_indices(pattern) {
            if mask[offset] {
                exits.push(offset);
            }
        }
    }
    exits.sort_unstable();
    if exits.len() < 3 {
        return Err(format!(
            "the loopback wake test has {} exits after the emitter; 2 failing and 1 passing are the contract",
            exits.len()
        ));
    }
    let mut previous = 0usize;
    for exit in exits {
        if !tail[previous..exit].contains("emit_wake_budget()") {
            return Err(
                "an exit of the loopback wake test returns without printing the wake-budget marker"
                    .to_string(),
            );
        }
        previous = exit;
    }
    Ok(())
}

#[test]
fn loopback_wake_budget_marker_is_printed_on_both_paths() {
    validate_loopback_wake_budget_marker(&repo_text("kernel/src/test_framework/registry.rs"))
        .expect("the wake-budget marker is printed on the passing and the failing paths");
}

/// Every occurrence of the compacted-code text `scheduler` that is a
/// receiver access (followed by `.`) in `body`, with the receiver name and
/// dot stripped, in source order. `body` must already be `compact_code`'d --
/// this walks it as plain code text with no comments or strings left to
/// mask.
/// claim-lint:ok: exercised by both legs of
/// loopback_wake_budget_placement_accessor_ratchet_rejects_a_queue_mutation
/// below, 2 of 2; see #586.
fn compact_receiver_accesses<'a>(compact: &'a str, receiver: &str) -> Vec<&'a str> {
    let mask = vec![true; compact.len()];
    identifier_offsets(compact, &mask, receiver)
        .into_iter()
        .filter_map(|offset| {
            let end = offset + receiver.len();
            (compact.as_bytes().get(end) == Some(&b'.')).then(|| &compact[end + 1..])
        })
        .collect()
}

/// Whether one `scheduler.<rest>` access is the accessor's one approved
/// read-only shape: an index into `per_cpu_queues` immediately chained into
/// `.iter(`. A second field, a mutating method chained onto the same field,
/// and a bare assignment are the 3 shapes this refuses -- see the 2 legs of
/// loopback_wake_budget_placement_accessor_ratchet_rejects_a_queue_mutation
/// below.
/// claim-lint:ok: 2 of the 3 named shapes (mutating method, bare
/// assignment) are the mutation test's 2 legs; the third (a second field
/// read rather than mutated) is refused by the same `strip_prefix` check
/// but is not separately mutation-tested; see #586.
fn is_read_only_queue_scan(after_dot: &str) -> bool {
    let Some(rest) = after_dot.strip_prefix("per_cpu_queues[") else {
        return false;
    };
    let Some(close) = rest.find(']') else {
        return false;
    };
    rest[close + 1..].starts_with(".iter(")
}

/// The accessor the marker reads is read-only: this checks that every use
/// of its `&mut Scheduler` receiver takes the one approved read-only shape.
/// This is a positive census of what the receiver is allowed to be put to,
/// not a denylist of mutating method names -- a denylist of names is
/// exactly as wide as the names on it and no wider: `push_front`,
/// `pop_back`, `clear`, `retain`, `drain`, `truncate`, `swap_remove`,
/// `iter_mut`, and a bare field assignment are 9 names/shapes invisible to
/// a 6-name denylist, none of which can produce
/// `per_cpu_queues[<cpu>].iter(...)`.
/// claim-lint:ok: 2 of the 9 (`push_front`, a bare field assignment) are
/// mutation-tested below; the remaining 7 are read off the same
/// `strip_prefix`/`starts_with` shape as those 2 and not separately
/// mutation-tested; see #586.
fn thread_placement_accessor_is_read_only(scheduler_source: &str) -> Result<(), String> {
    let body = function_body(scheduler_source, "thread_placement_facts")
        .ok_or_else(|| "the placement accessor the wake-budget marker reads is gone".to_string())?;
    let compact = compact_code(body);
    let accesses = compact_receiver_accesses(&compact, "scheduler");
    if accesses.is_empty() {
        return Err(
            "the placement accessor's closure no longer touches its `&mut Scheduler` receiver \
             at all; this census needs updating to match its new shape"
                .to_string(),
        );
    }
    for access in accesses {
        if !is_read_only_queue_scan(access) {
            let preview: String = access.chars().take(48).collect();
            return Err(format!(
                "the placement accessor uses its `&mut Scheduler` receiver as \
                 `scheduler.{preview}...`, which is not the one read-only shape this census \
                 allows (`.per_cpu_queues[<cpu>].iter(...)`); it must only read"
            ));
        }
    }
    Ok(())
}

#[test]
fn loopback_wake_budget_placement_accessor_is_read_only() {
    let scheduler = repo_text("kernel/src/task/scheduler.rs");
    thread_placement_accessor_is_read_only(&scheduler)
        .expect("the placement accessor the wake-budget marker reads must only read");
}

/// V-2: a denylist of 6 mutating method names does not see a mutation that
/// uses a different name. This reproduces the exact demonstration -- pushing
/// onto and clearing a ready queue inside the accessor's closure -- and
/// proves the positive-shape census above catches what the denylist missed.
#[test]
fn loopback_wake_budget_placement_accessor_ratchet_rejects_a_queue_mutation() {
    let scheduler = repo_text("kernel/src/task/scheduler.rs");
    thread_placement_accessor_is_read_only(&scheduler)
        .expect("baseline source must pass, or the mutation below proves nothing");

    let mutated = scheduler.replacen(
        "    let queued = with_scheduler(|scheduler| {
        for cpu in 0..MAX_CPUS {",
        "    let queued = with_scheduler(|scheduler| {
        scheduler.per_cpu_queues[0].push_front(tid);
        scheduler.per_cpu_queues[0].clear();
        for cpu in 0..MAX_CPUS {",
        1,
    );
    assert_ne!(mutated, scheduler, "the queue-mutation leg must apply");
    assert!(
        thread_placement_accessor_is_read_only(&mutated).is_err(),
        "an accessor that pushes onto and clears a ready queue must redden this census"
    );

    let field_assignment = scheduler.replacen(
        "    let queued = with_scheduler(|scheduler| {
        for cpu in 0..MAX_CPUS {",
        "    let queued = with_scheduler(|scheduler| {
        scheduler.woken_threads_len = 0;
        for cpu in 0..MAX_CPUS {",
        1,
    );
    assert_ne!(
        field_assignment, scheduler,
        "the field-assignment leg must apply"
    );
    assert!(
        thread_placement_accessor_is_read_only(&field_assignment).is_err(),
        "an accessor that assigns a field on its receiver must redden this census"
    );
}

/// The mutation legs. Deleting the fail-path print, deleting the pass-path
/// print, dropping one grammar field, and unhooking one clock stamp each
/// redden the validator; without them the validator could be satisfied by a
/// marker nobody prints and a budget nobody measured.
#[test]
fn loopback_wake_budget_validator_rejects_a_deleted_print() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    validate_loopback_wake_budget_marker(&source)
        .expect("baseline source must pass, or the mutations below prove nothing");

    let no_fail_print = source.replacen(
        "        emit_wake_budget();\n        return TestResult::Fail(diagnostic_message);",
        "        return TestResult::Fail(diagnostic_message);",
        1,
    );
    assert_ne!(no_fail_print, source, "fail-path mutation must apply");
    assert!(
        validate_loopback_wake_budget_marker(&no_fail_print).is_err(),
        "a failing path that returns without the wake-budget marker must redden the validator"
    );

    let no_pass_print = source.replacen(
        "    emit_wake_budget();\n    TestResult::Pass",
        "    TestResult::Pass",
        1,
    );
    assert_ne!(no_pass_print, source, "pass-path mutation must apply");
    assert!(
        validate_loopback_wake_budget_marker(&no_pass_print).is_err(),
        "a passing path that returns without the wake-budget marker must redden the validator"
    );

    let no_ctx_field = source.replacen(":ctx_delta={}", ":ctx={}", 1);
    assert_ne!(no_ctx_field, source, "grammar mutation must apply");
    assert!(
        validate_loopback_wake_budget_marker(&no_ctx_field).is_err(),
        "a grammar that drops a field must redden the validator"
    );

    for field in ["cpu_silence_ms", "silence_cpu"] {
        let without_field = source.replacen(&format!(":{field}={{}}"), ":omitted={}", 1);
        assert_ne!(without_field, source, "census mutation must apply");
        assert!(validate_loopback_wake_budget_marker(&without_field).is_err());
    }

    let unbracketed = source.replacen(
        "    let tick_before_ms = crate::time::get_monotonic_time();",
        "    let tick_before_ms = 0u64;",
        1,
    );
    assert_ne!(unbracketed, source, "clock mutation must apply");
    assert!(
        validate_loopback_wake_budget_marker(&unbracketed).is_err(),
        "a tick stamp that reads no clock must redden the validator"
    );
}

/// V-5: the emitter must keep "the scheduler was unavailable" (the placement
/// accessor's outer `Option` reading empty) separate from "sampled and
/// empty" (its inner `Option` reading empty, or a real `idle_cpu_bitmap` of
/// 0) -- the distinction `thread_placement_facts`'s own doc comment in
/// kernel/src/task/scheduler.rs:5977-5979 says is preserved.
/// `Option::and_then` on `queued_cpu`/`queued_index` cannot see which layer
/// read empty, and an unguarded `Option::map_or(0u32, ...)` prints the same
/// `0x0` bytes whether a sample ran and found nothing idle or never ran at
/// all. This checks the emitter source for a distinct token and for a
/// separate availability flag reaching the idle_cpus print site, not for
/// the exact wording of either.
/// claim-lint:ok: kernel/src/task/scheduler.rs:5977-5979 is the doc comment
/// quoted; see #586.
fn validate_placement_slot_distinguishes_unavailable(source: &str) -> Result<(), String> {
    let body = function_body(source, "run_loopback_recv_wake_test_inner")
        .ok_or_else(|| "missing run_loopback_recv_wake_test_inner".to_string())?;
    if !body.contains("\"unavailable\"") {
        return Err(
            "the wake-budget emitter has no distinct token for a placement sample the \
             scheduler declined to take"
                .to_string(),
        );
    }
    for pattern in [
        "placement.and_then(|facts| facts.queued_cpu)",
        "placement.and_then(|facts| facts.queued_index)",
    ] {
        if body.contains(pattern) {
            return Err(format!(
                "the wake-budget emitter folds an unavailable placement sample into `none` \
                 through `{pattern}`"
            ));
        }
    }
    // `idle_cpus_sampled` existing SOMEWHERE in `body` is not enough -- the
    // binding two-hop `map_or` bug this replaces still left the flag
    // computed and unused if a later edit dropped only the print-site
    // reference. Bound the check to the emitter closure itself, where the
    // print call lives.
    let mask = code_mask(body);
    let emitter_at = code_text_offset(body, "let emit_wake_budget =")
        .ok_or_else(|| "the wake-budget marker has no single emitter".to_string())?;
    let (open, close) = braced_block_span(body, &mask, emitter_at)
        .ok_or_else(|| "the wake-budget emitter closure is unterminated".to_string())?;
    let emitter_block = &body[open..=close];
    if !has_identifier(emitter_block, "idle_cpus_sampled") {
        return Err(
            "the wake-budget emitter's print call reads no separate availability flag for \
             idle_cpus"
                .to_string(),
        );
    }
    Ok(())
}

#[test]
fn loopback_wake_budget_emitter_distinguishes_unavailable_from_not_queued() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    validate_placement_slot_distinguishes_unavailable(&source)
        .expect("the emitter must keep an unavailable placement sample distinct from an empty one");
}

/// The mutation legs: reintroduce each half of the collapse V-5 found --
/// the `and_then` fold on `queued_cpu`/`queued_idx`, and the un-flagged
/// `idle_cpus` print with no availability check reaching it -- and prove the
/// validator reddens on each independently.
#[test]
fn loopback_wake_budget_emitter_validator_rejects_the_unavailable_collapse() {
    let source = repo_text("kernel/src/test_framework/registry.rs");
    validate_placement_slot_distinguishes_unavailable(&source)
        .expect("baseline source must pass, or the mutations below prove nothing");

    let and_then_collapse = source.replacen(
        "PlacementSlot::of(placement, |facts| facts.queued_cpu),",
        "OptSlot(placement.and_then(|facts| facts.queued_cpu)),",
        1,
    );
    assert_ne!(
        and_then_collapse, source,
        "the queued_cpu and_then-collapse mutation must apply"
    );
    assert!(
        validate_placement_slot_distinguishes_unavailable(&and_then_collapse).is_err(),
        "reintroducing the and_then collapse on queued_cpu must redden the validator"
    );

    let idle_collapse = source.replacen(
        "IdleCpusSlot {\n                bits: idle_cpus,\n                sampled: idle_cpus_sampled,\n            },",
        "idle_cpus,",
        1,
    );
    assert_ne!(
        idle_collapse, source,
        "the idle_cpus availability-flag mutation must apply"
    );
    assert!(
        validate_placement_slot_distinguishes_unavailable(&idle_collapse).is_err(),
        "reintroducing an idle_cpus print with no availability flag must redden the validator"
    );
}
