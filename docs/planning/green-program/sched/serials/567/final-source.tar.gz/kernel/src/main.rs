//! Kernel entry point and initialization.
//!
//! This file contains the x86_64-specific kernel entry point.
//! For ARM64, this file is gated out and the entry point is in main_aarch64.rs.

// Gate the entire file to x86_64. On ARM64, only the minimal stub at the bottom compiles.
#![cfg_attr(not(target_arch = "x86_64"), allow(unused_imports))]
#![no_std] // don't link the Rust standard library
#![no_main] // disable all Rust-level entry points
#![cfg_attr(target_arch = "x86_64", feature(abi_x86_interrupt))]
#![cfg_attr(target_arch = "x86_64", feature(alloc_error_handler))]
#![cfg_attr(target_arch = "x86_64", feature(never_type))]

// =============================================================================
// ARM64 Stub: This binary is x86_64-only. ARM64 uses kernel-aarch64 binary.
// Provide minimal lang items so this file compiles but does nothing.
// =============================================================================
#[cfg(not(target_arch = "x86_64"))]
mod aarch64_stub {
    use core::panic::PanicInfo;

    #[panic_handler]
    fn panic(_info: &PanicInfo) -> ! {
        loop {}
    }
}

// =============================================================================
// x86_64 Implementation
// =============================================================================
#[cfg(target_arch = "x86_64")]
extern crate alloc;

#[cfg(target_arch = "x86_64")]
use alloc::boxed::Box;
#[cfg(target_arch = "x86_64")]
use alloc::string::ToString;
#[cfg(target_arch = "x86_64")]
use bootloader_api::config::{BootloaderConfig, Mapping};
#[cfg(target_arch = "x86_64")]
use kernel::syscall::SyscallResult;
#[cfg(target_arch = "x86_64")]
use x86_64::VirtAddr;

/// Bootloader configuration to enable physical memory mapping
#[cfg(target_arch = "x86_64")]
pub static BOOTLOADER_CONFIG: BootloaderConfig = {
    let mut config = BootloaderConfig::new_default();
    config.mappings.physical_memory = Some(Mapping::Dynamic);
    // TODO: Enable higher-half kernel once we make kernel PIE
    // config.mappings.kernel_base = Mapping::FixedAddress(0xFFFF800000000000);
    config
};

#[cfg(target_arch = "x86_64")]
bootloader_api::entry_point!(kernel_main, config = &BOOTLOADER_CONFIG);

// Import the kernel library crate. All modules are accessed via kernel::.
// #[macro_use] makes serial_println!, serial_print!, delay!, test_checkpoint! available.
#[cfg(target_arch = "x86_64")]
#[macro_use]
extern crate kernel;

// Re-import commonly used kernel modules for unqualified access
#[cfg(all(target_arch = "x86_64", feature = "interactive"))]
use kernel::graphics;
// Unqualified `test_framework::` appears in exactly one place: the staged
// registry dispatch below. Every other reference is fully qualified, so this
// import's cfg has to match that block exactly or a `btrt`-only build warns on
// an unused import (it did, before and after this change was scoped).
#[cfg(all(
    target_arch = "x86_64",
    feature = "boot_tests",
    feature = "x86_staged_registry"
))]
use kernel::test_framework;
#[cfg(all(
    target_arch = "x86_64",
    not(any(
        feature = "kthread_test_only",
        feature = "kthread_stress_test",
        feature = "workqueue_test_only",
        feature = "dns_test_only",
        feature = "blocking_recv_test",
        feature = "nonblock_eagain_test"
    ))
))]
use kernel::{clock_gettime_test, time_test};
#[cfg(all(target_arch = "x86_64", feature = "testing"))]
use kernel::{contract_runner, gdt_tests, userspace_fault_tests};
#[cfg(target_arch = "x86_64")]
use kernel::{
    drivers, gdt, interrupts, keyboard, logger, memory, net, per_cpu, preempt_count_test, process,
    serial, stack_switch, syscall, task, test_exec, time, tls, tracing, tty, userspace_test,
};

// Fault test thread function
#[cfg(all(target_arch = "x86_64", feature = "testing"))]
#[allow(dead_code)]
extern "C" fn fault_test_thread(_arg: u64) -> ! {
    // Wait briefly for initial Ring 3 process to run (scheduler will handle timing)
    log::info!("Fault test thread: Waiting for initial Ring 3 validation...");

    // Yield to scheduler a few times to let Ring 3 processes run first
    // The scheduler will naturally prioritize user processes
    for _ in 0..10 {
        task::scheduler::yield_current();
    }

    log::info!("Fault test thread: Running user-only fault tests...");
    userspace_fault_tests::run_fault_tests();

    // Thread complete, just halt
    loop {
        x86_64::instructions::hlt();
    }
}

#[cfg(target_arch = "x86_64")]
fn kernel_main(boot_info: &'static mut bootloader_api::BootInfo) -> ! {
    // Initialize logger early so all log messages work
    logger::init_early();

    // Now we can use log! macros immediately - they'll be buffered
    log::info!("Kernel entry point reached");
    log::debug!("Boot info address: {:p}", boot_info);

    // Initialize serial port
    log::info!("Initializing serial port...");
    serial::init();

    // Initialize the /proc/kmsg log buffer early so ALL serial output is captured
    kernel::log_buffer::init();

    // Tell logger that serial is ready - this will flush buffered messages
    logger::serial_ready();

    log::info!("Serial port initialized and buffer flushed");

    // Get framebuffer and complete logger initialization
    log::info!("Setting up framebuffer...");
    let framebuffer = boot_info.framebuffer.as_mut().unwrap();
    let frame_buffer_info = framebuffer.info().clone();
    let raw_frame_buffer = framebuffer.buffer_mut();

    // Complete logger initialization with framebuffer
    logger::init_framebuffer(raw_frame_buffer, frame_buffer_info);

    log::info!("Initializing kernel systems...");

    // Initialize GDT and IDT
    interrupts::init();
    log::info!("GDT and IDT initialized");

    // Run GDT validation tests (after GDT/IDT init, before per-CPU setup)
    #[cfg(feature = "testing")]
    {
        log::info!("Running GDT validation tests...");
        gdt_tests::run_all_tests();
        log::info!("GDT tests completed");
    }

    // Initialize per-CPU data (must be after GDT/TSS setup)
    per_cpu::init();
    // Set the TSS pointer in per-CPU data
    per_cpu::set_tss(gdt::get_tss_ptr());
    log::info!("Per-CPU data initialized");

    // Run comprehensive preempt_count tests (before interrupts are enabled)
    log::info!("Running preempt_count comprehensive tests...");
    preempt_count_test::test_preempt_count_comprehensive();
    preempt_count_test::test_preempt_count_scheduling();
    log::info!("✅ preempt_count tests completed successfully");

    // Initialize memory management
    log::info!("Checking physical memory offset availability...");
    let physical_memory_offset = match boot_info.physical_memory_offset.into_option() {
        Some(offset) => {
            log::info!("Physical memory offset available: {:#x}", offset);
            VirtAddr::new(offset)
        }
        None => {
            log::error!("Physical memory offset not available! The bootloader needs to be configured to map physical memory.");
            panic!("Cannot initialize memory without physical memory mapping");
        }
    };
    let rsdp_addr = boot_info.rsdp_addr.into_option();
    let memory_regions = &boot_info.memory_regions;
    memory::init(physical_memory_offset, memory_regions);

    // #814 PR-1 / #629: enumerate the processors the firmware reports and
    // answer the CPU-count question from that enumeration instead of from a
    // compile-time constant. This reads four fixed ACPI tables through the
    // bootloader's physical-memory window, which is why it runs after
    // memory::init has installed the master kernel page table. It starts no
    // processor: see kernel/src/arch_impl/x86_64/smp.rs for what `online=1` in
    // the marker it emits does and does not claim.
    kernel::arch_impl::x86_64::smp::init(rsdp_addr, physical_memory_offset.as_u64());

    // Initialize BTRT (requires memory for virt_to_phys and serial for output)
    #[cfg(feature = "btrt")]
    {
        use kernel::test_framework::{btrt, catalog};
        btrt::init();
        btrt::pass(catalog::KERNEL_ENTRY);
        btrt::pass(catalog::SERIAL_INIT);
        btrt::pass(catalog::GDT_IDT_INIT);
        btrt::pass(catalog::PER_CPU_INIT);
        btrt::pass(catalog::MEMORY_INIT);
        btrt::pass(catalog::HEAP_INIT);
        btrt::pass(catalog::FRAME_ALLOC_INIT);
    }

    // Upgrade framebuffer to double buffering now that heap is available
    #[cfg(feature = "interactive")]
    logger::upgrade_to_double_buffer();

    // Initialize multi-terminal split-screen mode:
    // - Left side: Graphics demo (static)
    // - Right side: Tabbed terminals (Shell, Logs)
    // - F1/F2 to switch between terminals
    #[cfg(feature = "interactive")]
    {
        log::info!("Initializing multi-terminal display...");
        if let Some(fb) = logger::SHELL_FRAMEBUFFER.get() {
            let mut fb_guard = fb.lock();

            use kernel::graphics::primitives::Canvas;
            let width = Canvas::width(&*fb_guard);
            let height = Canvas::height(&*fb_guard);

            // Calculate layout: 50% left for demo, 50% right for terminals
            let divider_x = width / 2;
            let divider_width = 4;
            // Clear entire screen with dark background
            graphics::primitives::fill_rect(
                &mut *fb_guard,
                graphics::primitives::Rect {
                    x: 0,
                    y: 0,
                    width: width as u32,
                    height: height as u32,
                },
                graphics::primitives::Color::rgb(20, 30, 50),
            );

            // Draw graphics demo on left pane
            let left_region = graphics::split_screen::ClippedRegion {
                offset_x: 0,
                offset_y: 0,
                width: divider_x as u32,
                height: height as u32,
            };
            graphics::demo::run_demo_in_region(&mut *fb_guard, &left_region);

            // Draw vertical divider
            for i in 0..divider_width {
                graphics::primitives::draw_vline(
                    &mut *fb_guard,
                    (divider_x + i) as i32,
                    0,
                    height as i32 - 1,
                    graphics::primitives::Color::rgb(60, 80, 100),
                );
            }

            // Initialize the render queue for deferred framebuffer rendering
            graphics::render_queue::init();

            // Initialize log capture ring buffer for serial output tee
            graphics::log_capture::init();

            // Flush to screen
            if let Some(db) = fb_guard.double_buffer_mut() {
                db.flush_full();
            }

            log::info!("Split-screen display ready");
        }
    }

    // Phase 0: Log kernel layout inventory
    memory::layout::log_kernel_layout();

    // Initialize PCI and enumerate devices (needed for disk I/O)
    let pci_device_count = drivers::init();
    log::info!(
        "PCI subsystem initialized: {} devices found",
        pci_device_count
    );
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::PCI_ENUMERATION);

    // Initialize network stack (after E1000 driver is ready)
    net::init();
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::NETWORK_STACK_INIT);

    // ext2 is backed by IRQ-driven VirtIO block I/O. Mount it later, after
    // PIC/timer/scheduler setup, inside the temporary interrupt-enabled window.

    // Initialize devfs (/dev virtual filesystem)
    kernel::fs::devfs::init();
    log::info!("devfs initialized at /dev");

    // Initialize devptsfs (/dev/pts pseudo-terminal slave filesystem)
    kernel::fs::devptsfs::init();
    log::info!("devptsfs initialized at /dev/pts");

    // Detect CPU features (must be before procfs so /proc/cpuinfo has real data)
    kernel::arch_impl::x86_64::cpuinfo::init();
    log::info!(
        "CPU detected: {}",
        kernel::arch_impl::x86_64::cpuinfo::get()
            .map(|c| c.brand_str())
            .unwrap_or("Unknown")
    );

    // Initialize procfs (/proc virtual filesystem)
    kernel::fs::procfs::init();
    log::info!("procfs initialized at /proc");
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::PROCFS_INIT);

    // Update IST stacks with per-CPU emergency stacks
    gdt::update_ist_stacks();
    log::info!("Updated IST stacks with per-CPU emergency and page fault stacks");

    // Allocate initial kernel stack and set TSS.RSP0 before contract tests
    // This ensures Ring 3 → Ring 0 transitions will work
    {
        let initial_kernel_stack = memory::kernel_stack::allocate_kernel_stack()
            .expect("Failed to allocate initial kernel stack");
        let stack_top = initial_kernel_stack.top();
        per_cpu::set_kernel_stack_top(stack_top.as_u64());
        // Use gdt::set_tss_rsp0 which works with TSS_PTR directly
        gdt::set_tss_rsp0(stack_top);
        log::info!("Initial TSS.RSP0 set to {:#x}", stack_top);
        // This stack will be replaced later by the idle thread stack
        core::mem::forget(initial_kernel_stack);
    }

    // Run contract tests to verify kernel invariants
    #[cfg(feature = "testing")]
    {
        log::info!("Running contract tests...");
        let (passed, failed) = contract_runner::run_all_contracts();
        log::info!("Contract tests: {} passed, {} failed", passed, failed);
        if failed > 0 {
            panic!("Contract test failures!");
        }
    }

    // Test heap allocation
    log::info!("Testing heap allocation...");
    {
        use alloc::vec::Vec;
        let mut vec = Vec::new();
        for i in 0..10 {
            vec.push(i);
        }
        log::info!("Heap test: created vector with {} elements", vec.len());
        log::info!("Heap test: sum of elements = {}", vec.iter().sum::<i32>());
    }
    log::info!("Heap allocation test passed!");

    // Initialize TLS (Thread Local Storage)
    tls::init();
    log::info!("TLS initialized");

    // Setup SWAPGS support for syscall entry/exit
    if let Err(e) = tls::setup_swapgs_support() {
        log::error!("Failed to setup SWAPGS support: {}", e);
    } else {
        log::info!("SWAPGS support enabled");
    }

    // Initialize keyboard queue
    keyboard::init();
    log::info!("Keyboard queue initialized");

    // Initialize TTY subsystem
    tty::init();

    // Initialize PIC BEFORE timer so interrupts can be delivered
    log::info!("Initializing PIC...");
    interrupts::init_pic();
    log::info!("PIC initialized");

    // CRITICAL: Initialize timer AFTER PIC but BEFORE interrupts are enabled
    // The PIT must be programmed before interrupts::enable() is called, otherwise
    // no timer interrupts can fire and the scheduler will not run.
    time::init();
    log::info!("Timer initialized");
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::TIMER_INIT);

    // Initialize DTrace-style tracing framework
    // This must be after per_cpu::init() and time::init() for timestamps
    tracing::init();
    tracing::providers::init();
    // Enable tracing and all providers for kernel observability
    tracing::enable();
    tracing::providers::enable_all();
    log::info!("Tracing subsystem initialized and enabled");
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::TRACING_INIT);

    // CHECKPOINT A: Verify PIT Configuration
    log::info!("CHECKPOINT A: PIT initialized at {} Hz", 100);

    // CRITICAL: Unmask timer interrupt (IRQ 0)
    unsafe {
        use x86_64::instructions::port::Port;
        let mut pic1_data = Port::<u8>::new(0x21);
        let mask = pic1_data.read();
        pic1_data.write(mask & !0x01); // Clear bit 0 to unmask IRQ 0 (timer)
    }
    log::info!("Timer interrupt unmasked");

    // Now it's safe to enable serial input interrupts
    serial::enable_serial_input();

    // Register serial command handlers
    serial::command::register_handlers(
        || {
            // PS handler
            if let Some(ref manager) = *process::manager() {
                manager.debug_processes();
            } else {
                serial_println!("Process manager not initialized");
            }
        },
        || {
            // MEM handler
            memory::debug_memory_info();
        },
        || {
            // TEST handler
            serial_println!("Running test processes...");
            userspace_test::test_multiple_processes();
            serial_println!("Test processes scheduled. Type to continue...");
        },
        || {
            // FORKTEST handler
            serial_println!("Testing Fork System Call (Debug Mode)");
            userspace_test::test_fork_debug();
            serial_println!("Fork debug test scheduled. Press keys to continue...");
        },
        || {
            // EXECTEST handler - test userspace fork when testing feature enabled
            #[cfg(feature = "testing")]
            {
                serial_println!("Testing Fork Syscall from Userspace");
                test_exec::test_userspace_fork();
                serial_println!("Userspace fork test completed. Press keys to continue...");
            }
            #[cfg(not(feature = "testing"))]
            {
                serial_println!("Testing Exec System Call with Real Userspace Programs");
                test_exec::test_exec_real_userspace();
                serial_println!("Real userspace exec test scheduled. Press keys to continue...");
            }
        },
    );

    // Initialize syscall infrastructure
    log::info!("Initializing system call infrastructure...");
    syscall::init();
    log::info!("System call infrastructure initialized");

    // Initialize threading subsystem (Linux-style init/idle separation)
    log::info!("Initializing threading subsystem...");

    // CRITICAL FIX: Allocate a proper kernel stack for the idle thread
    // This ensures TSS.rsp0 points to the upper half, not the bootstrap stack
    log::info!("Allocating kernel stack for idle thread from upper half...");
    let idle_kernel_stack = memory::kernel_stack::allocate_kernel_stack()
        .expect("Failed to allocate kernel stack for idle thread");
    let idle_kernel_stack_top = idle_kernel_stack.top();
    log::info!(
        "Idle thread kernel stack allocated at {:#x} (PML4[{}])",
        idle_kernel_stack_top,
        (idle_kernel_stack_top.as_u64() >> 39) & 0x1FF
    );

    // CRITICAL: Update TSS and switch stacks atomically
    // This ensures no interrupts can occur between TSS update and stack switch
    x86_64::instructions::interrupts::without_interrupts(|| {
        // Set TSS.RSP0 to the kernel stack BEFORE switching
        // This ensures interrupts from userspace will use the correct stack
        per_cpu::set_kernel_stack_top(idle_kernel_stack_top.as_u64());
        per_cpu::update_tss_rsp0(idle_kernel_stack_top.as_u64());
        log::info!(
            "TSS.RSP0 set to kernel stack at {:#x}",
            idle_kernel_stack_top
        );

        // Keep the kernel stack alive (it will be used forever)
        // Using mem::forget is acceptable here with clear comment
        core::mem::forget(idle_kernel_stack); // Intentionally leaked - idle stack lives forever

        // Log the current bootstrap stack before switching
        let current_rsp: u64;
        unsafe {
            core::arch::asm!("mov {}, rsp", out(reg) current_rsp, options(nomem, nostack));
        }
        log::info!(
            "About to switch from bootstrap stack at {:#x} (PML4[{}]) to kernel stack",
            current_rsp,
            (current_rsp >> 39) & 0x1FF
        );

        // CRITICAL: Actually switch to the kernel stack!
        // After this point, we're running on the upper-half kernel stack
        unsafe {
            // Switch stacks and continue initialization
            // Pass the stack top as an argument so the continuation knows the correct value
            stack_switch::switch_stack_and_call_with_arg(
                idle_kernel_stack_top.as_u64(),
                kernel_main_on_kernel_stack,
                idle_kernel_stack_top.as_u64() as *mut core::ffi::c_void,
            );
        }
    });
    // Never reached - switch_stack_and_call_with_arg never returns
    unreachable!("Stack switch function should never return")
}

/// Continuation of kernel_main after switching to the upper-half kernel stack
/// This function runs on the properly allocated kernel stack, not the bootstrap stack
/// arg: the idle kernel stack top address (passed from kernel_main)
#[cfg(target_arch = "x86_64")]
extern "C" fn kernel_main_on_kernel_stack(arg: *mut core::ffi::c_void) -> ! {
    // Verify stack alignment per SysV ABI (RSP % 16 == 8 at function entry after call)
    let current_rsp: u64;
    unsafe {
        core::arch::asm!("mov {}, rsp", out(reg) current_rsp, options(nomem, nostack));
    }
    debug_assert_eq!(
        current_rsp & 0xF,
        8,
        "SysV stack misaligned at callee entry"
    );

    // Log that we're now on the kernel stack
    log::info!(
        "Successfully switched to kernel stack! RSP={:#x} (PML4[{}])",
        current_rsp,
        (current_rsp >> 39) & 0x1FF
    );

    // Use the actual kernel stack top passed from kernel_main
    let idle_kernel_stack_top = VirtAddr::new(arg as u64);

    // Create init_task (PID 0) - represents the currently running boot thread
    // This is the Linux swapper/idle task pattern
    let tls_base = tls::current_tls_base();
    let mut init_task = Box::new(task::thread::Thread::new(
        "swapper/0".to_string(), // Linux convention: swapper/0 is the idle task
        idle_thread_fn,
        VirtAddr::new(0),      // Will be set to current RSP
        idle_kernel_stack_top, // Use the properly allocated kernel stack
        VirtAddr::new(tls_base),
        task::thread::ThreadPrivilege::Kernel,
    ));

    // Mark init_task as already running (boot CPU idle task). The id stays the
    // one `Thread::new` allocated: 0 is the no-thread sentinel and is never a
    // live thread id.
    init_task.state = task::thread::ThreadState::Running;

    // Store the kernel stack in the thread (important for context switching)
    init_task.kernel_stack_top = Some(idle_kernel_stack_top);

    // Set up per-CPU current thread and idle thread
    let init_task_ptr = &*init_task as *const _ as *mut task::thread::Thread;
    per_cpu::set_current_thread(init_task_ptr);
    per_cpu::set_idle_thread(init_task_ptr);

    // CRITICAL: Ensure TSS.RSP0 is set to the kernel stack
    // This was already done before the stack switch, but verify it
    per_cpu::set_kernel_stack_top(idle_kernel_stack_top.as_u64());
    per_cpu::update_tss_rsp0(idle_kernel_stack_top.as_u64());

    log::info!("TSS.RSP0 verified at {:#x}", idle_kernel_stack_top);

    // Initialize scheduler with init_task as the current thread
    // This follows Linux where the boot thread becomes the idle task
    task::scheduler::init_with_current(init_task);
    log::info!("Threading subsystem initialized with init_task (swapper/0)");
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::SCHEDULER_INIT);

    log::info!(
        "percpu: cpu0 base={:#x}, current=swapper/0, rsp0={:#x}",
        x86_64::registers::model_specific::GsBase::read().as_u64(),
        idle_kernel_stack_top
    );

    // Initialize process management
    log::info!("Initializing process management...");
    process::init();
    log::info!("Process management initialized");

    // Initialize workqueue subsystem (depends on kthread infrastructure)
    task::workqueue::init_workqueue();
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::WORKQUEUE_INIT);

    // Initialize softirq subsystem (depends on kthread infrastructure)
    task::softirqd::init_softirq();
    crate::net::init_loopback_pump();
    // #775 round 4, R3-5/N14: the third census emission context, spawned
    // beside kloopbackd on the unconditional init path so it exists in the
    // zero-feature production profile. idle_loop and the pump both emit only
    // when the rest of the kernel gives them a reason to run.
    task::start_dispatch_strand_census_kthread();
    #[cfg(feature = "btrt")]
    kernel::test_framework::btrt::pass(kernel::test_framework::catalog::KTHREAD_SUBSYSTEM);

    // IRQ-driven driver self-tests must run after PIC/timer/scheduler setup
    // and with IF=1 so device completions can arrive on hardware IRQ lines.
    log::info!("Temporarily enabling interrupts for driver post-init self-tests...");
    x86_64::instructions::interrupts::enable();
    drivers::run_post_init_self_tests();

    // Initialize ext2 root filesystem once IRQ-driven block completions can arrive.
    match kernel::fs::ext2::init_root_fs() {
        Ok(()) => {
            log::info!("ext2 root filesystem mounted");
            #[cfg(feature = "btrt")]
            kernel::test_framework::btrt::pass(kernel::test_framework::catalog::EXT2_MOUNT);
        }
        Err(e) => {
            log::warn!("Failed to mount ext2 root: {:?}", e);
            #[cfg(feature = "btrt")]
            kernel::test_framework::btrt::fail(
                kernel::test_framework::catalog::EXT2_MOUNT,
                kernel::test_framework::btrt::BtrtErrorCode::IoError,
                0,
            );
        }
    }

    // ext2/VFS fault-injection leg (test profile only, feature `fs_fault_inject`).
    // Runs immediately after the root filesystem mounts, so every marker the rest
    // of this boot prints is evidence the kernel survived the injected faults.
    #[cfg(feature = "fs_fault_inject")]
    kernel::fs::fault_inject::run_fs_fault_leg();
    // Initialize ext2 home filesystem only when the x86 home disk is attached.
    if kernel::block::virtio::VirtioBlockWrapper::new(3).is_some() {
        match kernel::fs::ext2::init_home_fs() {
            Ok(()) => log::info!("ext2 home filesystem mounted at /home"),
            Err(e) => log::warn!("No home filesystem: {}", e),
        }
    } else {
        log::info!("No home filesystem: no home block device attached");
    }

    // Run after process::init() and the memory custody gates, while deferred-reclaim
    // queues are still quiescent and before any user process exists. This is inside
    // the IF=1 driver-test window because the gates need timer ticks and scheduler
    // epochs; placing them immediately after process::init() would spin forever.
    // The state-free fence check runs first. The reclaim-progress gate then owns
    // and returns quiescent deferred-reclaim queues. The retire cohort follows,
    // and the exec cohort runs last among page-table cohorts because it supersedes
    // populated address spaces. The clone admission gate follows immediately so
    // the publication transaction is ratcheted by the same fail-loud sequence.
    // The init designation transaction follows because it touches the reserved PID and leaves
    // the designation cleared. The init-group refusal gate follows because it is the only gate
    // that installs a designation and then clears it, and the rest of the boot still asserts no
    // real init. The ownership gate runs last among boot-test gates because its 1000-iteration
    // stress churns the kernel-stack pool and frame allocator after every gate that pins absolute
    // frame or page-table custody counts.
    #[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
    {
        // #767 first: it makes 3 relaxed loads of the tick counter, 1
        // AtomicBool swap and 1 serial line, so it cannot move the frame,
        // page-table or kernel-stack counts the gates below pin, while the
        // gates below churn state this sample does not care about. It needs
        // only a tick counter that is already advancing, which
        // interrupts::enable() above gives it.
        kernel::time_test::run_x86_timer_scale_gate();
        // #821 second, for the same reason #767 is first: its footprint is
        // two bytes pushed through the TTY input IRQ entry plus one brief
        // PROCESS_MANAGER hold, with 0 heap allocations and 0 process rows
        // created, so it does not move the frame, page-table or kernel-stack
        // counts the gates below pin. It has to be HERE rather
        // than later because this is the window where the boot thread runs
        // with IF=1: an x86 `manager()` holder with interrupts live is exactly
        // the exposed shape the #821 census names, and the oracle needs to be
        // one.
        kernel::test_framework::registry::run_tty_irq_pm_oracle();
        // #822 third, immediately after #821 and for the same reasons: two
        // bytes through the same TTY input IRQ entry plus one brief hold of the
        // console's own foreground_pgrp, with 0 heap allocations and 0 process
        // rows created, so it does not move the frame, page-table or
        // kernel-stack counts the gates below pin. It has to be HERE for the
        // same reason #821 does: this is the window where the boot thread runs
        // with IF=1, and a thread-context holder of this lock with interrupts
        // live is exactly the exposed shape the census names.
        kernel::test_framework::registry::run_tty_irq_fg_oracle();
        // Critical-path logging drain PR-1, fourth and for the same reason the
        // three above are here: its footprint is ten relaxed atomic adds and
        // three serial lines, with 0 heap allocations and 0 process rows
        // created, so it cannot move the frame, page-table or kernel-stack
        // counts the gates below pin. It has to be in this window because it
        // asserts that it runs with interrupts enabled -- the census
        // reporter's own emission boundary refuses otherwise -- and
        // `interrupts::disable()` comes after this block.
        kernel::test_framework::registry::run_x86_dispatch_fact_oracle();
        kernel::task::process_task::run_x86_retirement_fence_gate();
        kernel::task::process_task::run_x86_reclaim_progress_gate();
        kernel::tracing::providers::teardown::run_x86_retire_cohort_gate();
        kernel::test_framework::registry::run_x86_loopback_gates();
        kernel::task::boot_resume_oracle::run();
        kernel::tracing::providers::teardown::run_x86_exec_cohort_gate();
        kernel::tracing::providers::teardown::run_x86_exec_detach_gate();
        kernel::tracing::providers::teardown::run_x86_clone_admission_gate();
        kernel::tracing::providers::teardown::run_x86_init_designation_gate();
        kernel::tracing::providers::teardown::run_x86_init_group_refusal_gate();
        kernel::tracing::providers::teardown::run_x86_kernel_stack_ownership_gate();
        kernel::tracing::providers::teardown::run_x86_tombstone_join_gate();
    }

    // #847 (ruling R188): the x86 print site for the ring-depth self-check's
    // `[RING_SPAN:...]` marker, which the timer tick now publishes rather than
    // writes. Placed AFTER the gate block above, not inside it: this call can
    // spin (bounded) waiting for the publication, and the gates above pin
    // absolute frame, page-table and kernel-stack counts that a preemption
    // window opened between two of them could move. Interrupts are still
    // enabled here -- `interrupts::disable()` comes below, after the oracles --
    // which is what lets the publishing tick run.
    #[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
    kernel::test_framework::registry::run_x86_ring_span_gate();

    // Tracing framework, x86 leg (#533/#680/#681): the deferred-fault-ring
    // overflow provider test already exists and already runs on aarch64
    // through the staged registry executor, but that executor is off by
    // default on x86 (see
    // docs/planning/green-program/tracing/X86-533-2026-08-28.md). This is
    // the same direct-call shape as `run_x86_ring_span_gate` immediately
    // above: call the existing provider test function directly and print its
    // own `[TEST:...]` markers, rather than turning the staged executor on.
    // Its private queue/drain fixture does not schedule and does not move
    // the frame/page-table/kernel-stack counts the gate block above pins.
    #[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
    kernel::test_framework::registry::run_x86_tracing_provider_gate();

    // #728 ext2 lock-discipline repro oracle (test profile only, feature
    // `ext2_lock_race`). Needs a running scheduler/timer/preemption, so it
    // runs here rather than at the fault-injection leg's early insertion
    // point right after mount -- kthreads do not exist that early in boot.
    #[cfg(all(target_arch = "x86_64", feature = "ext2_lock_race"))]
    kernel::fs::ext2_lock_race::run_ext2_lock_race_leg();

    kernel::tracing::providers::teardown::emit_root_custody_summary();
    kernel::tracing::providers::teardown::emit_tombstone_census();
    // Slice 3e's oracle, x86_64 arm: MAX_CPUS is 1 here, so the arm reports a
    // SKIP with that reason rather than a verdict it did not measure.
    #[cfg(feature = "boot_tests")]
    kernel::task::scheduler::emit_pin_guard_oracle();

    x86_64::instructions::interrupts::disable();
    log::info!("Driver post-init self-tests complete; interrupts disabled for remaining init");

    // Spawn render thread for deferred framebuffer rendering (interactive mode only)
    // This must be done after kthread infrastructure is ready.
    //
    // Boot graphics architecture (shared with ARM64):
    // - Both architectures use render_task::spawn_render_thread() for deferred rendering
    // - Both use SHELL_FRAMEBUFFER (logger.rs on x86_64, arm64_fb.rs on ARM64)
    // - Both use graphics::render_queue for lock-free echo from interrupt context
    // - BWM (userspace window manager) handles terminal rendering
    // - Boot test progress display (test_framework::display) renders to SHELL_FRAMEBUFFER
    // - Boot milestones are tracked via BTRT (test_framework::btrt) on both platforms
    #[cfg(feature = "interactive")]
    if let Err(e) = graphics::render_task::spawn_render_thread() {
        log::error!("Failed to spawn render thread: {}", e);
    }

    // Test kthread lifecycle BEFORE creating userspace processes
    // (must be done early so scheduler doesn't preempt to userspace)
    #[cfg(feature = "testing")]
    kernel::task::kthread_tests::test_kthread_lifecycle();
    #[cfg(feature = "testing")]
    kernel::task::kthread_tests::test_kthread_join();
    // Skip workqueue test in kthread_stress_test mode - it passes in Boot Stages
    // which has the same code but different build configuration. The stress test
    // focuses on kthread lifecycle, not workqueue functionality.
    #[cfg(all(feature = "testing", not(feature = "kthread_stress_test")))]
    kernel::task::workqueue_tests::test_workqueue();
    #[cfg(all(feature = "testing", not(feature = "kthread_stress_test")))]
    kernel::task::softirq_tests::test_softirq();

    // In kthread_test_only mode, exit immediately after join test
    #[cfg(feature = "kthread_test_only")]
    {
        log::info!("=== KTHREAD_TEST_ONLY: All kthread tests passed ===");
        log::info!("KTHREAD_TEST_ONLY_COMPLETE");
        unsafe {
            use x86_64::instructions::port::Port;
            let mut port = Port::new(0xf4);
            port.write(0x00u32);
        }
        loop {
            x86_64::instructions::hlt();
        }
    }

    // In workqueue_test_only mode, exit immediately after workqueue test
    #[cfg(feature = "workqueue_test_only")]
    {
        log::info!("=== WORKQUEUE_TEST_ONLY: All workqueue tests passed ===");
        log::info!("WORKQUEUE_TEST_ONLY_COMPLETE");
        // Exit QEMU with success code
        unsafe {
            use x86_64::instructions::port::Port;
            let mut port = Port::new(0xf4);
            port.write(0x00u32); // This causes QEMU to exit
        }
        loop {
            x86_64::instructions::hlt();
        }
    }

    // In kthread_stress_test mode, run stress test and exit
    #[cfg(feature = "kthread_stress_test")]
    {
        kernel::task::kthread_tests::test_kthread_stress();
        log::info!("=== KTHREAD_STRESS_TEST: All stress tests passed ===");
        log::info!("KTHREAD_STRESS_TEST_COMPLETE");
        unsafe {
            use x86_64::instructions::port::Port;
            let mut port = Port::new(0xf4);
            port.write(0x00u32);
        }
        loop {
            x86_64::instructions::hlt();
        }
    }

    #[cfg(all(
        feature = "testing",
        not(feature = "kthread_test_only"),
        not(feature = "kthread_stress_test"),
        not(feature = "workqueue_test_only")
    ))]
    kernel::task::kthread_tests::test_kthread_exit_code();
    #[cfg(all(
        feature = "testing",
        not(feature = "kthread_test_only"),
        not(feature = "kthread_stress_test"),
        not(feature = "workqueue_test_only")
    ))]
    kernel::task::kthread_tests::test_kthread_park_unpark();
    #[cfg(all(
        feature = "testing",
        not(feature = "kthread_test_only"),
        not(feature = "kthread_stress_test"),
        not(feature = "workqueue_test_only")
    ))]
    kernel::task::kthread_tests::test_kthread_double_stop();
    #[cfg(all(
        feature = "testing",
        not(feature = "kthread_test_only"),
        not(feature = "kthread_stress_test"),
        not(feature = "workqueue_test_only")
    ))]
    kernel::task::kthread_tests::test_kthread_should_stop_non_kthread();
    #[cfg(all(
        feature = "testing",
        not(feature = "kthread_test_only"),
        not(feature = "kthread_stress_test"),
        not(feature = "workqueue_test_only")
    ))]
    kernel::task::kthread_tests::test_kthread_stop_after_exit();

    // The 766 latency leg creates ten kernel threads after the custody gates
    // whose counters pin earlier allocations. Keep it beside the lifecycle
    // tests; it restores the interrupt flag it finds on entry.
    #[cfg(all(target_arch = "x86_64", feature = "boot_tests"))]
    kernel::task::timer_wake_oracle::run();

    // Continue with the rest of kernel initialization...
    // (This will include creating user processes, enabling interrupts, etc.)
    #[cfg(not(any(
        feature = "kthread_test_only",
        feature = "kthread_stress_test",
        feature = "workqueue_test_only",
        feature = "dns_test_only",
        feature = "blocking_recv_test",
        feature = "nonblock_eagain_test"
    )))]
    kernel_main_continue();

    // DNS_TEST_ONLY mode: Skip all other tests, just run dns_test
    #[cfg(feature = "dns_test_only")]
    dns_test_only_main();

    // BLOCKING_RECV_TEST mode: Skip all other tests, just run blocking_recv_test
    #[cfg(feature = "blocking_recv_test")]
    blocking_recv_test_main();

    // NONBLOCK_EAGAIN_TEST mode: Skip all other tests, just run nonblock_eagain_test
    #[cfg(feature = "nonblock_eagain_test")]
    nonblock_eagain_test_main();
}

/// DNS test only mode - minimal boot, just run DNS test and exit
#[cfg(all(target_arch = "x86_64", feature = "dns_test_only"))]
fn dns_test_only_main() -> ! {
    use alloc::string::String;

    log::info!("=== DNS_TEST_ONLY: Starting minimal DNS test ===");

    // Disk-backed test binaries require VirtIO block IRQ completions.
    x86_64::instructions::interrupts::enable();
    serial_println!("DNS_TEST_ONLY: Loading dns_test binary");
    let elf = userspace_test::get_test_binary("dns_test");

    // Create dns_test process
    x86_64::instructions::interrupts::without_interrupts(|| {
        match process::create_user_process(String::from("dns_test"), &elf) {
            Ok(pid) => {
                log::info!(
                    "DNS_TEST_ONLY: Created dns_test process with PID {}",
                    pid.as_u64()
                );
            }
            Err(e) => {
                log::error!("DNS_TEST_ONLY: Failed to create dns_test: {}", e);
                // Exit with error
                unsafe {
                    use x86_64::instructions::port::Port;
                    let mut port = Port::new(0xf4);
                    port.write(0x01u32); // Error exit
                }
            }
        }
    });

    // Enable interrupts so dns_test can run
    log::info!("DNS_TEST_ONLY: Enabling interrupts");
    x86_64::instructions::interrupts::enable();

    // Enter idle loop - dns_test will run via scheduler
    // The test harness watches for "DNS Test: All tests passed" marker
    // and kills QEMU when it appears
    log::info!("DNS_TEST_ONLY: Entering idle loop (dns_test running via scheduler)");
    loop {
        x86_64::instructions::interrupts::enable_and_hlt();

        // Yield to give scheduler a chance
        task::scheduler::yield_current();

        // Drain loopback queue for localhost packets
        net::drain_loopback_queue();
    }
}

/// Blocking recvfrom test only mode - minimal boot, just run blocking_recv_test and exit
#[cfg(all(target_arch = "x86_64", feature = "blocking_recv_test"))]
fn blocking_recv_test_main() -> ! {
    use alloc::string::String;

    log::info!("=== BLOCKING_RECV_TEST: Starting minimal blocking recv test ===");

    // Disk-backed test binaries require VirtIO block IRQ completions.
    x86_64::instructions::interrupts::enable();
    serial_println!("BLOCKING_RECV_TEST: Loading blocking_recv_test binary");
    let elf = match userspace_test::load_test_binary_from_disk("blocking_recv_test") {
        Ok(elf) => elf,
        Err(e) => {
            log::error!(
                "BLOCKING_RECV_TEST: Failed to load blocking_recv_test: {}",
                e
            );
            unsafe {
                use x86_64::instructions::port::Port;
                let mut port = Port::new(0xf4);
                port.write(0x01u32);
            }
            loop {
                x86_64::instructions::hlt();
            }
        }
    };

    // Create blocking_recv_test process
    x86_64::instructions::interrupts::without_interrupts(|| {
        match process::create_user_process(String::from("blocking_recv_test"), &elf) {
            Ok(pid) => {
                log::info!(
                    "BLOCKING_RECV_TEST: Created blocking_recv_test process with PID {}",
                    pid.as_u64()
                );
            }
            Err(e) => {
                log::error!(
                    "BLOCKING_RECV_TEST: Failed to create blocking_recv_test: {}",
                    e
                );
                unsafe {
                    use x86_64::instructions::port::Port;
                    let mut port = Port::new(0xf4);
                    port.write(0x01u32);
                }
            }
        }
    });

    // Enable interrupts so blocking_recv_test can run
    log::info!("BLOCKING_RECV_TEST: Enabling interrupts");
    x86_64::instructions::interrupts::enable();

    // Enter idle loop - blocking_recv_test will run via scheduler
    log::info!("BLOCKING_RECV_TEST: Entering idle loop (blocking_recv_test running via scheduler)");
    loop {
        x86_64::instructions::interrupts::enable_and_hlt();

        // Yield to give scheduler a chance
        task::scheduler::yield_current();

        // Drain loopback queue for localhost packets
        net::drain_loopback_queue();
    }
}

/// Nonblock EAGAIN test only mode - minimal boot, just run nonblock_eagain_test and exit
#[cfg(all(target_arch = "x86_64", feature = "nonblock_eagain_test"))]
fn nonblock_eagain_test_main() -> ! {
    use alloc::string::String;

    log::info!("=== NONBLOCK_EAGAIN_TEST: Starting minimal nonblock EAGAIN test ===");

    // Disk-backed test binaries require VirtIO block IRQ completions.
    x86_64::instructions::interrupts::enable();
    serial_println!("NONBLOCK_EAGAIN_TEST: Loading nonblock_eagain_test binary");
    let elf = match userspace_test::load_test_binary_from_disk("nonblock_eagain_test") {
        Ok(elf) => elf,
        Err(e) => {
            log::error!(
                "NONBLOCK_EAGAIN_TEST: Failed to load nonblock_eagain_test: {}",
                e
            );
            unsafe {
                use x86_64::instructions::port::Port;
                let mut port = Port::new(0xf4);
                port.write(0x01u32);
            }
            loop {
                x86_64::instructions::hlt();
            }
        }
    };

    // Create nonblock_eagain_test process
    x86_64::instructions::interrupts::without_interrupts(|| {
        match process::create_user_process(String::from("nonblock_eagain_test"), &elf) {
            Ok(pid) => {
                log::info!(
                    "NONBLOCK_EAGAIN_TEST: Created nonblock_eagain_test process with PID {}",
                    pid.as_u64()
                );
            }
            Err(e) => {
                log::error!(
                    "NONBLOCK_EAGAIN_TEST: Failed to create nonblock_eagain_test: {}",
                    e
                );
                unsafe {
                    use x86_64::instructions::port::Port;
                    let mut port = Port::new(0xf4);
                    port.write(0x01u32);
                }
            }
        }
    });

    // Enable interrupts so nonblock_eagain_test can run
    log::info!("NONBLOCK_EAGAIN_TEST: Enabling interrupts");
    x86_64::instructions::interrupts::enable();

    // Enter idle loop - nonblock_eagain_test will run via scheduler
    // This test should complete quickly since it just verifies EAGAIN return
    log::info!(
        "NONBLOCK_EAGAIN_TEST: Entering idle loop (nonblock_eagain_test running via scheduler)"
    );
    loop {
        x86_64::instructions::interrupts::enable_and_hlt();

        // Yield to give scheduler a chance
        task::scheduler::yield_current();

        // Drain loopback queue for localhost packets
        net::drain_loopback_queue();
    }
}

/// Construct, designate, and publish `/sbin/init` (PID 1) on x86_64, then
/// hand its thread to the scheduler.
///
/// This is the x86_64 counterpart to aarch64's `launch_init_from_elf()` in
/// `main_aarch64.rs`; the two diverge only at the terminal step, per
/// `publish_init()`'s own doc comment: aarch64 ERETs into the thread
/// manually, x86_64 enqueues it on the ordinary scheduler dispatch path via
/// `task::scheduler::spawn()`.
///
/// Must be called with the PROCESS_MANAGER lock's usual boot-time discipline:
/// interrupts masked around the ProcessManager transaction (matching the
/// `testing`/`interactive` blocks in `kernel_main_continue()` this sits
/// beside), and with the ext2 root filesystem already mounted.
///
/// Does NOT take any scheduling brake of its own (#673 review, B3). The
/// caller (`kernel_main_continue()`'s production block) takes ONE
/// `preempt_disable()`/`preempt_enable()` bracket around this call and the
/// rest of boot's remaining sequential work, unconditionally before this
/// function can even be reached and unconditionally at a single matching
/// release site, so the bracket stays dynamically paired on every path
/// through this function -- including every one of its early `?` returns,
/// which used to skip a brake this function took internally while the
/// caller's release ran unconditionally regardless (the #672-shaped
/// asymmetry the review's B3 finding named).
#[cfg(all(
    target_arch = "x86_64",
    not(any(
        feature = "testing",
        feature = "interactive",
        feature = "disable_x86_prod_init"
    ))
))]
fn launch_x86_production_init(elf_data: &[u8]) -> Result<(), &'static str> {
    use alloc::string::String;

    let (thread, designated_pid_raw, reserved_collisions) = {
        let mut manager_guard = process::manager();
        let manager = manager_guard
            .as_mut()
            .ok_or("process manager not available")?;

        let ticket = manager.create_init_process(String::from("init"), elf_data)?;
        let publication = manager.designate_init(ticket)?;
        let designated_pid_raw = manager
            .designated_init()
            .ok_or("init designation missing after publication")?
            .as_u64();
        let reserved_collisions =
            tracing::providers::teardown::init_reserved_pid_collisions_total();
        let thread = manager.publish_init(publication);
        (thread, designated_pid_raw, reserved_collisions)
    };

    serial_println!(
        "[INIT_DESIGNATION:x86_64:designated_pid={}:reserved_collisions={}]",
        designated_pid_raw,
        reserved_collisions
    );

    task::scheduler::spawn(thread);

    Ok(())
}

/// Continue kernel initialization after setting up threading
#[cfg(all(
    target_arch = "x86_64",
    not(any(
        feature = "kthread_test_only",
        feature = "kthread_stress_test",
        feature = "workqueue_test_only",
        feature = "dns_test_only",
        feature = "blocking_recv_test",
        feature = "nonblock_eagain_test"
    ))
))]
fn kernel_main_continue() -> ! {
    // INTERACTIVE MODE: Load init_shell as the only userspace process
    #[cfg(feature = "interactive")]
    {
        // Disk-backed test binaries require VirtIO block IRQ completions, so the
        // load has to happen with interrupts enabled - 62af9d13 hoisted exactly
        // this call out of exactly this kind of block for the testing profile
        // (#554), and the interactive profile kept the hazardous shape because
        // no gate runs it (#665). Only process registration below needs the
        // masked window.
        x86_64::instructions::interrupts::enable();
        serial_println!("INTERACTIVE: Loading init_shell as PID 1");
        let elf = userspace_test::get_test_binary("init_shell");

        x86_64::instructions::interrupts::without_interrupts(|| {
            use alloc::string::String;
            match process::creation::create_user_process(String::from("init_shell"), &elf) {
                Ok(pid) => {
                    serial_println!("INTERACTIVE: init_shell running as PID {}", pid.as_u64());
                }
                Err(e) => {
                    serial_println!("INTERACTIVE: Failed to create init: {}", e);
                }
            }
        });
    }

    // Dispatch the staged boot-test registry (#533).
    //
    // This is the last point in the x86 boot where the registry CAN be
    // dispatched: `run_staged_tests` spawns one kthread per subsystem and
    // `kthread_join`s them, so it needs preemption enabled, and the boot thread
    // has to still be running. Both stop being true a few lines below - the
    // `preempt_disable()` immediately after this takes the scheduling brake, and
    // the boot thread then strands inside the disk-backed `get_test_binary()`
    // busy-wait in `test_exec::test_direct_execution()` and never returns.
    //
    // The historical call site sat next to `preempt_enable()` several hundred
    // lines further down, past both of those. It was therefore unreachable, and
    // #533's symptom was exactly that: an x86 boot emitted no
    // `[BOOT_TESTS:START]` and no per-test markers at all, and the only
    // completion output was the marker-only `[TESTS_COMPLETE:0/0]` +
    // `[BOOT_TESTS:PASS]` pair that the first Ring 3 syscall prints. Measured on
    // main @ 54aa16a1: the whole serial contained three registry markers, all
    // from that vacuous path.
    // Off by default until the strand below is fixed. Turning the feature on is
    // how the two blocking defects are reproduced; leaving it off keeps the
    // shipped x86 boot identical to what it was before this work.
    #[cfg(all(feature = "boot_tests", feature = "x86_staged_registry"))]
    {
        log::info!("[boot] Running parallel boot tests...");
        #[cfg(feature = "btrt")]
        kernel::test_framework::btrt::pass(kernel::test_framework::catalog::BOOT_TESTS_START);

        // The executor's `kthread_join` waits with `hlt`, so the timer has to be
        // able to fire or the boot thread halts forever with the test kthread
        // sitting runnable behind it. That is not hypothetical: every
        // `kernel::task::kthread_tests::*` case run immediately above this ends
        // with `arch_disable_interrupts()`, so control arrives here with IF
        // clear, and the first dispatched subsystem thread hung the boot
        // permanently after `[STAGE:serial:ADVANCE]`.
        //
        // Enable interrupts for the dispatch and put the flag back the way it
        // was found. Restoring rather than leaving them on keeps this block from
        // changing the interrupt state the rest of the boot sequence inherits.
        let interrupts_were_enabled = x86_64::instructions::interrupts::are_enabled();
        if !interrupts_were_enabled {
            x86_64::instructions::interrupts::enable();
        }

        let mut failures = test_framework::run_all_tests();

        // ProcessContext is the last stage with registered x86 tests, and this
        // is the only x86 context that can dispatch it: the stage's tests need
        // preemption (they run in a joined kthread like every other stage), and
        // the boot thread has none left after the `preempt_disable()` below.
        // Its precondition holds here - `kernel_main_on_kernel_stack` has
        // already created and retired user processes by this point, so the
        // process manager is populated and the boot thread is a live scheduler
        // thread. The Userspace stage stays marker-only on both architectures:
        // it is reached from syscall context, where #533 itself says not to run
        // blocking staged tests.
        failures += test_framework::advance_to_stage(test_framework::TestStage::ProcessContext);

        if !interrupts_were_enabled {
            x86_64::instructions::interrupts::disable();
        }

        if failures > 0 {
            log::error!("[boot] {} test(s) failed!", failures);
        } else {
            log::info!("[boot] All boot tests passed!");
        }
        #[cfg(feature = "btrt")]
        kernel::test_framework::btrt::pass(kernel::test_framework::catalog::BOOT_TESTS_COMPLETE);
    }

    // Take the boot sequence's scheduling brake.
    //
    // This call is UNCONDITIONAL and must stay that way. The matching
    // preempt_enable() several hundred lines below is unconditional too, and
    // the two are one protocol: they compile together or not at all. #672 was
    // the asymmetry - the disable used to sit inside the
    // `#[cfg(all(feature = "testing", not(feature = "interactive")))]` block
    // immediately below, so every shipped (zero-feature) boot and every
    // `interactive` boot decremented a preempt_count that had never been
    // incremented. The x86 HAL decrement is a bare `sub` on a u32, so the count
    // wrapped to 0xFFFFFFFF and clean preemptive scheduling stayed off for the
    // rest of that CPU's uptime. Whatever cfg the release below carries, this
    // call must carry the identical one; tests/preempt_bracket_structure.rs
    // pins that symmetry and per_cpu::preempt_enable() now refuses (and counts)
    // a decrement below zero rather than wrapping.
    //
    // preempt_disable() is the brake here, not interrupts::disable(), because
    // the disk-backed test binaries loaded in the block below need VirtIO block
    // IRQ completions: interrupts stay hardware-enabled and preempt_count gates
    // scheduling instead. PRECONDITION 7 further below checks that real
    // invariant. NOTE: real boot testing shows the timer interrupt can still
    // switch away from the boot thread during the busy-spin disk-completion
    // wait in this window (a pre-existing gap between preempt_count and this
    // kernel's actual can_schedule() logic, which this change neither
    // introduces nor closes - see the PR that added this comment for the
    // investigation notes and the recommended follow-up RCA).
    kernel::per_cpu::preempt_disable();

    // RING3_SMOKE: Create userspace process early for CI validation
    // Must be done before int3() which might hang in CI
    //
    // NOTE: The canonical list of test binaries is in boot::test_list::TEST_BINARIES.
    // The x86_64 loading pattern below uses individual blocks with per-block
    // without_interrupts for architectural reasons and is intentionally not
    // refactored to iterate the shared list. See boot/test_list.rs for details.
    #[cfg(all(feature = "testing", not(feature = "interactive")))]
    {
        // Disk-backed test binaries require VirtIO block IRQ completions, so
        // interrupts must be hardware-enabled here and must STAY enabled for
        // the rest of this boot-time test-registration phase: every
        // get_test_binary() call in the dozens of test_exec::test_*()
        // functions invoked later in this function also loads from disk and
        // needs the same IRQ completion (confirmed: unconditionally
        // re-disabling interrupts here causes those later calls to panic
        // with "DISK LOADING FAILED" - the IRQ can never be serviced).
        //
        // The scheduling brake for this whole window is the unconditional
        // preempt_disable() hoisted above this block (see its comment): it is
        // deliberately outside this cfg so that it pairs with the equally
        // unconditional preempt_enable() near the end of this function.
        // Disk-backed test binaries require VirtIO block IRQ completions.
        x86_64::instructions::interrupts::enable();
        let elf = userspace_test::get_test_binary("hello_time");
        let register_test_buf = kernel::userspace_test::get_test_binary("register_init_test");
        let clock_test_buf = kernel::userspace_test::get_test_binary("clock_gettime_test");
        let brk_test_buf = kernel::userspace_test::get_test_binary("brk_test");
        let test_mmap_buf = kernel::userspace_test::get_test_binary("test_mmap");
        let diagnostic_test_buf =
            kernel::userspace_test::get_test_binary("syscall_diagnostic_test");
        let udp_test_buf = kernel::userspace_test::get_test_binary("udp_socket_test");
        let tcp_test_buf = kernel::userspace_test::get_test_binary("tcp_socket_test");
        let tcp_dup_listener_test_buf =
            kernel::userspace_test::get_test_binary("tcp_dup_listener_test");
        let tcp_cloexec_exec_test_buf =
            kernel::userspace_test::get_test_binary("tcp_cloexec_exec_test");
        let dns_test_buf = kernel::userspace_test::get_test_binary("dns_test");
        let http_test_buf = kernel::userspace_test::get_test_binary("http_test");
        let loopback_wake_test_buf = kernel::userspace_test::get_test_binary("loopback_wake_test");
        let clonevm_exec_test_buf = kernel::userspace_test::get_test_binary("clonevm_exec_test");
        let futex_handoff_oracle_buf =
            kernel::userspace_test::get_test_binary("futex_handoff_oracle");
        // #737 direction-flag preempt oracle. Fork-free on purpose: the gate's
        // PRODUCTION_REAPED_ROWS census counts fork() call sites per roster
        // program (docker/qemu/run-x86-boot-tests.sh), and this program has no
        // such call site, so it contributes 0 there and moves only
        // EXPECTED_USERSPACE_EXITS.
        // claim-lint:ok: 0 of 0 fork() call sites in
        // userspace/programs/src/df_preempt_oracle.rs under the gate's own
        // census pattern, measured in the round that added this launch. #737.
        let df_preempt_oracle_buf = kernel::userspace_test::get_test_binary("df_preempt_oracle");

        x86_64::instructions::interrupts::without_interrupts(|| {
            use alloc::string::String;
            log::info!("RING3_SMOKE: creating hello_time userspace process (early)");
            match process::creation::create_user_process(String::from("smoke_hello_time"), &elf) {
                Ok(pid) => {
                    log::info!(
                        "RING3_SMOKE: created userspace PID {} (will run on timer interrupts)",
                        pid.as_u64()
                    );
                }
                Err(e) => {
                    log::error!("RING3_SMOKE: failed to create userspace process: {}", e);
                }
            }

            // Launch register_init_test to verify registers are properly initialized
            {
                serial_println!("RING3_SMOKE: creating register_init_test userspace process");
                match process::creation::create_user_process(
                    String::from("register_init_test"),
                    &register_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created register_init_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create register_init_test process: {}", e);
                    }
                }
            }

            // Launch clock_gettime_test after hello_time
            {
                serial_println!("RING3_SMOKE: creating clock_gettime_test userspace process");
                match process::creation::create_user_process(
                    String::from("clock_gettime_test"),
                    &clock_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created clock_gettime_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create clock_gettime_test process: {}", e);
                    }
                }
            }

            // Launch brk_test to validate heap management syscall
            {
                serial_println!("RING3_SMOKE: creating brk_test userspace process");
                match process::creation::create_user_process(
                    String::from("brk_test"),
                    &brk_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created brk_test process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create brk_test process: {}", e);
                    }
                }
            }

            // Launch test_mmap to validate mmap/munmap syscalls
            {
                serial_println!("RING3_SMOKE: creating test_mmap userspace process");
                match process::creation::create_user_process(
                    String::from("test_mmap"),
                    &test_mmap_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created test_mmap process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create test_mmap process: {}", e);
                    }
                }
            }

            // Launch syscall_diagnostic_test to isolate register corruption bug
            {
                serial_println!("RING3_SMOKE: creating syscall_diagnostic_test userspace process");
                match process::creation::create_user_process(
                    String::from("syscall_diagnostic_test"),
                    &diagnostic_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created syscall_diagnostic_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create syscall_diagnostic_test process: {}", e);
                    }
                }
            }

            // Launch UDP socket test to verify network syscalls from userspace
            {
                serial_println!("RING3_SMOKE: creating udp_socket_test userspace process");
                match process::creation::create_user_process(
                    String::from("udp_socket_test"),
                    &udp_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created udp_socket_test process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create udp_socket_test process: {}", e);
                    }
                }
            }

            // Launch TCP socket test to verify TCP syscalls from userspace
            {
                serial_println!("RING3_SMOKE: creating tcp_socket_test userspace process");
                match process::creation::create_user_process(
                    String::from("tcp_socket_test"),
                    &tcp_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created tcp_socket_test process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create tcp_socket_test process: {}", e);
                    }
                }
            }

            // Launch TCP dup'd-listener test (regression for #724 review
            // finding M1: dup()/dup2() never incremented a TcpListener's
            // ref_count, so sys_close()'s new decrement could retire a
            // listener out from under a surviving dup'd fd).
            {
                serial_println!("RING3_SMOKE: creating tcp_dup_listener_test userspace process");
                match process::creation::create_user_process(
                    String::from("tcp_dup_listener_test"),
                    &tcp_dup_listener_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created tcp_dup_listener_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create tcp_dup_listener_test process: {}", e);
                    }
                }
            }

            // Launch TCP FD_CLOEXEC exec() survival test (regression for #707:
            // close_cloexec() -- the path exec() uses to retire FD_CLOEXEC-marked
            // fds -- had no arm for FdKind::TcpListener, so a listener fd marked
            // FD_CLOEXEC leaked a reference across exec() instead of being
            // retired via tcp_listener_ref_dec()).
            {
                serial_println!("RING3_SMOKE: creating tcp_cloexec_exec_test userspace process");
                match process::creation::create_user_process(
                    String::from("tcp_cloexec_exec_test"),
                    &tcp_cloexec_exec_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created tcp_cloexec_exec_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create tcp_cloexec_exec_test process: {}", e);
                    }
                }
            }

            // Launch DNS test to verify DNS resolution using UDP sockets
            {
                serial_println!("RING3_SMOKE: creating dns_test userspace process");
                match process::creation::create_user_process(
                    String::from("dns_test"),
                    &dns_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created dns_test process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create dns_test process: {}", e);
                    }
                }
            }

            // Launch HTTP test to verify HTTP client over TCP+DNS
            {
                serial_println!("RING3_SMOKE: creating http_test userspace process");
                match process::creation::create_user_process(
                    String::from("http_test"),
                    &http_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!("Created http_test process with PID {}", pid.as_u64());
                    }
                    Err(e) => {
                        log::error!("Failed to create http_test process: {}", e);
                    }
                }
            }

            // Launch the userspace 545 regression in the normal userspace phase.
            {
                serial_println!("RING3_SMOKE: creating loopback_wake_test userspace process");
                match process::creation::create_user_process(
                    String::from("loopback_wake_test"),
                    &loopback_wake_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created loopback_wake_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create loopback_wake_test process: {}", e);
                    }
                }
            }

            // The #568 blocking-poll-on-connected-TCP oracle (poll_tcp_oracle)
            // is deliberately NOT launched here. It runs on aarch64, where eight
            // gates pin its marker and its verdict, and it is green there. On x86
            // it is not gate-compatible yet: it fork()s a peer per retry attempt,
            // so it shifts the tombstone census this file's own boot gate pins
            // (CENSUS_REMOVED = 6 + attempts, exact on 30/30 boots), and its
            // late_lost_wake verdict carries neither the peer's exit status nor
            // its token_ms/write_ms stamps, so a red cannot be told apart from
            // TCG starvation. Re-wiring it here, together with the marker
            // assertion removed from docker/qemu/run-boot-parallel.sh, is
            // tracked by #697. The #568 kernel fix itself is proven on x86
            // without the oracle, by the strand census in the A/B battery.
            //
            // #693's x86 batteries DID need it launched, so they ran on bytes
            // carrying an investigation patch that adds this launch site back,
            // committed as an apply/revert pair next to the drivers
            // (docs/planning/green-program/sockets/serials/693-fix/
            // x86-launch-site-apply.sh and -revert.sh). That patch is NOT in
            // the branch's bytes, because with it applied this file's own x86
            // boot gate cannot satisfy the census assertion at
            // docker/qemu/run-x86-boot-tests.sh:548: the oracle's stage-3 and
            // stage-4 ladders each fork at least 1 peer, so CENSUS_REMOVED is
            // at least 8 against a pin of 6, and the 1 gate boot the round-2
            // review ran at eba15887 reaped 5 peers. That is #697's scope.

            {
                serial_println!("RING3_SMOKE: creating clonevm_exec_test userspace process");
                match process::creation::create_user_process(
                    String::from("clonevm_exec_test"),
                    &clonevm_exec_test_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created clonevm_exec_test process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create clonevm_exec_test process: {}", e);
                    }
                }
            }

            {
                serial_println!("RING3_SMOKE: creating futex_handoff_oracle userspace process");
                match process::creation::create_user_process(
                    String::from("futex_handoff_oracle"),
                    &futex_handoff_oracle_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created futex_handoff_oracle process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create futex_handoff_oracle process: {}", e);
                    }
                }
            }

            // The 737 direction-flag preempt oracle: it holds DF=1 across many
            // timer ticks so the first from-userspace preempt lands inside the
            // window, instead of waiting for the timer to hit a userspace
            // memmove backward arm. Fork-free, so the gate's
            // PRODUCTION_REAPED_ROWS census (which counts fork call sites per
            // roster program) is unmoved; it moves EXPECTED_USERSPACE_EXITS by 1.
            {
                serial_println!("RING3_SMOKE: creating df_preempt_oracle userspace process");
                match process::creation::create_user_process(
                    String::from("df_preempt_oracle"),
                    &df_preempt_oracle_buf,
                ) {
                    Ok(pid) => {
                        log::info!(
                            "Created df_preempt_oracle process with PID {}",
                            pid.as_u64()
                        );
                    }
                    Err(e) => {
                        log::error!("Failed to create df_preempt_oracle process: {}", e);
                    }
                }
            }
        });
    }

    // PRODUCTION INIT: Load /sbin/init from the mounted ext2 root and hand it
    // to the scheduler as PID 1 (#673).
    //
    // This is the exact complement of the two blocks above: it runs only in
    // the shipped, zero-feature x86_64 build (neither `testing` nor
    // `interactive`). Before this block existed, that build constructed zero
    // userspace processes -- PRECONDITION 5 further down
    // ("Scheduler has runnable threads") failed on every production boot.
    //
    // It reuses the exact arch-neutral ProcessManager transaction aarch64's
    // `launch_init_from_elf()` (main_aarch64.rs) drives -- create_init_process
    // -> designate_init -> publish_init, all in process/manager.rs with no
    // target_arch cfg on the designate/publish steps -- and swaps aarch64's
    // manual ERET terminal step for `task::scheduler::spawn()`, the ordinary
    // x86_64 dispatch entry point every other process on this arch already
    // uses (see `process::creation::create_user_process`, called by both
    // sibling blocks above). `publish_init()`'s own doc comment anticipates
    // exactly this split: "aarch64 hands it to scheduler::spawn_as_current;
    // x86 rows run off the ready queue" -- the concrete missing call was
    // `task::scheduler::spawn()`, per #673's RCA.
    //
    // Interrupt/lock discipline mirrors the testing/interactive blocks above:
    // interrupts must be hardware-enabled for the disk-backed ext2 read (IRQ-
    // driven VirtIO block completions), then the ProcessManager transaction
    // runs inside a without_interrupts() window -- the SAME shape those two
    // blocks wrap their own create_user_process() calls in, not a property of
    // create_user_process() itself: creation.rs's own comment says the
    // opposite, explicitly declining to mask interrupts around process
    // creation to avoid a MEMORY_INFO lock-order deadlock with concurrent
    // frame allocation elsewhere. This call site (and the interactive/testing
    // ones beside it) can mask safely for a different reason: at this point
    // in boot there is exactly one CPU and no second thread alive yet to
    // contend for that lock, so there is nothing to deadlock against.
    // `spawn()` wraps itself in without_interrupts() internally too, so
    // nesting it inside the outer without_interrupts() here is redundant but
    // harmless (it just re-saves/restores already-disabled flags).
    //
    // `interrupts::enable()` below is new boot-order for the shipped profile
    // (#673 review, m1): before this fix, production's first hardware
    // interrupt-enable was several hundred lines later, immediately before
    // the executor starts. Every PRECONDITION check, `int3`, and the
    // timer/clock_gettime tests between here and there now run with
    // interrupts genuinely enabled for the first time in production
    // (matching what the `testing` profile has always done) -- this is what
    // surfaced time_test.rs's TOCTOU. The enable is unconditional: it also
    // runs on the ext2-read-failure path below, which only skips
    // constructing init, not this interrupt-state change.
    //
    // `disable_x86_prod_init` is a #673 anti-vacuity knob only: building with
    // it (and neither `testing` nor `interactive`) compiles this init-launch
    // block back out. It is NOT byte-for-byte the pre-#673 kernel -- the
    // rest of this branch's fixes (the scheduler blocked-state fix, the
    // timer TOCTOU fix, the console-executor kthread) stay in place. It only
    // reproduces the one property the gate's anti-vacuity leg needs to
    // discriminate: a kernel that never constructs a userspace process. It
    // is not meant to ship enabled.
    //
    // The scheduling brake taken immediately below is intentionally NOT
    // inside `launch_x86_production_init()` (#673 review, B3): it is taken
    // here, unconditionally, before even the ext2 read that can fail, and
    // released unconditionally at the single matching site further down
    // (search for its own comment) -- so the bracket is dynamically paired
    // on every path through this block, including both arms of the `match`
    // below, rather than depending on every fallible step inside
    // `launch_x86_production_init()` succeeding before the brake is taken.
    // Boot's own identity is the scheduler's idle thread (main.rs,
    // init_with_current(), "the boot thread becomes the idle task"); once
    // ANY thread reaches Ring 3, syscall::handler::is_ring3_confirmed()
    // latches true and context_switch.rs permanently stops restoring idle's
    // saved boot context, jumping to the generic idle_loop() instead every
    // time idle is next selected (its own comment: "Idle's saved context
    // from boot may contain RIP values in kernel init code that cause
    // hangs"). That is correct and necessary in general, but it means init
    // cannot be allowed to run until every remaining line of boot's own
    // PRECONDITION-checking, timer, and census work is done -- once init
    // makes its own first syscall, boot's chance to resume here is gone
    // for good, unconditionally, by design. This brake is what keeps that
    // from happening prematurely; the matching release (and what replaces
    // it once it lifts) is at the site named above.
    #[cfg(not(any(
        feature = "testing",
        feature = "interactive",
        feature = "disable_x86_prod_init"
    )))]
    {
        kernel::per_cpu::preempt_disable();

        x86_64::instructions::interrupts::enable();

        match kernel::boot::init_image::read_init_from_ext2("/sbin/init") {
            Ok(elf_data) => {
                x86_64::instructions::interrupts::without_interrupts(|| {
                    if let Err(e) = launch_x86_production_init(&elf_data) {
                        log::error!("PRODUCTION INIT: failed to launch init: {}", e);
                    }
                });
            }
            Err(e) => {
                log::error!(
                    "PRODUCTION INIT: failed to read /sbin/init from ext2: {}",
                    e
                );
            }
        }
    }

    // Test timer functionality immediately
    // TEMPORARILY DISABLED - these tests delay userspace execution
    // time_test::test_timer_directly();
    // rtc_test::test_rtc_and_real_time();
    // clock_gettime_test::test_clock_gettime();

    // Test if interrupts are working by triggering a breakpoint
    log::info!("Testing breakpoint interrupt...");
    x86_64::instructions::interrupts::int3();
    log::info!("Breakpoint test completed!");

    // Run user-only fault tests after initial Ring 3 validation
    // TEMPORARILY DISABLED: fault_tester thread calls yield_current() in a loop,
    // which prevents user threads from getting their FIRST RUN setup via interrupt return.
    // TODO: Fix yield_current() to properly use interrupt-based context switching.
    /*
    #[cfg(feature = "testing")]
    {
        // Create a kernel thread to run fault tests after a delay
        use alloc::boxed::Box;
        use alloc::string::String;

        match task::thread::Thread::new_kernel(
            String::from("fault_tester"),
            fault_test_thread,
            0,
        ) {
            Ok(thread) => {
                task::scheduler::spawn(Box::new(thread));
                log::info!("Spawned fault test thread (delayed execution)");
            }
            Err(e) => {
                log::error!("Failed to create fault test thread: {}", e);
            }
        }
    }
    */

    test_checkpoint!("POST_COMPLETE");

    log::info!("DEBUG: About to print POST marker (before enabling interrupts)");

    // Run tests BEFORE enabling interrupts - they will create userspace processes
    // which will then run when the scheduler activates after interrupt enable
    #[cfg(all(feature = "testing", not(feature = "interactive")))]
    {
        log::info!("=== Running kernel tests to create userspace processes ===");

        // Run all tests - fork/CoW page table lifecycle bug fixed
        log::info!("=== BASELINE TEST: Direct userspace execution ===");
        test_exec::test_direct_execution();
        log::info!("Direct execution test: process scheduled for execution.");

        // Test fork from userspace
        log::info!("=== USERSPACE TEST: Fork syscall from Ring 3 ===");
        test_exec::test_userspace_fork();
        log::info!("Fork test: process scheduled for execution.");

        // Test ENOSYS syscall
        log::info!("=== SYSCALL TEST: Undefined syscall returns ENOSYS ===");
        test_exec::test_syscall_enosys();
        log::info!("ENOSYS test: process scheduled for execution.");

        // Test signal handler execution
        log::info!("=== SIGNAL TEST: Signal handler execution ===");
        test_exec::test_signal_handler();
        log::info!("Signal handler test: process scheduled for execution.");

        // Test signal handler return via trampoline
        log::info!("=== SIGNAL TEST: Signal handler return via trampoline ===");
        test_exec::test_signal_return();
        log::info!("Signal return test: process scheduled for execution.");

        // Test signal register preservation
        log::info!("=== SIGNAL TEST: Register preservation across signals ===");
        test_exec::test_signal_regs();

        // Test pipe IPC syscalls
        log::info!("=== IPC TEST: Pipe syscall functionality ===");
        test_exec::test_pipe();

        // Test Unix domain socket (AF_UNIX) - socketpair AND bind/listen/accept/connect
        log::info!("=== IPC TEST: Unix domain socket (socketpair + named sockets) ===");
        test_exec::test_unix_socket();

        // Test FIFO (named pipe) functionality
        log::info!("=== IPC TEST: FIFO (named pipe) functionality ===");
        test_exec::test_fifo();

        // Test SIGTERM delivery with default handler (kill test)
        log::info!("=== SIGNAL TEST: SIGTERM delivery with default handler ===");
        test_exec::test_signal_kill();

        // Test SIGCHLD delivery when child exits
        log::info!("=== SIGNAL TEST: SIGCHLD delivery on child exit ===");
        test_exec::test_sigchld();

        // Test pause() syscall
        log::info!("=== SIGNAL TEST: pause() syscall functionality ===");
        test_exec::test_pause();

        // Test process group kill semantics
        log::info!("=== SIGNAL TEST: process group kill semantics ===");
        test_exec::test_kill_process_group();

        // Test sigsuspend() syscall
        log::info!("=== SIGNAL TEST: sigsuspend() syscall functionality ===");
        test_exec::test_sigsuspend();

        // Test sigaltstack() syscall
        log::info!("=== SIGNAL TEST: sigaltstack() syscall functionality ===");
        test_exec::test_sigaltstack();

        // Test dup() syscall
        log::info!("=== IPC TEST: dup() syscall functionality ===");
        test_exec::test_dup();

        // Test fcntl() syscall
        log::info!("=== IPC TEST: fcntl() syscall functionality ===");
        test_exec::test_fcntl();

        // Test close-on-exec (O_CLOEXEC) behavior
        log::info!("=== IPC TEST: close-on-exec (O_CLOEXEC) behavior ===");
        test_exec::test_cloexec();

        // Test pipe2() syscall
        log::info!("=== IPC TEST: pipe2() syscall functionality ===");
        test_exec::test_pipe2();

        // Test poll() syscall
        log::info!("=== IPC TEST: poll() syscall functionality ===");
        test_exec::test_poll();

        // Test select() syscall
        log::info!("=== IPC TEST: select() syscall functionality ===");
        test_exec::test_select();

        // Test O_NONBLOCK pipe behavior
        log::info!("=== IPC TEST: O_NONBLOCK pipe behavior ===");
        test_exec::test_nonblock();

        // Test TTY layer functionality
        log::info!("=== TTY TEST: TTY layer functionality ===");
        test_exec::test_tty();

        // Test session and process group syscalls
        log::info!("=== SESSION TEST: Session and process group syscalls ===");
        test_exec::test_session();

        // Test ext2 file read functionality
        log::info!("=== FS TEST: ext2 file read functionality ===");
        test_exec::test_file_read();

        // Test Ctrl-C (SIGINT) signal delivery
        log::info!("=== SIGNAL TEST: Ctrl-C (SIGINT) signal delivery ===");
        test_exec::test_ctrl_c();

        // Test fork memory isolation (CoW semantics)
        log::info!("=== FORK TEST: Fork memory isolation (CoW semantics) ===");
        test_exec::test_fork_memory();

        // Test fork state copying (copy_process_state)
        log::info!("=== FORK TEST: Fork state copying (FD, signals, pgid, sid) ===");
        test_exec::test_fork_state();

        // Test fork pending signal non-inheritance (POSIX)
        log::info!("=== SIGNAL TEST: fork pending signal non-inheritance ===");
        test_exec::test_fork_pending_signal();

        // Test CoW signal delivery (deadlock fix)
        log::info!("=== COW TEST: signal delivery on CoW-shared stack ===");
        test_exec::test_cow_signal();

        // Test CoW cleanup on process exit
        log::info!("=== COW TEST: cleanup on process exit ===");
        test_exec::test_cow_cleanup();

        // Test CoW sole owner optimization
        log::info!("=== COW TEST: sole owner optimization ===");
        test_exec::test_cow_sole_owner();

        // Test CoW at scale with many pages
        log::info!("=== COW TEST: stress test with many pages ===");
        test_exec::test_cow_stress();

        // Test CoW read-only page sharing (code sections)
        log::info!("=== COW TEST: read-only page sharing (code sections) ===");
        test_exec::test_cow_readonly();

        // Test argv support in exec syscall
        log::info!("=== EXEC TEST: argv support ===");
        test_exec::test_argv();
        log::info!("=== EXEC TEST: exec with argv ===");
        test_exec::test_exec_argv();
        log::info!("=== EXEC TEST: exec with stack-allocated argv ===");
        test_exec::test_exec_stack_argv();

        // Test getdents64 syscall for directory listing
        log::info!("=== FS TEST: getdents64 directory listing ===");
        test_exec::test_getdents();

        // Test lseek syscall
        log::info!("=== FS TEST: lseek syscall ===");
        test_exec::test_lseek();

        // Test filesystem write operations
        log::info!("=== FS TEST: filesystem write operations ===");
        test_exec::test_fs_write();

        // Test filesystem rename operations
        log::info!("=== FS TEST: filesystem rename operations ===");
        test_exec::test_fs_rename();

        // Test large file operations (indirect blocks)
        log::info!("=== FS TEST: large file operations ===");
        test_exec::test_fs_large_file();

        // Test filesystem directory operations
        log::info!("=== FS TEST: directory operations ===");
        test_exec::test_fs_directory();

        // Test filesystem link operations
        log::info!("=== FS TEST: link operations ===");
        test_exec::test_fs_link();

        // Test access() syscall
        log::info!("=== FS TEST: access() syscall ===");
        test_exec::test_access();

        // Test devfs device files (/dev/null, /dev/zero, /dev/console, /dev/tty)
        log::info!("=== FS TEST: devfs device files ===");
        test_exec::test_devfs();

        // Test current working directory syscalls (getcwd, chdir)
        log::info!("=== FS TEST: cwd syscalls (getcwd, chdir) ===");
        test_exec::test_cwd();

        // Test exec from ext2 filesystem
        log::info!("=== FS TEST: exec from ext2 filesystem ===");
        test_exec::test_exec_from_ext2();

        // Test filesystem block allocation (regression test for truncate/alloc bugs)
        log::info!("=== FS TEST: block allocation regression test ===");
        test_exec::test_fs_block_alloc();

        // Coreutil tests
        log::info!("=== COREUTIL TEST: true (exit code 0) ===");
        test_exec::test_true_coreutil();
        log::info!("=== COREUTIL TEST: false (exit code 1) ===");
        test_exec::test_false_coreutil();
        log::info!("=== COREUTIL TEST: head (first N lines) ===");
        test_exec::test_head_coreutil();
        log::info!("=== COREUTIL TEST: tail (last N lines) ===");
        test_exec::test_tail_coreutil();
        log::info!("=== COREUTIL TEST: wc (line/word/byte counts) ===");
        test_exec::test_wc_coreutil();
        log::info!("=== COREUTIL TEST: which (command location) ===");
        test_exec::test_which_coreutil();
        log::info!("=== COREUTIL TEST: cat (file concatenation) ===");
        test_exec::test_cat_coreutil();
        log::info!("=== COREUTIL TEST: ls (directory listing) ===");
        test_exec::test_ls_coreutil();

        // Test Rust std library support
        log::info!("=== STD TEST: Rust std library support ===");
        test_exec::test_hello_std_real();

        // Test signal handler reset on exec
        log::info!("=== SIGNAL TEST: Signal handler reset on exec ===");
        test_exec::test_signal_exec();

        // Test waitpid syscall
        log::info!("=== IPC TEST: Waitpid syscall functionality ===");
        test_exec::test_waitpid();

        // Test signal fork inheritance
        log::info!("=== SIGNAL TEST: Signal handler fork inheritance ===");
        test_exec::test_signal_fork();

        // Test WNOHANG timing behavior
        log::info!("=== IPC TEST: WNOHANG timing behavior ===");
        test_exec::test_wnohang_timing();

        // Test shell pipeline execution (pipe+fork+dup2 pattern)
        log::info!("=== IPC TEST: Shell pipeline execution ===");
        test_exec::test_shell_pipe();

        // Test FbInfo syscall (framebuffer information)
        log::info!("=== GRAPHICS TEST: FbInfo syscall ===");
        test_exec::test_fbinfo();
    }

    // NOTE: Premature success markers removed - tests must verify actual execution
    // The legitimate markers are printed from context_switch.rs when Ring 3 actually runs

    // CHECKPOINT B: Verify Scheduler State
    // Verify scheduler has runnable threads before enabling interrupts
    let _scheduler_state = task::scheduler::with_scheduler(|s| {
        let has_runnable = s.has_runnable_threads();
        let has_user = s.has_userspace_threads();
        log::info!(
            "CHECKPOINT B: scheduler has_runnable_threads = {}",
            has_runnable
        );
        log::info!("CHECKPOINT B: has_userspace_threads = {}", has_user);
        (has_runnable, has_user)
    });

    // ========================================================================
    // PRECONDITION VALIDATION: Check ALL preconditions before enabling interrupts
    // ========================================================================
    log::info!("==================== PRECONDITION VALIDATION ====================");

    // PRECONDITION 1: IDT Configured
    log::info!("PRECONDITION 1: Checking IDT timer entry configuration...");
    let (idt_valid, handler_addr, idt_desc) = interrupts::validate_timer_idt_entry();
    if idt_valid {
        log::info!("PRECONDITION 1: IDT timer entry ✓ PASS");
        log::info!("  Handler address: {:#x}", handler_addr);
        log::info!("  Status: {}", idt_desc);
    } else {
        log::error!("PRECONDITION 1: IDT timer entry ✗ FAIL");
        log::error!("  Handler address: {:#x}", handler_addr);
        log::error!("  Reason: {}", idt_desc);
    }

    // PRECONDITION 2: Timer Interrupt Handler Registered
    log::info!("PRECONDITION 2: Verifying timer handler points to timer_interrupt_entry...");
    // This is part of the same check as PRECONDITION 1
    if idt_valid {
        log::info!("PRECONDITION 2: Timer handler registered ✓ PASS");
        log::info!("  The IDT entry for IRQ0 (vector 32) is properly configured");
    } else {
        log::error!("PRECONDITION 2: Timer handler registered ✗ FAIL");
        log::error!("  IDT entry validation failed (see PRECONDITION 1)");
    }

    // PRECONDITION 3: PIT Hardware Configured
    log::info!("PRECONDITION 3: Checking PIT counter is active...");
    let (pit_counting, count1, count2, pit_desc) = time::timer::validate_pit_counting();
    if pit_counting {
        log::info!("PRECONDITION 3: PIT counter ✓ PASS");
        log::info!("  Counter values: {:#x} -> {:#x}", count1, count2);
        log::info!("  Status: {}", pit_desc);
    } else {
        log::error!("PRECONDITION 3: PIT counter ✗ FAIL");
        log::error!("  Counter values: {:#x} -> {:#x}", count1, count2);
        log::error!("  Reason: {}", pit_desc);
    }

    // PRECONDITION 4: PIC IRQ0 Unmasked
    log::info!("PRECONDITION 4: Checking PIC IRQ0 mask bit...");
    let (irq0_unmasked, mask, pic_desc) = interrupts::validate_pic_irq0_unmasked();
    if irq0_unmasked {
        log::info!("PRECONDITION 4: PIC IRQ0 unmasked ✓ PASS");
        log::info!("  PIC1 mask register: {:#04x}", mask);
        log::info!("  Status: {}", pic_desc);
    } else {
        log::error!("PRECONDITION 4: PIC IRQ0 unmasked ✗ FAIL");
        log::error!("  PIC1 mask register: {:#04x}", mask);
        log::error!("  Reason: {}", pic_desc);
    }

    // PRECONDITION 5: Scheduler Has Runnable Threads
    log::info!("PRECONDITION 5: Checking scheduler has runnable threads...");
    let has_runnable = task::scheduler::with_scheduler(|s| s.has_runnable_threads());
    if let Some(true) = has_runnable {
        log::info!("PRECONDITION 5: Scheduler has runnable threads ✓ PASS");
    } else {
        log::error!("PRECONDITION 5: Scheduler has runnable threads ✗ FAIL");
        log::error!(
            "  No runnable threads in scheduler - timer interrupt will have nothing to schedule!"
        );
    }

    // PRECONDITION 6: Current Thread Set
    log::info!("PRECONDITION 6: Checking current thread is set...");
    let has_current_thread = if let Some(thread) = per_cpu::current_thread() {
        log::info!("PRECONDITION 6: Current thread set ✓ PASS");
        log::info!("  Thread pointer: {:p}", thread);
        log::info!("  Thread ID: {}", thread.id);
        log::info!("  Thread name: {}", thread.name);

        // Validate the thread pointer looks reasonable
        let thread_addr = thread as *const _ as u64;
        if thread_addr > 0x1000 {
            log::info!("  Thread pointer validation: ✓ looks valid");
        } else {
            log::error!("  Thread pointer validation: ✗ looks suspicious (too low)");
        }
        true
    } else {
        log::error!("PRECONDITION 6: Current thread set ✗ FAIL");
        log::error!("  per_cpu::current_thread() returned None!");
        false
    };

    // PRECONDITION 7: Preemption Currently Disabled
    // (Interrupts are intentionally already hardware-enabled by this point -
    // see the preempt_disable()/interrupts::enable() pair in the first
    // RING3_SMOKE block above, needed for disk-backed test binary loads.
    // preempt_count is the real invariant guarding against premature
    // scheduling during this boot-time test-registration phase.)
    log::info!("PRECONDITION 7: Verifying preemption is currently disabled...");
    let preemption_disabled = kernel::per_cpu::preempt_count() > 0;
    if preemption_disabled {
        log::info!("PRECONDITION 7: Preemption disabled ✓ PASS");
        log::info!("  Ready to enable preemption safely");
    } else {
        log::error!("PRECONDITION 7: Preemption disabled ✗ FAIL");
        log::error!("  Preemption is not disabled! This should not happen.");
    }

    log::info!("================================================================");

    // Summary of precondition validation
    let all_passed = idt_valid
        && pit_counting
        && irq0_unmasked
        && has_runnable.unwrap_or(false)
        && has_current_thread
        && preemption_disabled;

    if all_passed {
        log::info!("✓ ALL PRECONDITIONS PASSED - Safe to enable interrupts");
    } else {
        log::error!("✗ SOME PRECONDITIONS FAILED - See details above");
        log::error!("  Enabling interrupts anyway to observe failure behavior...");
    }

    // Test timer resolution. Interrupts are already hardware-enabled by this
    // point in the shipped x86 production profile (#673 review, mi4 --
    // "BEFORE enabling interrupts" was true pre-#673 and is now false here;
    // see the `interrupts::enable()` boot-order comment in the first
    // RING3_SMOKE block above for why, and time_test.rs's own comment for
    // how the test now tolerates a genuine tick landing between its two
    // reads). This validates that get_monotonic_time() correctly converts
    // PIT ticks to milliseconds.
    log::info!("Testing timer resolution...");
    time_test::test_timer_resolution();
    log::info!("✅ Timer resolution test passed");

    // Test our clock_gettime implementation BEFORE enabling preemption.
    // Interrupts are already hardware-enabled at this point (see the first
    // RING3_SMOKE block above); preemption is intended to still be disabled
    // via preempt_disable() called there (see that comment for a known gap:
    // the timer can still switch away during a disk-completion busy-wait).
    log::info!("Testing clock_gettime syscall implementation...");
    clock_gettime_test::test_clock_gettime();
    log::info!("✅ clock_gettime tests passed");

    // The staged boot-test registry used to be dispatched from here. It is now
    // dispatched from the top of kernel_main_continue() instead - see the #533
    // comment there for why this position could never work.

    // Mark kernel initialization complete BEFORE enabling interrupts
    // Once interrupts are enabled, the scheduler will preempt to userspace
    // and kernel_main may never execute again
    log::info!("✅ Kernel initialization complete!");

    // Finalize BTRT: in non-testing mode, finalize now (kernel milestones only).
    // In testing mode, auto-finalize happens via on_process_exit() when all
    // registered test processes have completed.
    #[cfg(all(feature = "btrt", not(feature = "testing")))]
    kernel::test_framework::btrt::finalize();

    // Release the scheduling brake taken in the first RING3_SMOKE block
    // above (see its preempt_disable() comment) - this is the true,
    // intended start of preemption for userspace processes registered
    // since then.
    kernel::per_cpu::preempt_enable();

    // Enable interrupts for preemptive multitasking - userspace processes will now run
    // WARNING: After this call, kernel_main will likely be preempted immediately
    // by the timer interrupt and scheduler. All essential init must be done above.
    log::info!("Enabling interrupts (after creating user processes)...");
    x86_64::instructions::interrupts::enable();
    // NOTE: Code below this point may never execute due to scheduler preemption

    // RING3_SMOKE: Create userspace process early for CI validation
    // Must be done after interrupts are enabled but before other tests
    #[cfg(all(feature = "testing", not(feature = "interactive")))]
    {
        let elf = userspace_test::get_test_binary("hello_time");
        x86_64::instructions::interrupts::without_interrupts(|| {
            use alloc::string::String;
            serial_println!("RING3_SMOKE: creating hello_time userspace process (early)");
            match process::create_user_process(String::from("smoke_hello_time"), &elf) {
                Ok(pid) => {
                    serial_println!(
                        "RING3_SMOKE: created userspace PID {} (will run on timer interrupts)",
                        pid.as_u64()
                    );
                }
                Err(e) => {
                    serial_println!("RING3_SMOKE: failed to create userspace process: {}", e);
                }
            }
        });
    }

    // Keyboard was already initialized earlier (line 225), don't initialize again

    // Wait briefly for processes to run
    for _ in 0..1000000 {
        x86_64::instructions::nop();
    }

    log::info!("Disabling interrupts after scheduler test...");

    // Preempt-bracket census (#672). Unconditional, once per boot, on the way
    // to the executor: a nonzero value means some path called preempt_enable()
    // without a matching preempt_disable(), which per_cpu::preempt_enable()
    // now refuses and counts instead of wrapping preempt_count to 0xFFFFFFFF.
    // Pinned at zero by docker/qemu/run-x86-prod-profile-boot-test.sh.
    log::info!(
        "[PREEMPT_BRACKET_CENSUS:underflow={}]",
        kernel::per_cpu::preempt_underflow_count()
    );

    // Initialize and run the async executor.
    log::info!("Starting async executor...");

    // Non-production profiles drive the console executor directly from the
    // boot thread's own tail, exactly as they always have -- unaffected by
    // the #673 B1 fix below.
    #[cfg(any(
        feature = "testing",
        feature = "interactive",
        feature = "disable_x86_prod_init"
    ))]
    let mut executor = {
        let mut executor = task::executor::Executor::new();
        executor.spawn(task::Task::new(keyboard::keyboard_task()));
        executor.spawn(task::Task::new(serial::command::serial_command_task()));
        executor
    };

    // Release the SECOND, dedicated brake taken above (#673 review, B3) by
    // handing the console its OWN kernel thread instead of ever driving it
    // from the boot thread's own saved context (#673 review, B1).
    //
    // The straightforward version of this -- executor.run() as this
    // function's own tail, exactly like the non-production profiles above --
    // reliably loses the console about a second after init starts. Boot's
    // identity is the scheduler's idle thread (see the comment above this
    // block); once init's first syscall lands, is_ring3_confirmed() latches
    // and context_switch.rs permanently abandons whatever context idle is
    // next preempted from, in favour of its own generic idle_loop(). A
    // one-shot run_ready_tasks() priming pass before that point does not fix
    // this: it advances every task to its first await point, but nothing
    // ever polls the executor again afterward -- Waker::wake() only pushes a
    // task id back onto the executor's own queue, and the ONLY thing that
    // ever drains that queue is Executor::run()'s loop, which just became
    // unreachable code the instant idle's saved context was abandoned.
    // aarch64 never hits this: it has no equivalent call to Executor::run()
    // in its own production path at all -- main_aarch64.rs never constructs
    // an Executor, because its console (bsshd, spawned by init) is a real
    // userspace process, not a kernel-side async task competing with boot
    // for the same saved context.
    //
    // The fix: give the console executor its own ordinary kernel thread
    // (`task::kthread::kthread_run`), spawned here -- before the brake
    // below lifts, so it becomes runnable at the same instant init does,
    // not after. A kthread's context is preserved by the SAME dispatch path
    // every other kernel thread uses (`switch_to_thread()`'s
    // `is_kernel_thread` arm, `setup_kernel_thread_return()`) -- it is never
    // the scheduler's idle thread, so it never falls into the idle-specific
    // "abandon this context" rule above, and it survives being preempted
    // and resumed indefinitely, exactly like any other long-lived kernel
    // thread. Once this exists, the boot thread genuinely has nothing left
    // worth preserving after this point, so it no longer tries: see the
    // plain interrupt-driven halt loop below instead of a second, competing
    // Executor::run() call.
    #[cfg(not(any(
        feature = "testing",
        feature = "interactive",
        feature = "disable_x86_prod_init"
    )))]
    {
        if let Err(e) = task::kthread::kthread_run(
            || {
                // #673 review, R3-B1: census the production bracket's
                // release from HERE, not from boot's own tail after
                // preempt_enable() below (see that call's comment for why
                // boot's own reads are a footrace this profile cannot win).
                // This kthread's context is never abandoned the way
                // boot/idle's is -- it is dispatched and resumed by the
                // ordinary switch_to_thread() is_kernel_thread path for as
                // long as the system runs -- so this line executes exactly
                // once, deterministically, rather than racing the next
                // timer tick.
                //
                // It is also guaranteed to run AFTER the release below:
                // this closure cannot start executing until the scheduler
                // switches the CPU away from boot's currently-running
                // context onto this thread, and per_cpu::can_schedule()
                // (per_cpu.rs -- the `current_preempt == 0` guard ahead of
                // `returning_to_idle_kernel`/`need_resched_set`, OR'd with
                // the separate blocked/terminated admission this thread
                // does not hold here) refuses that switch while ANY
                // preempt_disable() bracket is still held on this CPU.
                // kthread_run() only calls scheduler::spawn() (adds this
                // thread to the ready queue); it never forces an immediate
                // dispatch. So the first instruction of this closure can
                // only run once preempt_count has already dropped to 0 on
                // this CPU -- and the ONLY preempt_enable() call left
                // between here and that point in this profile is the very
                // next line below (this is boot's SECOND, more-nested brake,
                // #673 review B3/B4 -- its release is boot's first
                // preemptible point since that brake was taken, because the
                // outer, unconditional bracket around the whole boot
                // sequence was already released earlier in this function).
                // The underflow counter itself
                // (per_cpu::PREEMPT_UNDERFLOW_COUNT) is a monotonic,
                // never-reset AtomicU64 (fetch_add on underflow only, no
                // corresponding decrement anywhere), so reading it here
                // still observes an underflow caused by that release even
                // though this read happens strictly after it. Pinned by
                // docker/qemu/run-x86-prod-profile-boot-test.sh.
                log::info!(
                    "[PROD_BRACKET_RELEASE_CENSUS:underflow={}]",
                    kernel::per_cpu::preempt_underflow_count()
                );

                let mut executor = task::executor::Executor::new();
                executor.spawn(task::Task::new(keyboard::keyboard_task()));
                executor.spawn(task::Task::new(serial::command::serial_command_task()));
                executor.run()
            },
            "console_executor",
        ) {
            log::error!(
                "PRODUCTION INIT: failed to start console executor kthread: {:?}",
                e
            );
        }

        kernel::per_cpu::preempt_enable();

        // #673 review, R3-B1: the census that used to sit here
        // ([PROD_BRACKET_RELEASE_CENSUS:...]) was a designed footrace and
        // has been MOVED to the top of the console_executor kthread's
        // closure above (search for "R3-B1" there for the full
        // derivation).
        //
        // Why it raced here: this profile's whole design (#712) is that
        // boot IS the scheduler's idle thread from init_with_current()
        // onward, and once any thread reaches Ring 3,
        // is_ring3_confirmed() latches and context_switch.rs permanently
        // abandons whatever context idle is next preempted from -- boot
        // never resumes its own saved context again. A formatted
        // log::info!() call is not atomic with the preempt_enable() call
        // above it: between the two, this CPU is preemptible (preempt_count
        // is already 0) and the very next 1 kHz timer tick can switch away
        // from boot before it reaches the log call, permanently stranding
        // it unexecuted (measured: 1/6 shipping-profile boots at the #673
        // fix-round-3 review). The release itself was never affected by
        // this -- preempt_enable() above always completes -- only the
        // diagnostic line describing it could be lost. See #712 for the
        // full mechanism and the corrected account (this is boot's tail
        // being dropped after a correct release, not a stranded brake).

        // Boot's own sequential work is done, and its future role really is
        // the scheduler's generic idle one from here on: init and the
        // console-executor kthread are both dispatchable threads with their
        // own preserved contexts now, and this thread contributes nothing
        // else. A plain interrupt-driven halt loop is deliberately all this
        // needs -- unlike the pre-fix design above, nothing here owns state
        // that must survive being resumed at context_switch.rs's own
        // idle_loop() instead of wherever this loop happened to be halted.
        loop {
            x86_64::instructions::interrupts::enable_and_hlt();
        }
    }

    // Don't run tests automatically - let the user trigger them manually
    #[cfg(feature = "testing")]
    {
        log::info!("Testing features enabled. Press keys to test:");
        log::info!("  Ctrl+P - Test multiple concurrent processes");
        log::info!("  Ctrl+U - Run single userspace test");
        log::info!("  Ctrl+F - Test fork() system call");
        log::info!("  Ctrl+E - Test exec() system call");
        log::info!("  Ctrl+T - Show time debug info");
        log::info!("  Ctrl+M - Show memory debug info");
    }

    #[cfg(any(
        feature = "testing",
        feature = "interactive",
        feature = "disable_x86_prod_init"
    ))]
    executor.run()
}

/// The idle task's stored entry point. THIS BODY IS NEVER DISPATCHED on x86.
/// claim-lint:ok: #775 round 3 finding N1 measured this; the boot-level
/// evidence is in
/// docs/planning/green-program/sockets/775-CENSUS-EQUIVALENCE-2026-09-04.md
///
/// `kernel_main_continue` builds `init_task` with this as its entry point and
/// then immediately marks it Running on the boot context (see the
/// `Thread::new(... idle_thread_fn ...)` / `ThreadState::Running` pair above),
/// so the scheduler never enters it. After any thread reaches Ring 3,
/// `is_ring3_confirmed()` latches and `context_switch.rs` abandons idle's saved
/// context and rewrites the frame to its own `idle_loop()`, which is where every
/// idle dispatch resumes from then on (main.rs:1636 and :2221 state the same
/// design).
/// claim-lint:ok: the three in-tree statements of the same design are
/// main.rs:1636, main.rs:2221 and context_switch.rs setup_idle_return.
///
/// #775 round 3 (finding N1): the census heartbeat used to be called from here
/// and therefore never ran. It now lives in `context_switch.rs::idle_loop()`.
/// `drain_loopback_from_idle()` below is dead for the same reason; #775 leaves
/// it alone because moving it changes loopback behaviour and is unrelated to the
/// census. The equivalence document records that.
/// claim-lint:ok: #775 ruling R134 item 1 fixes the live idle site.
#[cfg(target_arch = "x86_64")]
fn idle_thread_fn() {
    loop {
        // Enable interrupts and halt until next interrupt
        x86_64::instructions::interrupts::enable_and_hlt();

        crate::net::drain_loopback_from_idle();

        // Check if there are any ready threads
        if let Some(has_work) = task::scheduler::with_scheduler(|s| s.has_runnable_threads()) {
            if has_work {
                // Yield to let scheduler pick a ready thread
                task::scheduler::yield_current();
            }
        }

        // Periodically wake keyboard task to ensure responsiveness
        // This helps when returning from userspace execution
        static mut WAKE_COUNTER: u64 = 0;
        unsafe {
            WAKE_COUNTER += 1;
            if WAKE_COUNTER % 100 == 0 {
                keyboard::stream::wake_keyboard_task();
            }
        }
    }
}

#[cfg(target_arch = "x86_64")]
use core::panic::PanicInfo;

/// This function is called on panic.
#[cfg(target_arch = "x86_64")]
#[panic_handler]
fn panic(info: &PanicInfo) -> ! {
    // Try to output panic info if possible
    serial_println!("KERNEL PANIC: {}", info);
    log::error!("KERNEL PANIC: {}", info);

    // Failure-capture PR-4: the bounded, lock-free BXCAP record.
    //
    // ORDER. It goes after the banner because a reader wants the panic
    // message immediately above the state that explains it, and it goes
    // BEFORE `exit_qemu`, which ends the process at that line -- anything
    // not on the wire by then is lost. 6 of this kernel's 7 terminal x86
    // exceptions reach `panic!` (double fault, kernel page fault,
    // stack-segment, GPF, divide-by-0, stack overflow), so this one call
    // site carries those 6; `invalid_opcode_handler` does not panic and is
    // NOT covered -- see
    // docs/planning/green-program/failure-capture/PR-4-2026-09-05.md.
    //
    // The two words are the panic site's line and column, which is what
    // `[BXCAP:EDGE a0= a1=]` can carry without formatting anything.
    let (panic_line, panic_column) = match info.location() {
        Some(location) => (location.line() as u64, location.column() as u64),
        None => (0, 0),
    };
    kernel::capture::emit(kernel::capture::Edge::Panic, panic_line, panic_column);

    // In testing/CI builds, request QEMU to exit with failure for deterministic CI signal
    #[cfg(feature = "testing")]
    {
        kernel::exit_qemu(kernel::QemuExitCode::Failed);
    }

    // Disable interrupts and halt
    x86_64::instructions::interrupts::disable();
    loop {
        x86_64::instructions::hlt();
    }
}

// Test function for exception handlers
#[cfg(all(target_arch = "x86_64", feature = "test_all_exceptions"))]
fn test_exception_handlers() {
    log::info!("🧪 EXCEPTION_HANDLER_TESTS_START 🧪");

    // Test divide by zero
    log::info!("Testing divide by zero exception (simulated)...");
    // We can't actually trigger it without halting, so we just verify the handler is installed
    log::info!("EXCEPTION_TEST: DIVIDE_BY_ZERO handler installed ✓");

    // Test invalid opcode
    log::info!("Testing invalid opcode exception (simulated)...");
    log::info!("EXCEPTION_TEST: INVALID_OPCODE handler installed ✓");

    // Test page fault
    log::info!("Testing page fault exception (simulated)...");
    log::info!("EXCEPTION_TEST: PAGE_FAULT handler installed ✓");

    // Test that we can read from a valid address (shouldn't page fault)
    let test_addr = 0x1000 as *const u8;
    let _ = unsafe { core::ptr::read_volatile(test_addr) };
    log::info!("EXCEPTION_TEST: Valid memory access succeeded ✓");

    log::info!("🧪 EXCEPTION_HANDLER_TESTS_COMPLETE 🧪");
}

/// Test system calls from kernel mode
#[cfg(target_arch = "x86_64")]
#[allow(dead_code)]
fn test_syscalls() {
    serial_println!("DEBUG: test_syscalls() function entered");
    log::info!("DEBUG: Proceeding with syscall tests");

    {
        serial_println!("Testing system call infrastructure...");

        // Test 1: Verify INT 0x80 handler is installed
        serial_println!("Test 1: INT 0x80 handler installation");
        let _pre_result = unsafe { syscall::SYSCALL_RESULT };
        unsafe {
            core::arch::asm!(
                "mov rax, 4", // SyscallNumber::GetTime
                "int 0x80",
                // The kernel writes RAX on every syscall return, so the block
                // must declare it clobbered rather than leave the compiler
                // believing a live value survives the trap (#608 shape).
                lateout("rax") _,
                options(nostack)
            );
        }
        let post_result = unsafe { syscall::SYSCALL_RESULT };

        if post_result == 0x1234 {
            log::info!("✓ INT 0x80 handler called successfully");
        } else {
            log::error!("✗ INT 0x80 handler not working properly");
        }

        // Test 2: Direct syscall function tests
        log::info!("Test 2: Direct syscall implementations");

        // Test sys_get_time
        let time_result = syscall::handlers::sys_get_time();
        match time_result {
            SyscallResult::Ok(millis) => {
                // #767: milliseconds, which is what handlers::sys_get_time is
                // documented to return and what it now actually returns.
                log::info!("✓ sys_get_time: {} ms", millis);
                // Note: Timer may be 0 if very early in boot process
            }
            SyscallResult::Err(e) => log::error!("✗ sys_get_time failed: {:?}", e),
        }

        // Test sys_write
        let msg = b"[syscall test output]\n";
        let write_result = syscall::handlers::sys_write(1, msg.as_ptr() as u64, msg.len() as u64);
        match write_result {
            SyscallResult::Ok(bytes) => {
                log::info!("✓ sys_write: {} bytes written", bytes);
                // Note: All bytes should be written
            }
            SyscallResult::Err(e) => log::error!("✗ sys_write failed: {:?}", e),
        }

        // Test sys_yield
        let yield_result = syscall::handlers::sys_yield();
        match yield_result {
            SyscallResult::Ok(_) => log::info!("✓ sys_yield: success"),
            SyscallResult::Err(e) => log::error!("✗ sys_yield failed: {:?}", e),
        }

        // Test sys_read (should return 0 as no input available)
        let mut buffer = [0u8; 10];
        let read_result =
            syscall::handlers::sys_read(0, buffer.as_mut_ptr() as u64, buffer.len() as u64);
        match read_result {
            SyscallResult::Ok(bytes) => {
                log::info!("✓ sys_read: {} bytes read (expected 0)", bytes);
                // Note: No input should be available initially
            }
            SyscallResult::Err(e) => log::error!("✗ sys_read failed: {:?}", e),
        }

        // Test 3: Error handling
        log::info!("Test 3: Syscall error handling");

        // Invalid file descriptor for write
        let invalid_write = syscall::handlers::sys_write(99, 0, 0);
        match invalid_write {
            SyscallResult::Err(_) => log::info!("✓ Invalid FD correctly rejected"),
            SyscallResult::Ok(_) => panic!("Invalid FD should fail"),
        }
        log::info!("✓ Invalid write FD correctly rejected");

        // Invalid file descriptor for read
        let invalid_read = syscall::handlers::sys_read(99, 0, 0);
        match invalid_read {
            SyscallResult::Err(_) => log::info!("✓ Invalid FD correctly rejected"),
            SyscallResult::Ok(_) => panic!("Invalid FD should fail"),
        }
        log::info!("✓ Invalid read FD correctly rejected");

        log::info!("DEBUG: All tests done, about to print final message");
        log::info!("System call infrastructure test completed successfully!");
        log::info!("DEBUG: About to return from test_syscalls");
    }
}

// test_kthread_lifecycle and test_kthread_join moved to task/kthread_tests.rs
// for cross-architecture sharing (x86_64 + ARM64).

// test_kthread_exit_code, test_kthread_park_unpark, test_kthread_double_stop,
// test_kthread_should_stop_non_kthread, and test_kthread_stop_after_exit
// moved to task/kthread_tests.rs for cross-architecture sharing (x86_64 + ARM64).

// test_workqueue and test_softirq moved to task/workqueue_tests.rs and
// task/softirq_tests.rs for cross-architecture sharing (x86_64 + ARM64).

// test_kthread_stress moved to task/kthread_tests.rs for cross-architecture sharing (x86_64 + ARM64).

/// Test basic threading functionality
#[cfg(all(target_arch = "x86_64", feature = "testing"))]
#[allow(dead_code)]
fn test_threading() {
    log::info!("Testing threading infrastructure...");

    // Test 1: TLS infrastructure
    let tls_base = kernel::tls::current_tls_base();
    log::info!("✓ TLS base: {:#x}", tls_base);

    if tls_base == 0 {
        log::error!("TLS base is 0! Cannot test threading.");
        return;
    }

    // Test 2: CPU context creation
    let _context = kernel::task::thread::CpuContext::new(
        x86_64::VirtAddr::new(0x1000),
        x86_64::VirtAddr::new(0x2000),
        kernel::task::thread::ThreadPrivilege::Kernel,
    );
    log::info!("✓ CPU context creation works");

    // Test 3: Thread data structures
    let thread_name = alloc::string::String::from("test_thread");
    fn dummy_thread() {
        loop {
            x86_64::instructions::hlt();
        }
    }

    let _thread = kernel::task::thread::Thread::new(
        thread_name,
        dummy_thread,
        x86_64::VirtAddr::new(0x2000),
        x86_64::VirtAddr::new(0x1000),
        x86_64::VirtAddr::new(tls_base),
        kernel::task::thread::ThreadPrivilege::Kernel,
    );
    log::info!("✓ Thread structure creation works");

    // Test 4: TLS helper functions
    if let Some(_tls_block) = kernel::tls::get_thread_tls_block(0) {
        log::info!("✓ TLS block lookup works");
    } else {
        log::warn!("⚠️ TLS block lookup returned None (expected: 0 is the no-thread sentinel)");
    }

    // Test 5: Context switching assembly (just verify it compiles)
    log::info!("✓ Context switching assembly compiled successfully");

    // Test 6: Scheduler data structures compile
    log::info!("✓ Scheduler infrastructure compiled successfully");

    log::info!("=== Threading Infrastructure Test Results ===");
    log::info!("✅ TLS system: Working");
    log::info!("✅ CPU context: Working");
    log::info!("✅ Thread structures: Working");
    log::info!("✅ Assembly routines: Compiled");
    log::info!("✅ Scheduler: Compiled");
    log::info!("✅ Timer integration: Compiled");

    // Test 7: Actual thread switching using our assembly
    log::info!("Testing real context switching...");

    static SWITCH_TEST_COUNTER: core::sync::atomic::AtomicU32 =
        core::sync::atomic::AtomicU32::new(0);
    static mut MAIN_CONTEXT: Option<kernel::task::thread::CpuContext> = None;
    static mut THREAD_CONTEXT: Option<kernel::task::thread::CpuContext> = None;

    extern "C" fn test_thread_function() {
        // This is our test thread - it should run when we switch to it
        log::info!("🎯 SUCCESS: Thread context switch worked!");
        log::info!("🎯 Thread is executing with its own stack!");
        // Get current stack pointer using inline assembly
        let rsp: u64;
        unsafe {
            core::arch::asm!("mov {}, rsp", out(reg) rsp);
        }
        log::info!("🎯 Current stack pointer: {:#x}", rsp);

        SWITCH_TEST_COUNTER.fetch_add(100, core::sync::atomic::Ordering::Relaxed);

        // Validate that we're actually running in a different context
        let counter = SWITCH_TEST_COUNTER.load(core::sync::atomic::Ordering::Relaxed);

        log::info!("=== THREAD CONTEXT SWITCH VALIDATION ===");
        log::info!("✅ Thread execution: CONFIRMED");
        log::info!("✅ Thread stack: WORKING (RSP: {:#x})", rsp);
        log::info!("✅ Atomic operations: WORKING (counter: {})", counter);
        log::info!("✅ Thread logging: WORKING");
        log::info!("✅ CONTEXT SWITCHING TEST: **PASSED**");
        log::info!("==========================================");

        // Don't try to switch back - that would cause a page fault
        // Instead, just halt in this thread to show it's working
        log::info!("🎯 Thread test complete - entering halt loop");
        log::info!("🎯 (You should see this followed by a page fault - that's expected)");

        // Don't attempt return switch - just halt to prove the switch worked
        log::info!("🎯 Test complete - halting in thread context");
        loop {
            x86_64::instructions::hlt();
        }
    }

    // Allocate stack for our test thread
    if let Ok(test_stack) = kernel::memory::stack::allocate_stack(8192) {
        log::info!("✓ Allocated test thread stack");

        // Create contexts
        let main_context = kernel::task::thread::CpuContext::new(
            x86_64::VirtAddr::new(0), // Will be filled by actual switch
            x86_64::VirtAddr::new(0), // Will be filled by actual switch
            kernel::task::thread::ThreadPrivilege::Kernel,
        );

        let thread_context = kernel::task::thread::CpuContext::new(
            x86_64::VirtAddr::new(test_thread_function as u64),
            test_stack.top(),
            kernel::task::thread::ThreadPrivilege::Kernel,
        );

        log::info!("✓ Created contexts for real switching test");
        log::info!(
            "✓ Main context RIP: {:#x}, RSP: {:#x}",
            main_context.rip,
            main_context.rsp
        );
        log::info!(
            "✓ Thread context RIP: {:#x}, RSP: {:#x}",
            thread_context.rip,
            thread_context.rsp
        );

        // Save values before moving
        let thread_rip = thread_context.rip;
        let thread_rsp = thread_context.rsp;

        unsafe {
            MAIN_CONTEXT = Some(main_context);
            THREAD_CONTEXT = Some(thread_context);
        }

        SWITCH_TEST_COUNTER.store(1, core::sync::atomic::Ordering::Relaxed);

        log::info!("🚀 Skipping actual context switch in testing mode...");
        log::info!("✅ Context switch infrastructure ready");
        log::info!(
            "✅ Would switch to thread at RIP: {:#x}, RSP: {:#x}",
            thread_rip,
            thread_rsp
        );

        // Skip the actual switch to allow other tests to run
        /*
        unsafe {
            if let (Some(ref mut main_ctx), Some(ref thread_ctx)) = (MAIN_CONTEXT.as_mut(), THREAD_CONTEXT.as_ref()) {
                // This should save our current context and jump to the thread
                kernel::task::context::perform_context_switch(
                    main_ctx,
                    thread_ctx
                );
            }
        }
        */

        // We won't get here because the thread switch causes a page fault,
        // but if we did, we'd check the results
        log::info!("Note: If you see this, the return switch worked unexpectedly well!");
        let counter = SWITCH_TEST_COUNTER.load(core::sync::atomic::Ordering::Relaxed);
        log::info!("Counter would be: {}", counter);
    } else {
        log::error!("❌ Failed to allocate stack for switching test");
    }

    log::info!("📋 Note: Full context switching requires:");
    log::info!("   - Assembly integration with interrupt handling");
    log::info!("   - Stack unwinding and restoration");
    log::info!("   - This foundation is ready for that implementation");

    log::info!("Threading infrastructure test completed successfully!");
}

// =============================================================================
// Non-x86_64 note:
// When building for non-x86_64 (e.g., aarch64), all the code above is gated out.
// The lang items (panic_handler, global_allocator, alloc_error_handler) are
// provided by kernel::memory::heap for the entire crate.
// =============================================================================
